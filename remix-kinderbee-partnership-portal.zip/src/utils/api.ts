import { Enquiry, BlogPost, FAQItem, SystemSettings, DashboardStats } from "../types";

// Base API URL helper
const API_BASE = "";

// Helper to check if a response is JSON
async function fetchJsonOrFallback<T>(url: string, options?: RequestInit): Promise<{ isJson: boolean; ok: boolean; status: number; data?: T }> {
  try {
    const res = await fetch(url, options);
    const contentType = res.headers.get("content-type") || "";
    if (contentType.includes("application/json")) {
      const data = await res.json();
      return { isJson: true, ok: res.ok, status: res.status, data };
    }
    return { isJson: false, ok: res.ok, status: res.status };
  } catch (err) {
    return { isJson: false, ok: false, status: 0 };
  }
}

// Initial fallback seeds
const DEFAULT_SETTINGS: SystemSettings = {
  phone: "+91 99013 32233",
  email: "kinderbeeschools@gmail.com",
  officeAddress: "Opp Vijay Bakery, Old UCO Bank road, Ramamurthy Nagar, Bangalore, 560016",
  whatsappNumber: "+919901332233",
  facebookUrl: "https://facebook.com/kinderbeepreschool",
  linkedinUrl: "https://linkedin.com/company/kinderbee-education",
  instagramUrl: "https://instagram.com/kinderbee.preschool"
};

const DEFAULT_ENQUIRIES: Enquiry[] = [
  {
    id: "enq-1",
    type: "franchise",
    fields: {
      name: "Suresh Mehra",
      email: "suresh.mehra@gmail.com",
      phone: "+91 98234 56789",
      city: "Pune",
      state: "Maharashtra",
      budget: "₹25 Lakhs - ₹30 Lakhs",
      partnershipModel: "Preschool Franchise",
      message: "I own a 3,000 sq ft property in an upscale residential area of Pune. Interested in starting a premium Finnish-inspired preschool. Please call me."
    },
    status: "pending",
    notes: "Property verified. Ready for initial call on Friday.",
    aiSummary: "🌟 High Interest Lead: Entrepreneur owns a prime 3,000 sq ft property in Pune with a budget matching the ₹15L-₹35L requirement. Strongly recommended to highlight the Zero Royalty benefit during the call to secure the contract.",
    createdAt: "2026-08-05T14:30:00Z"
  },
  {
    id: "enq-2",
    type: "investor",
    fields: {
      name: "Anjali Deshmukh",
      email: "anjali@deshmukhtrust.org",
      phone: "+91 91234 88812",
      organization: "Deshmukh Educational Trust",
      city: "Nagpur",
      state: "Maharashtra",
      investmentInterest: "CBSE School Setup",
      budget: "₹1.5 Crores - ₹2 Crores",
      message: "Our trust wants to establish a new CBSE K-12 school in Nagpur. We need end-to-end guidance from land approvals to curriculum."
    },
    status: "reviewed",
    notes: "Emailed corporate presentation. Scheduled presentation with Director on Monday.",
    aiSummary: "💎 Elite Lead: Large budget educational trust exploring CBSE setup. Needs comprehensive operational and compliance support. Excellent candidate for KIPS multi-year project consulting.",
    createdAt: "2026-08-04T09:15:00Z"
  }
];

const DEFAULT_BLOGS: BlogPost[] = [
  {
    id: "blog-1",
    title: "The Power of Play-Based Learning: A Nordic Perspective",
    category: "Nordic Education",
    excerpt: "Discover why Finland's early childhood curriculum relies heavily on play and explore its implementation in modern Indian classrooms.",
    content: `## The Power of Play-Based Learning: A Nordic Perspective\n\nIn Finland, early childhood education is centered around a simple, powerful concept: **play is the natural way for a child to learn.**\n\nAccording to research supported by the Finnish Way Academy, structured and free play in early childhood develops critical pathways in a child's brain:\n1. **Social & Emotional Intelligence**: Children learn negotiation, turn-taking, and empathy through collaborative games.\n2. **Problem Solving**: Setting up a block tower or playing role-play scenarios requires creative reasoning.\n3. **Resilience**: Experiencing minor set-backs during play builds stress-management skills.\n\n### Bringing Finland to India\nAt KinderBee, we bridge the gap between rigorous academic expectations and healthy child development. By introducing the Nordic-inspired Play-Based Learning framework, we prepare preschoolers for the future of education, fostering lifetime curiosity and compliance with India's NEP 2020 guidelines.`,
    image: "https://images.unsplash.com/photo-1502086223501-7ea6ecd79368?auto=format&fit=crop&q=80&w=800",
    author: "Elina Virtanen (Nordic Curriculum Lead)",
    date: "2026-08-01",
    readTime: "5 min read",
    views: 1420
  },
  {
    id: "blog-2",
    title: "Why Investing in Early Education is India's Smartest Business Move",
    category: "Investment",
    excerpt: "With rising parental awareness and government reforms, the Indian preschool and K-12 market is experiencing unprecedented demand.",
    content: `## Why Investing in Early Education is India's Smartest Business Move\n\nFor entrepreneurs and investors, selecting a business sector with sustainable, recurring revenue and low volatility is a high priority. The **Indian Education Market** represents one of the most resilient industries in the country today.\n\nHere are three primary drivers:\n- **Zero Recessional Vulnerability**: Parents prioritize education over luxury items.\n- **NEP 2020 Regulatory Push**: Government reforms formalize early childhood care.\n- **Double-Digit Growth**: Preschool franchise segments in Tier-1, Tier-2, and Tier-3 cities expand at >12% CAGR.\n\n### The KinderBee Advantage (KIPS)\nUnlike traditional educational franchises that charge high royalty fees (15%-25%), KIPS operates on a **100% Zero Royalty Model** allowing higher profit retention.`,
    image: "https://images.unsplash.com/photo-1509062522246-3755977927d7?auto=format&fit=crop&q=80&w=800",
    author: "Amit Sharma (Chief Financial Strategist)",
    date: "2026-07-28",
    readTime: "4 min read",
    views: 980
  },
  {
    id: "blog-3",
    title: "Implementing NEP 2020: A Guide for School Administrators",
    category: "School Setup",
    excerpt: "National Education Policy 2020 is reshaping school structures. Learn how existing campuses can adapt and upgrade smoothly.",
    content: `## Implementing NEP 2020: A Guide for School Administrators\n\nThe National Education Policy (NEP) 2020 introduces a structural shift to the **5+3+3+4 cognitive development framework**.\n\nFor existing school administrators, this requires rethinking both physical spaces and academic syllabi:\n- **Foundational Stage (Ages 3-8)**: Encompasses 3 years of preschool plus Grades 1 and 2.\n- **Preparatory Stage (Ages 8-11)**: Integrates hands-on learning with textbook concepts.\n- **Skills and Coding Integration**: Secondary grades now require vocational exposure and coding readiness.`,
    image: "https://images.unsplash.com/photo-1427504494785-3a9ca7044f45?auto=format&fit=crop&q=80&w=800",
    author: "Dr. Rajesh Iyer (Academic Advisor)",
    date: "2026-07-15",
    readTime: "7 min read",
    views: 2150
  }
];

const DEFAULT_FAQS: FAQItem[] = [
  {
    id: "faq-1",
    question: "What is the KIPS Zero Royalty model and how does it work?",
    answer: "Unlike traditional franchises that charge 15-25% of your recurring tuition revenues, KinderBee operates on a Zero Royalty Model. Partners pay an upfront, transparent integration/consultancy fee. You keep 100% of your tuition revenues and profits, allowing faster break-even and higher profitability.",
    section: "home"
  },
  {
    id: "faq-2",
    question: "What support does KinderBee provide during school setup?",
    answer: "We provide complete end-to-end support, including site selection guidance, interior layout design, furniture planning, digital classroom setup, teacher recruitment assistance, Finnish Way Academy curriculum and training, admission launch campaigns, and ongoing academic audits.",
    section: "home"
  },
  {
    id: "faq-3",
    question: "Are the teacher certifications accredited?",
    answer: "Yes, FinnishWay Academy certifications are globally recognized and industry-aligned, preparing educators with professional competencies, practical portfolios, and hands-on teaching strategies that meet international and NEP 2020 standards.",
    section: "fwa"
  },
  {
    id: "faq-4",
    question: "What is the minimum land/space requirement for a Preschool?",
    answer: "A preschool franchise typically requires a minimum land area of 2,500 to 5,000 sq. ft. and a built-up area of 1,800 to 3,500 sq. ft., accommodating 6 to 10 classrooms, administrative zones, and play areas.",
    section: "investor"
  },
  {
    id: "faq-5",
    question: "What is the typical investment and ROI timeline?",
    answer: "The typical investment ranges from ₹15 Lakhs to ₹35 Lakhs depending on the city, building state, and local infrastructure requirements. Due to the Zero Royalty structure, most franchise partners achieve break-even and generate positive ROI within 18 to 24 months.",
    section: "investor"
  }
];

const DEFAULT_PAGES = [
  {
    id: "home",
    title: "Build the Future of Education with KIPS",
    subtitle: "The KinderBee Integrated Partnership System (KIPS) is India's leading complete educational ecosystem. We don't just sell franchises—we help entrepreneurs plan, establish, launch, and operate highly successful, world-class schools with absolute local authority.",
    metaTitle: "Build the Future of Education with KIPS | KinderBee KIPS",
    metaDescription: "The KinderBee Integrated Partnership System (KIPS) is India's leading complete educational ecosystem. We don't just sell franchises—we help entrepreneurs...",
    keywords: "preschool franchise, school setup india, finnish education, zero royalty franchise, nep 2020 school setup, preschool business",
    badgeText: "Zero Royalty. Lifetime Support. Global Standards.",
    content1: "India's Zero Royalty Education Franchise & School Development Partner"
  },
  {
    id: "about",
    title: "Empowering Educators & Entrepreneurs",
    subtitle: "KinderBee is on a mission to democratize premium international education across India, eliminating royalty burdens and providing school owners with elite world-class tools.",
    metaTitle: "About KinderBee - Global Standards, Nordic Pedagogy",
    metaDescription: "Learn about KinderBee's mission, values, and our partnership with Finnish Way Academy to deliver top-tier education with Zero Royalty benefits across India.",
    keywords: "kinderbee curriculum, finnish school franchise, nep preschool india, play-based early learning",
    badgeText: "OUR JOURNEY & CORE MISSION",
    content1: "Democratic Education with Zero Franchise Royalties"
  },
  {
    id: "partnerships",
    title: "Our Collaborative Education Models",
    subtitle: "From high-profit Preschool Franchises to comprehensive CBSE School Setup and existing school upgrades, explore our zero-royalty partnership pathways.",
    metaTitle: "Education Partnerships - School Setup & Upgrades | KinderBee",
    metaDescription: "Explore KinderBee educational models. Get comprehensive assistance for CBSE/IB school setups, play school franchise systems, and existing school transformation with zero royalties.",
    keywords: "cbse school setup, preschool franchise cost, school setup consultant, school rebranding",
    badgeText: "Strategic Association Portfolios",
    content1: "Custom Solutions Tailored to Your Property and Vision"
  },
  {
    id: "fwa",
    title: "Finnish Way Academy Teacher Training",
    subtitle: "Unlock globally acclaimed pedagogical expertise. Empower your teaching staff with active, play-based learning frameworks certified by Finnish childhood education experts.",
    metaTitle: "Finnish Way Academy - Early Educator Certifications | KinderBee",
    metaDescription: "Acquire international early childhood teacher diplomas and certifications. Finnish-inspired pedagogy, active play-based teacher training programs.",
    keywords: "teacher training diploma, preschool teacher course, finnish education training, ntt course online",
    badgeText: "Acclaimed Pedagogical Certifications",
    content1: "Globally Accredited Teacher Professional Development"
  },
  {
    id: "investors",
    title: "High ROI Educational Investment Opportunities",
    subtitle: "Invest in one of India's most resilient and expanding sectors. Benefit from rapid capital recovery, zero recurring royalties, and complete operational guidance.",
    metaTitle: "Investors Hub - High ROI Preschool Investment | KinderBee",
    metaDescription: "Explore premium preschool franchise investment options. Highly resilient cash flows, fast ROI within 18-24 months, and a 100% Zero Royalty setup.",
    keywords: "education investment, preschool franchise roi, profitable school franchise, education business opportunity",
    badgeText: "Capital Appreciation & Enterprise Growth",
    content1: "Robust Multi-Year Fiscal Security in Indian K-12 Spaces"
  },
  {
    id: "contact",
    title: "Connect with our Central Advisors",
    subtitle: "Speak directly with our school planning consultants to map out your educational project feasibility, site criteria, and budget expectations.",
    metaTitle: "Contact Us - KinderBee School Setup Advisory",
    metaDescription: "Contact KinderBee corporate office today. Schedule a phone consultation or offline visit to discuss school franchise or consulting requirements.",
    keywords: "contact school franchise, kinderbee office phone, preschool setup consulting call",
    badgeText: "Get In Touch Today",
    content1: "Strategic Project Blueprint Session"
  }
];

// LocalStorage helpers
function getLocal<T>(key: string, fallback: T): T {
  try {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : fallback;
  } catch (e) {
    return fallback;
  }
}

function setLocal<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (e) {
    console.warn("Failed to write to localStorage:", e);
  }
}

function getAuthHeaders(): HeadersInit {
  const token = localStorage.getItem("kips_admin_token");
  return {
    "Content-Type": "application/json",
    ...(token ? { "Authorization": `Bearer ${token}` } : {})
  };
}

export const api = {
  // Public submissions
  async submitEnquiry(type: Enquiry['type'], fields: Enquiry['fields']): Promise<{ success: boolean; enquiryId: string; aiSummary?: string }> {
    const res = await fetchJsonOrFallback<{ success: boolean; enquiryId: string; aiSummary?: string }>(`${API_BASE}/api/enquiries`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ type, fields })
    });

    if (res.isJson && res.ok && res.data) {
      return res.data;
    }

    // Client-side fallback for static hosts
    const id = "enq-" + Date.now();
    const name = fields.name || "Prospect";
    const city = fields.city || "Location";
    const aiSummary = `🌟 New Lead (${type.toUpperCase()}): ${name} from ${city}. Project budget: ${fields.budget || "Standard"}. High priority follow-up logged.`;
    
    const newEnq: Enquiry = {
      id,
      type,
      fields,
      status: "pending",
      notes: "Lead recorded via Web Portal.",
      aiSummary,
      createdAt: new Date().toISOString()
    };

    const currentEnqs = getLocal<Enquiry[]>("kips_local_enquiries", DEFAULT_ENQUIRIES);
    setLocal("kips_local_enquiries", [newEnq, ...currentEnqs]);

    return { success: true, enquiryId: id, aiSummary };
  },

  // Admin authentication
  async login(password: string): Promise<{ success: boolean; token?: string; error?: string }> {
    const res = await fetchJsonOrFallback<{ success: boolean; token?: string; error?: string }>(`${API_BASE}/api/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ password })
    });

    if (res.isJson) {
      if (res.status === 401) return { success: false, error: "Invalid password" };
      if (res.ok && res.data) return res.data;
    }

    // Fallback authentication for static deployments (Vercel/GitHub Pages)
    const customPass = getLocal<string>("kips_local_admin_password", "admin");
    const validPasswords = ["admin", "kips2026", "admin123", customPass];

    if (validPasswords.includes(password.trim())) {
      const token = "kips_static_token_" + Date.now();
      return { success: true, token };
    }

    return { success: false, error: "Incorrect security code. Default is 'admin'." };
  },

  // Public blogs
  async getBlogs(): Promise<BlogPost[]> {
    const res = await fetchJsonOrFallback<BlogPost[]>(`${API_BASE}/api/blogs`);
    if (res.isJson && res.ok && res.data) return res.data;
    return getLocal<BlogPost[]>("kips_local_blogs", DEFAULT_BLOGS);
  },

  async recordBlogView(id: string): Promise<{ success: boolean; views: number }> {
    const res = await fetchJsonOrFallback<{ success: boolean; views: number }>(`${API_BASE}/api/blogs/${id}/view`, { method: "POST" });
    if (res.isJson && res.ok && res.data) return res.data;

    const blogs = getLocal<BlogPost[]>("kips_local_blogs", DEFAULT_BLOGS);
    let updatedViews = 1;
    const updated = blogs.map(b => {
      if (b.id === id) {
        updatedViews = (b.views || 0) + 1;
        return { ...b, views: updatedViews };
      }
      return b;
    });
    setLocal("kips_local_blogs", updated);
    return { success: true, views: updatedViews };
  },

  // Public FAQs
  async getFAQs(): Promise<FAQItem[]> {
    const res = await fetchJsonOrFallback<FAQItem[]>(`${API_BASE}/api/faqs`);
    if (res.isJson && res.ok && res.data) return res.data;
    return getLocal<FAQItem[]>("kips_local_faqs", DEFAULT_FAQS);
  },

  // Public settings
  async getSettings(): Promise<SystemSettings> {
    const res = await fetchJsonOrFallback<SystemSettings>(`${API_BASE}/api/settings`);
    if (res.isJson && res.ok && res.data) return res.data;
    return getLocal<SystemSettings>("kips_local_settings", DEFAULT_SETTINGS);
  },

  // ==========================================
  // ADMIN AUTHENTICATED ENDPOINTS
  // ==========================================

  // Get all enquiries (leads)
  async getEnquiries(): Promise<Enquiry[]> {
    const res = await fetchJsonOrFallback<Enquiry[]>(`${API_BASE}/api/enquiries`, { headers: getAuthHeaders() });
    if (res.isJson && res.ok && res.data) return res.data;
    return getLocal<Enquiry[]>("kips_local_enquiries", DEFAULT_ENQUIRIES);
  },

  // Update enquiry notes or status
  async updateEnquiry(id: string, updates: { status?: Enquiry['status']; notes?: string }): Promise<Enquiry> {
    const res = await fetchJsonOrFallback<Enquiry>(`${API_BASE}/api/enquiries/${id}`, {
      method: "PUT",
      headers: getAuthHeaders(),
      body: JSON.stringify(updates)
    });
    if (res.isJson && res.ok && res.data) return res.data;

    const enqs = getLocal<Enquiry[]>("kips_local_enquiries", DEFAULT_ENQUIRIES);
    let targetEnq: Enquiry | null = null;
    const updated = enqs.map(e => {
      if (e.id === id) {
        targetEnq = { ...e, ...updates };
        return targetEnq;
      }
      return e;
    });
    setLocal("kips_local_enquiries", updated);
    if (!targetEnq) throw new Error("Inquiry not found");
    return targetEnq;
  },

  // Delete enquiry
  async deleteEnquiry(id: string): Promise<{ success: boolean }> {
    const res = await fetchJsonOrFallback<{ success: boolean }>(`${API_BASE}/api/enquiries/${id}`, {
      method: "DELETE",
      headers: getAuthHeaders()
    });
    if (res.isJson && res.ok && res.data) return res.data;

    const enqs = getLocal<Enquiry[]>("kips_local_enquiries", DEFAULT_ENQUIRIES);
    setLocal("kips_local_enquiries", enqs.filter(e => e.id !== id));
    return { success: true };
  },

  // Blog management (CRUD)
  async createBlog(blog: Omit<BlogPost, 'id' | 'date'>): Promise<{ success: boolean; blog: BlogPost }> {
    const res = await fetchJsonOrFallback<{ success: boolean; blog: BlogPost }>(`${API_BASE}/api/blogs`, {
      method: "POST",
      headers: getAuthHeaders(),
      body: JSON.stringify(blog)
    });
    if (res.isJson && res.ok && res.data) return res.data;

    const newBlog: BlogPost = {
      ...blog,
      id: "blog-" + Date.now(),
      date: new Date().toISOString().split("T")[0],
      views: 0
    };
    const blogs = getLocal<BlogPost[]>("kips_local_blogs", DEFAULT_BLOGS);
    setLocal("kips_local_blogs", [newBlog, ...blogs]);
    return { success: true, blog: newBlog };
  },

  async updateBlog(id: string, blog: Partial<BlogPost>): Promise<{ success: boolean; blog: BlogPost }> {
    const res = await fetchJsonOrFallback<{ success: boolean; blog: BlogPost }>(`${API_BASE}/api/blogs/${id}`, {
      method: "PUT",
      headers: getAuthHeaders(),
      body: JSON.stringify(blog)
    });
    if (res.isJson && res.ok && res.data) return res.data;

    const blogs = getLocal<BlogPost[]>("kips_local_blogs", DEFAULT_BLOGS);
    let updatedBlog: BlogPost | null = null;
    const updated = blogs.map(b => {
      if (b.id === id) {
        updatedBlog = { ...b, ...blog };
        return updatedBlog;
      }
      return b;
    });
    setLocal("kips_local_blogs", updated);
    if (!updatedBlog) throw new Error("Blog not found");
    return { success: true, blog: updatedBlog };
  },

  async deleteBlog(id: string): Promise<{ success: boolean }> {
    const res = await fetchJsonOrFallback<{ success: boolean }>(`${API_BASE}/api/blogs/${id}`, {
      method: "DELETE",
      headers: getAuthHeaders()
    });
    if (res.isJson && res.ok && res.data) return res.data;

    const blogs = getLocal<BlogPost[]>("kips_local_blogs", DEFAULT_BLOGS);
    setLocal("kips_local_blogs", blogs.filter(b => b.id !== id));
    return { success: true };
  },

  // FAQ management (CRUD)
  async createFAQ(faq: Omit<FAQItem, 'id'>): Promise<{ success: boolean; faq: FAQItem }> {
    const res = await fetchJsonOrFallback<{ success: boolean; faq: FAQItem }>(`${API_BASE}/api/faqs`, {
      method: "POST",
      headers: getAuthHeaders(),
      body: JSON.stringify(faq)
    });
    if (res.isJson && res.ok && res.data) return res.data;

    const newFaq: FAQItem = {
      ...faq,
      id: "faq-" + Date.now()
    };
    const faqs = getLocal<FAQItem[]>("kips_local_faqs", DEFAULT_FAQS);
    setLocal("kips_local_faqs", [...faqs, newFaq]);
    return { success: true, faq: newFaq };
  },

  async updateFAQ(id: string, faq: Partial<FAQItem>): Promise<{ success: boolean; faq: FAQItem }> {
    const res = await fetchJsonOrFallback<{ success: boolean; faq: FAQItem }>(`${API_BASE}/api/faqs/${id}`, {
      method: "PUT",
      headers: getAuthHeaders(),
      body: JSON.stringify(faq)
    });
    if (res.isJson && res.ok && res.data) return res.data;

    const faqs = getLocal<FAQItem[]>("kips_local_faqs", DEFAULT_FAQS);
    let updatedFaq: FAQItem | null = null;
    const updated = faqs.map(f => {
      if (f.id === id) {
        updatedFaq = { ...f, ...faq };
        return updatedFaq;
      }
      return f;
    });
    setLocal("kips_local_faqs", updated);
    if (!updatedFaq) throw new Error("FAQ not found");
    return { success: true, faq: updatedFaq };
  },

  async deleteFAQ(id: string): Promise<{ success: boolean }> {
    const res = await fetchJsonOrFallback<{ success: boolean }>(`${API_BASE}/api/faqs/${id}`, {
      method: "DELETE",
      headers: getAuthHeaders()
    });
    if (res.isJson && res.ok && res.data) return res.data;

    const faqs = getLocal<FAQItem[]>("kips_local_faqs", DEFAULT_FAQS);
    setLocal("kips_local_faqs", faqs.filter(f => f.id !== id));
    return { success: true };
  },

  // Update Settings
  async updateSettings(settings: Partial<SystemSettings>): Promise<{ success: boolean; settings: SystemSettings }> {
    const res = await fetchJsonOrFallback<{ success: boolean; settings: SystemSettings }>(`${API_BASE}/api/settings`, {
      method: "PUT",
      headers: getAuthHeaders(),
      body: JSON.stringify(settings)
    });
    if (res.isJson && res.ok && res.data) return res.data;

    const currentSettings = getLocal<SystemSettings>("kips_local_settings", DEFAULT_SETTINGS);
    const updated = { ...currentSettings, ...settings };
    setLocal("kips_local_settings", updated);
    return { success: true, settings: updated };
  },

  // Change Admin Password
  async changePassword(password: string): Promise<{ success: boolean }> {
    const res = await fetchJsonOrFallback<{ success: boolean }>(`${API_BASE}/api/settings/password`, {
      method: "PUT",
      headers: getAuthHeaders(),
      body: JSON.stringify({ newPassword: password })
    });
    if (res.isJson && res.ok && res.data) return res.data;

    setLocal("kips_local_admin_password", password);
    return { success: true };
  },

  // Get Admin Dashboard Analytics
  async getAnalytics(): Promise<DashboardStats> {
    const res = await fetchJsonOrFallback<DashboardStats>(`${API_BASE}/api/analytics`, { headers: getAuthHeaders() });
    if (res.isJson && res.ok && res.data) return res.data;

    const enqs = getLocal<Enquiry[]>("kips_local_enquiries", DEFAULT_ENQUIRIES);
    const blogs = getLocal<BlogPost[]>("kips_local_blogs", DEFAULT_BLOGS);

    const pendingLeads = enqs.filter(e => e.status === "pending").length;
    const reviewedLeads = enqs.filter(e => e.status === "reviewed").length;
    const contactedLeads = enqs.filter(e => e.status === "contacted").length;
    const closedLeads = enqs.filter(e => e.status === "closed").length;

    const franchiseCount = enqs.filter(e => e.type === "franchise").length;
    const investorCount = enqs.filter(e => e.type === "investor").length;
    const fwaCount = enqs.filter(e => e.type === "fwa_course").length;
    const generalCount = enqs.filter(e => e.type === "general" || e.type === "consultation" || e.type === "brochure").length;

    return {
      totalLeads: enqs.length,
      pendingLeads,
      reviewedLeads,
      contactedLeads,
      closedLeads,
      totalBlogs: blogs.length,
      estimatedRevenuePotential: `₹${(enqs.length * 15).toFixed(1)} Lakhs`,
      leadsByType: [
        { name: "Franchise", value: franchiseCount },
        { name: "Investor", value: investorCount },
        { name: "FWA Course", value: fwaCount },
        { name: "General Inquiry", value: generalCount }
      ]
    };
  },

  // Request AI suggested professional draft reply
  async getAISuggestedReply(enquiryId: string): Promise<{ success: boolean; emailDraft: string }> {
    const res = await fetchJsonOrFallback<{ success: boolean; emailDraft: string }>(`${API_BASE}/api/ai/suggest-reply`, {
      method: "POST",
      headers: getAuthHeaders(),
      body: JSON.stringify({ enquiryId })
    });
    if (res.isJson && res.ok && res.data) return res.data;

    const enqs = getLocal<Enquiry[]>("kips_local_enquiries", DEFAULT_ENQUIRIES);
    const target = enqs.find(e => e.id === enquiryId);
    const name = target?.fields?.name || "Valued Educator";

    const draft = `Subject: KinderBee KIPS Partnership Advisory - Consultation Blueprint\n\nDear ${name},\n\nThank you for reaching out to KinderBee Integrated Partnership System (KIPS).\n\nWe have reviewed your request regarding educational setup opportunities. With our 100% Zero Royalty Model and Finnish Way Academy curriculum integration, KinderBee provides an unexcelled framework for academic excellence and rapid investment returns.\n\nOur Senior Academic Advisor will connect with you shortly to schedule an initial consultation.\n\nWarm regards,\nKinderBee Partnerships Team\n${DEFAULT_SETTINGS.phone} | ${DEFAULT_SETTINGS.email}`;

    return { success: true, emailDraft: draft };
  },

  // Pages management (CRUD/SEOs)
  async getPages(): Promise<any[]> {
    const res = await fetchJsonOrFallback<any[]>(`${API_BASE}/api/pages`);
    if (res.isJson && res.ok && res.data) return res.data;
    return getLocal<any[]>("kips_local_pages", DEFAULT_PAGES);
  },

  async updatePage(id: string, data: any): Promise<{ success: boolean; page: any }> {
    const res = await fetchJsonOrFallback<{ success: boolean; page: any }>(`${API_BASE}/api/pages/${id}`, {
      method: "PUT",
      headers: getAuthHeaders(),
      body: JSON.stringify(data)
    });
    if (res.isJson && res.ok && res.data) return res.data;

    const pages = getLocal<any[]>("kips_local_pages", DEFAULT_PAGES);
    let updatedPage: any = null;
    const updated = pages.map(p => {
      if (p.id === id) {
        updatedPage = { ...p, ...data };
        return updatedPage;
      }
      return p;
    });
    setLocal("kips_local_pages", updated);
    return { success: true, page: updatedPage };
  }
};
