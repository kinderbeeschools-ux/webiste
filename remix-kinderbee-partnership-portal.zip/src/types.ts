export type EnquiryType = 'franchise' | 'consultation' | 'brochure' | 'general' | 'fwa_course' | 'investor';

export interface Enquiry {
  id: string;
  type: EnquiryType;
  fields: {
    name: string;
    email: string;
    phone: string;
    organization?: string;
    city?: string;
    state?: string;
    investmentInterest?: string;
    budget?: string;
    partnershipModel?: string;
    message?: string;
    courseOfInterest?: string;
    academicBackground?: string;
    learningMode?: string;
  };
  status: 'pending' | 'reviewed' | 'contacted' | 'closed';
  notes: string;
  aiSummary?: string;
  createdAt: string;
}

export interface BlogPost {
  id: string;
  title: string;
  category: string;
  excerpt: string;
  content: string;
  image: string;
  author: string;
  date: string;
  readTime: string;
  views?: number;
  metaTitle?: string;
  metaDescription?: string;
  keywords?: string;
}

export interface FAQItem {
  id: string;
  question: string;
  answer: string;
  section: 'home' | 'investor' | 'fwa';
}

export interface SystemSettings {
  phone: string;
  email: string;
  officeAddress: string;
  whatsappNumber: string;
  facebookUrl: string;
  linkedinUrl?: string;
  instagramUrl: string;
  workingHours?: string;
  
  // Customizable Popup Settings
  popupEnabled?: boolean;
  popupDelay?: number; // Delay in seconds before auto-popping (default 5s)
  popupScrollTrigger?: boolean; // Trigger popup on scroll depth (default true)
  popupScrollPercent?: number; // Scroll percentage threshold (default 50%)
  popupTag?: string; // e.g. "ADMISSIONS & FRANCHISE OPEN"
  popupTitle?: string; // e.g. "Start Your Transformation Journey"
  popupSubtitle?: string; // e.g. "Complete the form and our Academic Advisor will contact you shortly."
  popupImageUrl?: string; // Left Poster Image URL
  popupImageAlt?: string;
}

export interface DashboardStats {
  totalLeads: number;
  pendingLeads: number;
  reviewedLeads: number;
  contactedLeads: number;
  closedLeads: number;
  totalBlogs: number;
  estimatedRevenuePotential: string;
  leadsByType: { name: string; value: number }[];
}
