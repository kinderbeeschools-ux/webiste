import React, { useState, useEffect } from 'react';
import { X, Check, ArrowRight, Sparkles, GraduationCap, Users, Globe, Cpu, Award, Heart, ChevronDown } from 'lucide-react';
import { api } from '../utils/api';
import { SystemSettings } from '../types';

interface LeadPopupModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: SystemSettings;
}

export default function LeadPopupModal({ isOpen, onClose, settings }: LeadPopupModalProps) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    status: 'School Student',
    academy: 'KIPS Preschool Franchise (0% Royalty)',
    city: ''
  });
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      setSubmitted(false);
      setError(null);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.phone || !formData.email) {
      setError('Please fill in Name, Email, and Phone Number.');
      return;
    }

    setSubmitting(true);
    setError(null);

    try {
      await api.submitEnquiry('franchise', {
        name: formData.name,
        email: formData.email,
        phone: formData.phone,
        city: formData.city || 'Not Specified',
        partnershipModel: `${formData.status} - ${formData.academy}`,
        message: `Transformation Popup Lead: ${formData.status} interested in ${formData.academy} in ${formData.city || 'General'}`
      });
      setSubmitted(true);
    } catch (err) {
      console.error('Failed to submit popup lead:', err);
      setError('Something went wrong. Please try again or contact our advisor directly.');
    } finally {
      setSubmitting(false);
    }
  };

  const statusOptions = [
    'School Student',
    'College Student',
    'Working Professional',
    'Parent',
    'Faculty'
  ];

  const academyOptions = [
    'KIPS Preschool Franchise (0% Royalty)',
    'Finnish Way NTT Teacher Training & Diploma',
    'CBSE / ICSE School Setup Consulting',
    'Existing School Upgrade & Rebranding',
    'Future Skills & AI Leadership Academy',
    'Student Admission Enquiry'
  ];

  return (
    <div 
      className="fixed inset-0 z-[9999] flex items-center justify-center p-2.5 sm:p-4 md:p-6 bg-black/75 backdrop-blur-sm overflow-y-auto"
      id="lead-popup-modal-overlay"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      {/* Modal Dialog Container - Compact & Scaled */}
      <div 
        className="relative bg-white rounded-2xl sm:rounded-3xl shadow-2xl overflow-hidden max-w-4xl w-full grid grid-cols-1 md:grid-cols-12 border border-stone-200 my-auto max-h-[92vh] flex flex-col md:grid"
        id="lead-popup-dialog"
        role="dialog"
        aria-modal="true"
      >
        {/* Close Button Top Right */}
        <button
          onClick={onClose}
          type="button"
          className="absolute top-2 right-2 sm:top-3 sm:right-3 z-40 w-6 h-6 sm:w-7 sm:h-7 rounded-full bg-stone-100/90 hover:bg-stone-200 text-stone-700 flex items-center justify-center transition-all cursor-pointer shadow-xs"
          aria-label="Close dialog"
        >
          <X className="w-3.5 h-3.5" />
        </button>

        {/* Mobile Compact Top Header Banner (Shown ONLY on Mobile < md) */}
        <div className="md:hidden bg-[#04100D] text-white px-3 py-1.5 relative overflow-hidden flex items-center justify-between pr-8 border-b border-stone-800 shrink-0">
          <div className="flex items-center gap-1.5">
            <div className="w-4 h-4 rounded-full border border-amber-400/60 bg-amber-400/10 flex items-center justify-center">
              <Globe className="w-2.5 h-2.5 text-amber-400" />
            </div>
            <span className="font-bold tracking-wider text-amber-300 text-[10px] font-display">
              KIPS GLOBAL VENTURES
            </span>
          </div>
          <span className="text-[8px] font-bold text-amber-400 uppercase tracking-wider bg-amber-400/10 px-1.5 py-0.5 rounded border border-amber-400/30">
            Admissions Open
          </span>
        </div>

        {/* LEFT COLUMN: Luxurious Brand Poster Card (Desktop/Tablet md: and lg:) */}
        <div className="hidden md:flex md:col-span-5 relative bg-[#04100D] text-white flex-col justify-between p-5 lg:p-6 overflow-hidden border-r border-stone-800">
          
          {/* Background image & gradient overlay */}
          <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
            <img
              src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=900"
              alt="Transformation Journey"
              className="w-full h-full object-cover object-center opacity-30 filter contrast-125 brightness-95"
            />
            {/* Dark green & golden ambient vignettes */}
            <div className="absolute inset-0 bg-gradient-to-t from-[#04100D] via-[#04100D]/80 to-[#04100D]/40" />
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-amber-500/20 via-transparent to-transparent" />
            
            {/* Elegant golden curve graphics */}
            <div className="absolute -bottom-10 -right-10 w-60 h-60 rounded-full border-[1.5px] border-amber-400/30 blur-[0.5px]" />
          </div>

          {/* Top Logo / Brand Title */}
          <div className="relative z-10 space-y-1">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-full border border-amber-400/60 bg-amber-400/10 flex items-center justify-center">
                <Globe className="w-3.5 h-3.5 text-amber-400" />
              </div>
              <div>
                <span className="font-extrabold tracking-wider text-amber-300 text-xs font-display block leading-tight">
                  KIPS GLOBAL VENTURES
                </span>
                <span className="text-[8px] tracking-[0.2em] text-stone-300 uppercase block font-sans">
                  VALUES • TRADE • FUTURE
                </span>
              </div>
            </div>
            <div className="w-full h-[1px] bg-gradient-to-r from-transparent via-amber-400/40 to-transparent mt-1.5"></div>
          </div>

          {/* Center Poster Content */}
          <div className="relative z-10 space-y-3 my-auto py-3">
            <div>
              <div className="text-2xl lg:text-3xl font-black font-display tracking-tight text-white leading-none">
                TRANSFORM
              </div>
              <div className="text-2xl lg:text-3xl font-black font-display tracking-tight text-white leading-none mt-0.5">
                YOUR
              </div>
              <div className="text-2xl lg:text-3xl font-serif italic font-bold tracking-tight text-amber-400 leading-none mt-0.5">
                FUTURE
              </div>
              
              <div className="mt-1.5 text-[9px] tracking-wider font-extrabold text-cyan-300 uppercase font-display">
                FUTURE SKILLS • LEADERSHIP • GLOBAL CAREERS
              </div>

              <p className="text-[10px] lg:text-[11px] text-stone-300 font-sans mt-1.5 leading-relaxed line-clamp-2">
                Empowering individuals to become confident professionals, visionary leaders and responsible citizens.
              </p>
            </div>

            {/* Feature Icon Badges */}
            <div className="grid grid-cols-1 gap-1.5 pt-0.5">
              {[
                { icon: GraduationCap, label: 'CAREER READY PROGRAMS' },
                { icon: Users, label: 'INDUSTRY MENTORSHIP' },
                { icon: Globe, label: 'GLOBAL PLACEMENT SUPPORT' },
                { icon: Cpu, label: 'AI & FUTURE SKILLS' },
                { icon: Award, label: 'LEADERSHIP DEVELOPMENT' },
                { icon: Heart, label: 'FAMILY TRANSFORMATION' }
              ].map((item, idx) => (
                <div key={idx} className="flex items-center gap-2 text-[10px] font-semibold text-stone-200">
                  <div className="w-4 h-4 rounded-full bg-amber-400/15 border border-amber-400/40 text-amber-300 flex items-center justify-center shrink-0">
                    <item.icon className="w-2.5 h-2.5" />
                  </div>
                  <span className="tracking-wide uppercase font-sans text-stone-100">{item.label}</span>
                </div>
              ))}
            </div>

            {/* Apply Now Pill */}
            <div className="pt-1">
              <div className="inline-flex items-center justify-center gap-1.5 w-full py-1.5 px-3 rounded-full bg-gradient-to-r from-[#0C5A3E] to-[#0A4731] border border-amber-400/50 text-white font-bold text-[10px] tracking-wider uppercase shadow-md">
                <span>APPLY NOW</span>
                <ArrowRight className="w-3 h-3 text-amber-300" />
              </div>
            </div>
          </div>

          {/* Bottom Banner Footer */}
          <div className="relative z-10 pt-2 border-t border-white/15 text-center space-y-0.5">
            <div className="text-[8.5px] tracking-wider text-amber-300 font-bold uppercase font-display">
              YOUR JOURNEY. OUR MISSION.
            </div>
            <div className="text-[7.5px] tracking-wider text-stone-300 flex items-center justify-center gap-1.5 font-sans">
              <span>📖 LEARN</span>
              <span>•</span>
              <span>🚀 TRANSFORM</span>
              <span>•</span>
              <span>⭐ LEAD</span>
              <span>•</span>
              <span>👥 INSPIRE</span>
            </div>
          </div>

        </div>

        {/* RIGHT COLUMN: Interactive Ultra-Compact Lead Form */}
        <div className="md:col-span-7 p-3 sm:p-5 lg:p-6 bg-white flex flex-col justify-center overflow-y-auto">
          
          {submitted ? (
            <div className="text-center py-5 space-y-2 animate-in fade-in" id="popup-success-state">
              <div className="w-10 h-10 bg-emerald-100 text-emerald-700 rounded-full flex items-center justify-center mx-auto shadow-inner">
                <Check className="w-5 h-5 stroke-[2.5]" />
              </div>
              <div className="space-y-0.5">
                <h3 className="text-lg sm:text-xl font-serif text-stone-900 font-normal tracking-tight">
                  Application Received!
                </h3>
                <p className="text-[11px] sm:text-xs text-stone-600 max-w-xs mx-auto font-sans leading-tight">
                  Thank you, <strong className="text-stone-900">{formData.name}</strong>. Our Senior Advisor will connect with you shortly.
                </p>
              </div>

              <div className="pt-1.5">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-1.5 bg-stone-900 hover:bg-stone-800 text-white rounded-full text-xs font-bold transition-all cursor-pointer"
                >
                  Close Window
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-2 sm:space-y-3" id="popup-lead-form">
              
              {/* Header Title */}
              <div>
                <span className="text-[9px] font-bold text-amber-700 uppercase tracking-widest font-sans block">
                  ADMISSIONS OPEN
                </span>
                <h2 className="text-base sm:text-xl font-serif text-stone-900 font-normal tracking-tight leading-tight">
                  Start Your Transformation Journey
                </h2>
                <p className="text-[10px] sm:text-xs text-stone-500 font-sans mt-0.5 leading-tight">
                  Complete the form and our Transformation Advisor will contact you shortly.
                </p>
              </div>

              {error && (
                <div className="p-1.5 bg-rose-50 border border-rose-200 text-rose-700 text-[11px] rounded-lg font-sans">
                  {error}
                </div>
              )}

              {/* Full Name */}
              <div>
                <label className="block text-[9px] sm:text-[10px] font-bold text-stone-600 uppercase tracking-wider mb-0.5 font-sans">
                  FULL NAME <span className="text-amber-600">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Your full name"
                  className="w-full px-2.5 py-1.5 text-xs bg-[#F8F7F2] border border-stone-200/90 rounded-lg focus:bg-white focus:outline-none focus:ring-1 focus:ring-[#0D724D] focus:border-[#0D724D] transition-all font-sans text-stone-900"
                />
              </div>

              {/* Email & Phone Number (2 columns on mobile too!) */}
              <div className="grid grid-cols-2 gap-2 sm:gap-2.5">
                <div>
                  <label className="block text-[9px] sm:text-[10px] font-bold text-stone-600 uppercase tracking-wider mb-0.5 font-sans truncate">
                    EMAIL <span className="text-amber-600">*</span>
                  </label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="name@example.com"
                    className="w-full px-2.5 py-1.5 text-xs bg-[#F8F7F2] border border-stone-200/90 rounded-lg focus:bg-white focus:outline-none focus:ring-1 focus:ring-[#0D724D] focus:border-[#0D724D] transition-all font-sans text-stone-900"
                  />
                </div>
                <div>
                  <label className="block text-[9px] sm:text-[10px] font-bold text-stone-600 uppercase tracking-wider mb-0.5 font-sans truncate">
                    PHONE NUMBER <span className="text-amber-600">*</span>
                  </label>
                  <input
                    type="tel"
                    required
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="+91 98765 43210"
                    className="w-full px-2.5 py-1.5 text-xs bg-[#F8F7F2] border border-stone-200/90 rounded-lg focus:bg-white focus:outline-none focus:ring-1 focus:ring-[#0D724D] focus:border-[#0D724D] transition-all font-sans text-stone-900"
                  />
                </div>
              </div>

              {/* Current Status Compact Selection */}
              <div>
                <label className="block text-[9px] sm:text-[10px] font-bold text-stone-600 uppercase tracking-wider mb-1 font-sans">
                  CURRENT STATUS
                </label>
                <div className="flex flex-wrap gap-1 sm:gap-1.5 text-xs font-sans text-stone-800">
                  {statusOptions.map((opt) => {
                    const isChecked = formData.status === opt;
                    return (
                      <button
                        type="button"
                        key={opt} 
                        onClick={() => setFormData({ ...formData, status: opt })}
                        className={`flex items-center gap-1 px-2 py-0.5 sm:py-1 rounded-md text-[10px] sm:text-[11px] font-medium transition-all border cursor-pointer ${
                          isChecked 
                            ? 'bg-[#0D724D]/10 border-[#0D724D] text-[#0D724D] font-bold shadow-xs' 
                            : 'bg-[#F8F7F2] border-stone-200 text-stone-600 hover:border-stone-300'
                        }`}
                      >
                        <span className={`w-1.5 h-1.5 rounded-full ${isChecked ? 'bg-[#0D724D]' : 'bg-stone-300'}`} />
                        <span>{opt}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Interested Academy & City (2 columns on mobile too!) */}
              <div className="grid grid-cols-12 gap-2 sm:gap-2.5">
                <div className="col-span-7">
                  <label className="block text-[9px] sm:text-[10px] font-bold text-stone-600 uppercase tracking-wider mb-0.5 font-sans truncate">
                    INTERESTED ACADEMY
                  </label>
                  <div className="relative">
                    <select
                      value={formData.academy}
                      onChange={(e) => setFormData({ ...formData, academy: e.target.value })}
                      className="w-full appearance-none px-2.5 py-1.5 text-[10.5px] sm:text-xs bg-[#F8F7F2] border border-stone-200/90 rounded-lg focus:bg-white focus:outline-none focus:ring-1 focus:ring-[#0D724D] focus:border-[#0D724D] transition-all font-sans text-stone-900 pr-6 truncate"
                    >
                      {academyOptions.map((p) => (
                        <option key={p} value={p}>{p}</option>
                      ))}
                    </select>
                    <ChevronDown className="w-3 h-3 text-stone-500 absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none" />
                  </div>
                </div>

                <div className="col-span-5">
                  <label className="block text-[9px] sm:text-[10px] font-bold text-stone-600 uppercase tracking-wider mb-0.5 font-sans">
                    CITY
                  </label>
                  <input
                    type="text"
                    value={formData.city}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    placeholder="e.g. Bangalore"
                    className="w-full px-2.5 py-1.5 text-xs bg-[#F8F7F2] border border-stone-200/90 rounded-lg focus:bg-white focus:outline-none focus:ring-1 focus:ring-[#0D724D] focus:border-[#0D724D] transition-all font-sans text-stone-900"
                  />
                </div>
              </div>

              {/* Submit Application Button */}
              <div className="pt-1">
                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full py-2 px-4 bg-[#0D724D] hover:bg-[#0A5A3C] text-white font-bold rounded-lg text-xs flex items-center justify-center gap-1.5 shadow-sm hover:shadow transition-all duration-200 disabled:opacity-50 cursor-pointer"
                >
                  {submitting ? (
                    <span>Submitting Application...</span>
                  ) : (
                    <>
                      <span>Submit Application</span>
                      <ArrowRight className="w-3 h-3" />
                    </>
                  )}
                </button>
              </div>

            </form>
          )}

        </div>

      </div>

    </div>
  );
}
