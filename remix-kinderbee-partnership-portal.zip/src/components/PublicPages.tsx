import React, { useState, useEffect } from 'react';
import { 
  Award, Star, ArrowRight, Check, BookOpen, Clock, 
  MapPin, Phone, Mail, FileText, Download, MessageSquare, 
  Search, HelpCircle, ChevronRight, Briefcase, TrendingUp, Users, ShieldCheck, Sparkles, AlertCircle, Eye, List, ChevronDown, GraduationCap, Building2, Globe
} from 'lucide-react';
import { api } from '../utils/api';
import { BlogPost, FAQItem, SystemSettings } from '../types';
import LeadForms from './LeadForms';
import BrochureModal from './BrochureModal';
import { BeeGraduateMascot, Education3DCapGlobe, GrowthCoinsSchool } from './MascotGraphics';
import CBSEModelView from './school-models/CBSEModelView';
import IBModelView from './school-models/IBModelView';
import DegreeCollegeModelView from './school-models/DegreeCollegeModelView';

interface PublicPagesProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  settings: SystemSettings;
  pages: any[];
}

export default function PublicPages({ currentTab, setCurrentTab, settings, pages }: PublicPagesProps) {
  const [blogs, setBlogs] = useState<BlogPost[]>([]);
  const [faqs, setFaqs] = useState<FAQItem[]>([]);
  const [blogsLoading, setBlogsLoading] = useState(true);
  const [faqsLoading, setFaqsLoading] = useState(true);
  const [activeFaq, setActiveFaq] = useState<string | null>(null);
  const [activeFwaCategory, setActiveFwaCategory] = useState<'cert' | 'diploma' | 'prof' | 'lead' | 'care'>('diploma');
  const [activePartnershipTab, setActivePartnershipTab] = useState<'preschool' | 'cbse' | 'ib' | 'college'>('preschool');
  const [selectedBlog, setSelectedBlog] = useState<BlogPost | null>(null);
  const [blogSearch, setBlogSearch] = useState('');
  const [blogFilter, setBlogFilter] = useState('All');
  const [calcModel, setCalcModel] = useState<'preschool' | 'school' | 'college'>('preschool');
  const [calcBudget, setCalcBudget] = useState(25); // in Lakhs
  const [activeHeadingId, setActiveHeadingId] = useState<string>('');
  const [mobileTocOpen, setMobileTocOpen] = useState<boolean>(true);

  // Brochure modal state
  const [brochureOpen, setBrochureOpen] = useState(false);
  const [brochureTitle, setBrochureTitle] = useState('NTT Teacher Training & KIPS Franchise Brochure');

  // Find current page configuration for dynamic content & SEO
  const pageData = pages?.find(p => p.id === currentTab) || pages?.find(p => p.id === 'home');

  // Sync document head SEO parameters dynamically
  useEffect(() => {
    if (pageData) {
      document.title = pageData.metaTitle || pageData.title;
      
      let metaDesc = document.querySelector('meta[name="description"]');
      if (!metaDesc) {
        metaDesc = document.createElement('meta');
        metaDesc.setAttribute('name', 'description');
        document.head.appendChild(metaDesc);
      }
      metaDesc.setAttribute('content', pageData.metaDescription || pageData.subtitle);

      let metaKeywords = document.querySelector('meta[name="keywords"]');
      if (!metaKeywords) {
        metaKeywords = document.createElement('meta');
        metaKeywords.setAttribute('name', 'keywords');
        document.head.appendChild(metaKeywords);
      }
      metaKeywords.setAttribute('content', pageData.keywords || 'kinderbee, kips, preschool franchise, ntt teacher training');
    }
  }, [pageData]);

  // Load data from Express endpoints on mount
  useEffect(() => {
    async function loadData() {
      try {
        const blogsData = await api.getBlogs();
        setBlogs(blogsData);
      } catch (err) {
        console.error("Failed to load blogs:", err);
      } finally {
        setBlogsLoading(false);
      }

      try {
        const faqsData = await api.getFAQs();
        setFaqs(faqsData);
      } catch (err) {
        console.error("Failed to load faqs:", err);
      } finally {
        setFaqsLoading(false);
      }
    }
    loadData();
  }, [currentTab]);

  const handleConsultationCTA = () => {
    if (typeof window !== 'undefined' && window.openLeadPopup) {
      window.openLeadPopup();
    } else {
      setCurrentTab('partner-with-us');
      window.scrollTo({ top: 350, behavior: 'smooth' });
    }
  };

  const handleOpenBrochure = (title: string) => {
    setBrochureTitle(title);
    setBrochureOpen(true);
  };

  // Scroll spy listener to highlight active section in TOC as user scrolls
  useEffect(() => {
    if (!selectedBlog) return;
    const toc = getTableOfContents(selectedBlog.content);
    if (toc.length === 0) return;

    const handleScroll = () => {
      const scrollPosition = window.scrollY + 200;
      for (let i = toc.length - 1; i >= 0; i--) {
        const heading = toc[i];
        const el = document.getElementById(heading.id);
        if (el && el.offsetTop <= scrollPosition) {
          setActiveHeadingId(heading.id);
          break;
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();
    return () => window.removeEventListener('scroll', handleScroll);
  }, [selectedBlog]);

  const parseContentToParagraphs = (content: string) => {
    if (!content) return null;
    return content.split('\n\n').map((p, i) => {
      if (p.startsWith('## ')) {
        const text = p.replace('## ', '').trim();
        const id = text.toLowerCase().replace(/[^a-z0-9]+/g, '-');
        return (
          <h2 key={i} id={id} className="text-xl sm:text-2xl font-extrabold text-[#0F172A] mt-8 mb-4 font-display scroll-mt-28 border-b border-stone-200 pb-2 flex items-center gap-2">
            <span className="w-1.5 h-6 bg-[#E1007A] rounded-full inline-block"></span>
            <span>{text}</span>
          </h2>
        );
      }
      if (p.startsWith('### ')) {
        const text = p.replace('### ', '').trim();
        const id = text.toLowerCase().replace(/[^a-z0-9]+/g, '-');
        return (
          <h3 key={i} id={id} className="text-lg font-bold text-stone-800 mt-6 mb-3 font-display scroll-mt-28 flex items-center gap-2">
            <span className="w-1 h-4 bg-sky-500 rounded-full inline-block"></span>
            <span>{text}</span>
          </h3>
        );
      }
      if (p.startsWith('- ') || p.startsWith('* ')) {
        const items = p.split('\n');
        return (
          <ul key={i} className="list-disc pl-5 my-3 space-y-1.5 text-stone-700 text-sm sm:text-base">
            {items.map((item, j) => <li key={j}>{item.replace(/^[-*]\s+/, '')}</li>)}
          </ul>
        );
      }
      return <p key={i} className="text-stone-700 text-sm sm:text-base leading-relaxed mb-4 font-sans">{p}</p>;
    });
  };

  const getTableOfContents = (content: string) => {
    if (!content) return [];
    const headings: { text: string; id: string; level: number }[] = [];
    content.split('\n\n').forEach(p => {
      if (p.startsWith('## ')) {
        const text = p.replace('## ', '').trim();
        const id = text.toLowerCase().replace(/[^a-z0-9]+/g, '-');
        headings.push({ text, id, level: 2 });
      } else if (p.startsWith('### ')) {
        const text = p.replace('### ', '').trim();
        const id = text.toLowerCase().replace(/[^a-z0-9]+/g, '-');
        headings.push({ text, id, level: 3 });
      }
    });
    return headings;
  };

  // ==========================================
  // VIEW RENDERERS
  // ==========================================

  // --- 1. HOME VIEW (Pages 1 to 7) ---
  const renderHome = () => {
    const featuredBlogs = blogs.slice(0, 3);
    const homeFaqs = faqs.filter(f => f.section === 'home');

    return (
      <div className="space-y-20 animate-fade-in" id="home-view">
        
        {/* Page 1 & 2: Hero Section - Dark Cinematic Video Background Banner */}
        <section className="relative w-full min-h-[560px] sm:min-h-[620px] lg:min-h-[680px] flex items-center justify-center overflow-hidden bg-[#0A0D14] text-white py-16 sm:py-24 px-4 border-b border-stone-900" id="home-hero">
          
          {/* Ambient Video Background */}
          <video
            autoPlay
            loop
            muted
            playsInline
            className="absolute inset-0 w-full h-full object-cover opacity-45 pointer-events-none scale-105 select-none z-0"
            poster="https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&q=80&w=1920"
          >
            <source src="https://assets.mixkit.co/videos/preview/mixkit-curving-flow-of-golden-particles-in-the-dark-32777-large.mp4" type="video/mp4" />
            <source src="https://assets.mixkit.co/videos/preview/mixkit-abstract-green-and-gold-flowing-lines-41584-large.mp4" type="video/mp4" />
          </video>

          {/* Cinematic Gradient Overlays for Contrast & Depth */}
          <div className="absolute inset-0 bg-gradient-to-b from-[#0A0D14]/90 via-[#0A0D14]/30 to-[#0A0D14] pointer-events-none z-0" />
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-amber-500/10 via-transparent to-[#0A0D14]/90 pointer-events-none z-0" />

          <div className="max-w-5xl mx-auto text-center space-y-6 sm:space-y-7 relative z-10">
            
            {/* Top Eyebrow Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-amber-400/10 border border-amber-400/30 rounded-full text-xs text-amber-300 font-bold tracking-[0.2em] uppercase font-display backdrop-blur-md">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>THE FUTURE OF EDUCATION STARTS HERE</span>
            </div>
            
            {/* Main Headline with Serif Italic Accent (Terranext Styling) */}
            <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold text-white tracking-tight leading-[1.12] font-display max-w-4xl mx-auto">
              Reimagine Education.
              <span className="block font-serif italic text-transparent bg-clip-text bg-gradient-to-r from-[#FFE072] via-[#F59E0B] to-[#F79F33] mt-1 sm:mt-2 drop-shadow-md">
                Transform Tomorrow.
              </span>
            </h1>

            {/* Subtitle */}
            <p className="text-stone-300 text-sm sm:text-base md:text-lg leading-relaxed font-sans max-w-2xl mx-auto font-normal">
              A future-ready education ecosystem empowering schools, educators and young minds through innovation, excellence and transformative learning.
            </p>

            {/* Primary & Secondary Call-To-Action Buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-2">
              <button
                type="button"
                onClick={() => {
                  const el = document.getElementById('kips-value-proposition');
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                  else setCurrentTab('about');
                }}
                className="w-full sm:w-auto px-8 py-3.5 sm:px-9 sm:py-4 bg-white hover:bg-stone-100 text-stone-950 font-extrabold rounded-full text-sm sm:text-base transition-all shadow-xl hover:shadow-2xl hover:scale-105 active:scale-95 cursor-pointer flex items-center justify-center gap-2 font-display"
              >
                <span>Explore KIPS</span>
                <ArrowRight className="w-4 h-4 text-stone-900" />
              </button>
              <button
                type="button"
                onClick={handleConsultationCTA}
                className="w-full sm:w-auto px-8 py-3.5 sm:px-9 sm:py-4 bg-white/10 hover:bg-white/20 text-white border border-white/25 hover:border-white/45 backdrop-blur-md font-bold rounded-full text-sm sm:text-base transition-all hover:scale-105 active:scale-95 cursor-pointer text-center font-display"
              >
                Talk to Our Experts
              </button>
            </div>

            {/* Trust Highlights */}
            <div className="flex flex-wrap items-center justify-center gap-6 sm:gap-10 pt-4 text-xs font-semibold text-stone-300/90 font-sans border-t border-white/10">
              <span className="flex items-center gap-2"><Check className="w-4 h-4 text-amber-400" /> NEP 2020 Aligned</span>
              <span className="flex items-center gap-2"><Check className="w-4 h-4 text-amber-400" /> 0% Royalty Model</span>
              <span className="flex items-center gap-2"><Check className="w-4 h-4 text-amber-400" /> 30+ Years Legacy</span>
            </div>

          </div>
        </section>

        {/* Page 2: KIPS Value Proposition Banner */}
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" id="kips-value-proposition">
          <div className="bg-gradient-to-br from-[#0F172A] via-[#1E293B] to-[#0F172A] text-white rounded-3xl p-8 sm:p-12 shadow-2xl relative overflow-hidden space-y-8 border border-slate-800">
            
            {/* Top Hook */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1 bg-amber-400/10 border border-amber-400/30 rounded-full text-xs text-amber-300 font-bold uppercase tracking-wider font-display">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>ZERO ROYALTY. GLOBAL STANDARDS. COMPLETE SUPPORT.</span>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
              <div className="lg:col-span-8 space-y-4">
                <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold font-display !text-white tracking-tight leading-tight">
                  Build the Future of Education with KIPS
                </h2>
                
                <div className="text-lg font-bold text-[#E1007A] font-display">
                  Transform Schools. Empower Educators. Shape Futures.
                </div>

                <p className="text-slate-300 text-sm sm:text-base leading-relaxed font-sans max-w-2xl">
                  The <span className="font-bold text-white">Kinderbee Integrated Partnership System (KIPS)</span> empowers entrepreneurs and educational institutions to build, launch and grow future-ready schools with proven academic systems, expert support and innovative learning solutions.
                </p>

                <div className="p-3 bg-slate-800/80 rounded-xl border border-slate-700 text-xs text-slate-200 font-medium font-sans flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
                  <span>🛡 Zero-Royalty Partnership • End-to-End School Support • Finnish-Inspired Learning</span>
                </div>

                <div className="flex flex-wrap gap-3 pt-2">
                  <button
                    onClick={handleConsultationCTA}
                    className="px-7 py-3.5 bg-[#E1007A] hover:bg-[#c20068] text-white font-bold rounded-full text-xs sm:text-sm transition-all shadow-md cursor-pointer flex items-center gap-2"
                  >
                    <span>Book a Free Consultation</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setCurrentTab('partnerships')}
                    className="px-7 py-3.5 border border-slate-600 hover:border-white text-white font-bold rounded-full text-xs sm:text-sm transition-all cursor-pointer"
                  >
                    Explore KIPS Models
                  </button>
                </div>
              </div>

              {/* 3 Metric Counters */}
              <div className="lg:col-span-4 bg-slate-900/90 p-6 rounded-2xl border border-slate-700 space-y-5">
                <div className="border-b border-slate-800 pb-3">
                  <div className="text-3xl sm:text-4xl font-black text-[#E1007A] font-display">0%</div>
                  <div className="text-xs text-slate-300 font-bold uppercase tracking-wider font-sans mt-0.5">Royalty Fees</div>
                  <p className="text-[11px] text-slate-400 font-sans mt-1">Keep 100% of student fee revenues. Fast-track break-even.</p>
                </div>

                <div className="border-b border-slate-800 pb-3">
                  <div className="text-3xl sm:text-4xl font-black text-[#F79F33] font-display">30+</div>
                  <div className="text-xs text-slate-300 font-bold uppercase tracking-wider font-sans mt-0.5">Years Legacy</div>
                  <p className="text-[11px] text-slate-400 font-sans mt-1">Deep institutional knowledge across preschool and K-12 systems.</p>
                </div>

                <div>
                  <div className="text-3xl sm:text-4xl font-black text-emerald-400 font-display">100%</div>
                  <div className="text-xs text-slate-300 font-bold uppercase tracking-wider font-sans mt-0.5">Partnership Support</div>
                  <p className="text-[11px] text-slate-400 font-sans mt-1">From land feasibility to admissions marketing & teacher training.</p>
                </div>
              </div>
            </div>

          </div>
        </section>

        {/* Page 3 & 4: Our Philosophy & Ecosystem */}
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12" id="philosophy-section">
          
          {/* Top Mascot with Philosophy Statement */}
          <div className="bg-white rounded-3xl border border-stone-200 p-8 sm:p-12 shadow-sm relative space-y-6">
            <div className="flex flex-col sm:flex-row items-center gap-6">
              <BeeGraduateMascot className="w-28 h-28 shrink-0" subtitle="Kinderbee Mascot" />
              
              <div className="space-y-3 text-center sm:text-left">
                <span className="text-xs font-bold text-[#E1007A] uppercase tracking-wider font-display">Our Philosophy & Mission</span>
                <h2 className="text-2xl sm:text-3xl font-extrabold text-[#0F172A] tracking-tight font-display">
                  Transforming Learning Through Integrated Educational Systems
                </h2>
              </div>
            </div>

            <div className="space-y-4 text-stone-700 text-sm sm:text-base leading-relaxed font-sans border-t border-stone-100 pt-6">
              <p>
                The <strong className="text-stone-950">Kinderbee Integrated Partnership System (KIPS)</strong> is a trusted school education and preschool development partner, dedicated to building high-quality, future-ready learning environments across India. With expertise in early childhood education, preschool management, curriculum development, and teacher training, we help educational entrepreneurs create successful and sustainable schools.
              </p>
              <p>
                Our <strong className="text-[#7E22CE]">NTT (Nursery Teacher Training) Program</strong> equips aspiring and working educators with practical skills, modern teaching methodologies, and child-centric approaches for effective early years education. From preschool teacher training and curriculum support to school development and academic guidance, Kinderbee provides an integrated ecosystem designed to empower educators and transform learning.
              </p>
            </div>

            <div className="pt-2 flex flex-wrap gap-4 items-center">
              <button
                onClick={() => {
                  setCurrentTab('fwa');
                  window.scrollTo({ top: 350, behavior: 'smooth' });
                }}
                className="px-6 py-3 bg-[#7E22CE] hover:bg-[#6b1dae] text-white font-bold rounded-full text-xs sm:text-sm transition-all shadow cursor-pointer flex items-center gap-2"
              >
                <span>Explore Our Programs → NTT Teacher Training</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <button
                onClick={() => handleOpenBrochure('NTT Teacher Training Curriculum Brochure')}
                className="px-6 py-3 border border-stone-300 hover:bg-stone-50 text-stone-800 font-bold rounded-full text-xs sm:text-sm transition-all cursor-pointer flex items-center gap-2"
              >
                <Download className="w-4 h-4 text-[#E1007A]" />
                <span>Download NTT Brochure</span>
              </button>
            </div>
          </div>

          {/* Page 4: One Ecosystem, Countless Opportunities (3 Key Pillars) */}
          <div className="space-y-8">
            <div className="text-center max-w-3xl mx-auto space-y-2">
              <span className="text-xs font-bold text-[#E1007A] uppercase tracking-wider font-display">One Ecosystem, Infinite Possibilities</span>
              <h2 className="text-3xl font-extrabold text-[#0F172A] tracking-tight font-display">
                Comprehensive Support Across Every Stage of Education
              </h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              
              {/* Pillar 01 */}
              <div className="bg-white p-8 rounded-3xl border border-stone-200 hover:border-[#E1007A]/60 shadow-sm hover:shadow-xl transition-all flex flex-col justify-between space-y-6 group">
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-xs font-extrabold text-[#E1007A] uppercase tracking-wider font-display">01 Preschool Franchise</span>
                    <span className="w-8 h-8 rounded-full bg-pink-50 text-[#E1007A] flex items-center justify-center font-bold text-xs">01</span>
                  </div>
                  <h3 className="text-xl font-extrabold text-stone-950 font-display group-hover:text-[#E1007A] transition-colors">
                    Start a Preschool Franchise in India
                  </h3>
                  <p className="text-stone-600 text-xs sm:text-sm leading-relaxed font-sans">
                    Launch a zero-royalty preschool franchise with a NEP 2020-aligned, play-based curriculum, comprehensive school setup support and modern early childhood education solutions.
                  </p>
                </div>
                <button 
                  onClick={() => {
                    setCurrentTab('partnerships');
                    window.scrollTo({ top: 350, behavior: 'smooth' });
                  }} 
                  className="px-5 py-2.5 bg-pink-50 text-[#E1007A] hover:bg-[#E1007A] hover:text-white rounded-xl text-xs font-bold transition-all flex items-center justify-between cursor-pointer"
                >
                  <span>Explore Franchise</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>

              {/* Pillar 02 */}
              <div className="bg-white p-8 rounded-3xl border border-stone-200 hover:border-[#7E22CE]/60 shadow-sm hover:shadow-xl transition-all flex flex-col justify-between space-y-6 group">
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-xs font-extrabold text-[#7E22CE] uppercase tracking-wider font-display">02 FinnishWay Academy</span>
                    <span className="w-8 h-8 rounded-full bg-purple-50 text-[#7E22CE] flex items-center justify-center font-bold text-xs">02</span>
                  </div>
                  <h3 className="text-xl font-extrabold text-stone-950 font-display group-hover:text-[#7E22CE] transition-colors">
                    NTT & Preschool Teacher Training
                  </h3>
                  <p className="text-stone-600 text-xs sm:text-sm leading-relaxed font-sans">
                    Advance your career with professional NTT (Nursery Teacher Training), ECCE and preschool teacher training programs designed around modern, child-centric and Finnish-inspired teaching methodologies.
                  </p>
                </div>
                <button 
                  onClick={() => {
                    setCurrentTab('fwa');
                    window.scrollTo({ top: 350, behavior: 'smooth' });
                  }} 
                  className="px-5 py-2.5 bg-purple-50 text-[#7E22CE] hover:bg-[#7E22CE] hover:text-white rounded-xl text-xs font-bold transition-all flex items-center justify-between cursor-pointer"
                >
                  <span>Explore NTT Teacher Training</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>

              {/* Pillar 03 */}
              <div className="bg-white p-8 rounded-3xl border border-stone-200 hover:border-[#F97316]/60 shadow-sm hover:shadow-xl transition-all flex flex-col justify-between space-y-6 group">
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-xs font-extrabold text-[#F97316] uppercase tracking-wider font-display">03 Investor Opportunities</span>
                    <span className="w-8 h-8 rounded-full bg-orange-50 text-[#F97316] flex items-center justify-center font-bold text-xs">03</span>
                  </div>
                  <h3 className="text-xl font-extrabold text-stone-950 font-display group-hover:text-[#F97316] transition-colors">
                    Invest in Education
                  </h3>
                  <p className="text-stone-600 text-xs sm:text-sm leading-relaxed font-sans">
                    Explore strategic investment opportunities in the education sector with Kinderbee. Partner with a growing education ecosystem offering scalable preschool, CBSE/IB school development, teacher training, and education business models, backed by structured systems and long-term support.
                  </p>
                </div>
                <button 
                  onClick={() => {
                    setCurrentTab('investors');
                    window.scrollTo({ top: 350, behavior: 'smooth' });
                  }} 
                  className="px-5 py-2.5 bg-orange-50 text-[#F97316] hover:bg-[#F97316] hover:text-white rounded-xl text-xs font-bold transition-all flex items-center justify-between cursor-pointer"
                >
                  <span>Explore Investment Opportunities</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>

            </div>
          </div>

        </section>

        {/* Page 5 & 6: Your Journey with KIPS (6 Steps Process with 3D Assets & Mascot) */}
        <section className="bg-stone-100 py-16 border-y border-stone-200" id="journey-roadmap">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
            
            <div className="text-center max-w-2xl mx-auto space-y-3">
              <span className="text-xs font-bold text-[#E1007A] uppercase tracking-wider font-display font-semibold">Your Journey With KIPS</span>
              <h2 className="text-3xl sm:text-4xl font-extrabold text-[#0F172A] tracking-tight font-display">
                6 Steps to Launching a Successful Institution
              </h2>
              <p className="text-stone-500 text-xs sm:text-sm font-sans">
                Our proven partnership framework guides you seamlessly from your initial vision to grand opening and sustainable growth.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-6 relative">
              
              <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm relative space-y-2">
                <div className="w-7 h-7 rounded-full bg-[#E1007A] text-white flex items-center justify-center text-xs font-bold mb-2">1</div>
                <h4 className="font-bold text-stone-900 text-sm font-display">Initial Query</h4>
                <p className="text-stone-500 text-xs leading-relaxed font-sans">
                  Discuss your vision, budget, territory choices, and school format.
                </p>
              </div>

              <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm relative space-y-2">
                <div className="w-7 h-7 rounded-full bg-[#F97316] text-white flex items-center justify-center text-xs font-bold mb-2">2</div>
                <h4 className="font-bold text-stone-900 text-sm font-display">Feasibility & Location</h4>
                <p className="text-stone-500 text-xs leading-relaxed font-sans">
                  Evaluate local catchment demand, competitor density, and space layout.
                </p>
              </div>

              <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm relative space-y-2">
                <div className="w-7 h-7 rounded-full bg-[#FFD200] text-stone-900 flex items-center justify-center text-xs font-bold mb-2">3</div>
                <h4 className="font-bold text-stone-900 text-sm font-display">Architecture & Blueprint</h4>
                <p className="text-stone-500 text-xs leading-relaxed font-sans">
                  Generate customized floor plans, smart classrooms, and play zones.
                </p>
              </div>

              <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm relative space-y-2">
                <div className="w-7 h-7 rounded-full bg-[#7E22CE] text-white flex items-center justify-center text-xs font-bold mb-2">4</div>
                <h4 className="font-bold text-stone-900 text-sm font-display">Agreement (0% Royalty)</h4>
                <p className="text-stone-500 text-xs leading-relaxed font-sans">
                  Formalize licensing terms with complete zero royalty fee protection.
                </p>
              </div>

              <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm relative space-y-2">
                <div className="w-7 h-7 rounded-full bg-emerald-600 text-white flex items-center justify-center text-xs font-bold mb-2">5</div>
                <h4 className="font-bold text-stone-900 text-sm font-display">Staff Training & Setup</h4>
                <p className="text-stone-500 text-xs leading-relaxed font-sans">
                  Train educators via FinnishWay Academy and execute admission campaigns.
                </p>
              </div>

              <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm relative space-y-2">
                <div className="w-7 h-7 rounded-full bg-[#E1007A] text-white flex items-center justify-center text-xs font-bold mb-2">6</div>
                <h4 className="font-bold text-stone-900 text-sm font-display">Ongoing Growth</h4>
                <p className="text-stone-500 text-xs leading-relaxed font-sans">
                  Maintain excellence with academic audits, digital CRM, and mentorship.
                </p>
              </div>

            </div>

            <div className="bg-white p-6 rounded-2xl border border-stone-200 flex flex-col sm:flex-row items-center justify-between gap-4 max-w-4xl mx-auto shadow-sm">
              <div className="flex items-center gap-3">
                <ShieldCheck className="w-8 h-8 text-emerald-600 shrink-0" />
                <div className="text-xs text-stone-700 font-sans">
                  <strong className="text-stone-900 font-display block text-sm">Full Institutional Autonomy</strong>
                  No hidden operational surprises. We provide strict pre-construction audits to safeguard your capital.
                </div>
              </div>
              <button 
                onClick={handleConsultationCTA} 
                className="px-6 py-2.5 bg-[#0F172A] hover:bg-[#1E293B] text-white font-bold rounded-full text-xs transition-all shrink-0 cursor-pointer"
              >
                Begin Your Journey
              </button>
            </div>

          </div>
        </section>

        {/* Dynamic Blogs Highlights Section */}
        {featuredBlogs.length > 0 && (
          <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
            <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4">
              <div className="space-y-3 max-w-xl">
                <span className="text-xs font-bold text-[#E1007A] uppercase tracking-wider font-display font-semibold">Insights & Industry Reports</span>
                <h2 className="text-3xl font-extrabold text-[#0F172A] tracking-tight font-display">
                  Latest from Educational Thought Leaders
                </h2>
              </div>
              <button onClick={() => setCurrentTab('blogs')} className="px-5 py-2.5 border border-stone-300 rounded-full text-xs font-bold hover:bg-stone-50 cursor-pointer flex items-center gap-1">
                View All Articles <ArrowRight className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {featuredBlogs.map((blog) => (
                <div key={blog.id} className="bg-white rounded-2xl border border-stone-200/80 overflow-hidden shadow-sm hover:shadow-md transition-all group flex flex-col h-full">
                  <div className="h-48 bg-stone-100 overflow-hidden relative">
                    <img referrerPolicy="no-referrer" src={blog.image} alt={blog.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                    <span className="absolute top-4 left-4 px-2.5 py-1 bg-[#0F172A] text-white text-[10px] font-bold uppercase rounded">
                      {blog.category}
                    </span>
                  </div>
                  <div className="p-6 flex-1 flex flex-col justify-between">
                    <div className="space-y-2">
                      <div className="flex items-center gap-3 text-stone-400 text-[10px] font-semibold uppercase">
                        <span>{blog.author}</span>
                        <span>•</span>
                        <span>{blog.readTime}</span>
                      </div>
                      <h3 className="font-bold text-stone-950 text-base font-display leading-snug line-clamp-2">
                        {blog.title}
                      </h3>
                      <p className="text-stone-600 text-xs font-sans leading-relaxed line-clamp-3">
                        {blog.excerpt}
                      </p>
                    </div>
                    <button onClick={() => { setSelectedBlog(blog); setCurrentTab('blogs'); }} className="text-xs font-bold text-[#E1007A] hover:text-[#c20068] mt-4 flex items-center gap-1 cursor-pointer">
                      Read Full Report <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Page 7: FAQ Accordion Section */}
        {homeFaqs.length > 0 && (
          <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8" id="faq-section">
            <div className="text-center space-y-3">
              <span className="text-xs font-bold text-[#E1007A] uppercase tracking-wider font-display">Got Questions?</span>
              <h2 className="text-3xl font-extrabold text-[#0F172A] tracking-tight font-display">Frequently Asked Questions</h2>
            </div>

            <div className="space-y-3" id="faq-accordion">
              {homeFaqs.map((faq) => {
                const isOpen = activeFaq === faq.id;
                return (
                  <div key={faq.id} className="bg-white rounded-xl border border-stone-200/80 overflow-hidden transition-all shadow-sm">
                    <button
                      onClick={() => setActiveFaq(isOpen ? null : faq.id)}
                      className="w-full px-6 py-4 text-left flex justify-between items-center hover:bg-stone-50 cursor-pointer"
                    >
                      <span className="font-bold text-stone-900 text-sm sm:text-base font-display pr-4">{faq.question}</span>
                      <ChevronRight className={`w-5 h-5 text-stone-400 shrink-0 transform transition-transform ${isOpen ? 'rotate-90 text-[#E1007A]' : ''}`} />
                    </button>
                    {isOpen && (
                      <div className="px-6 pb-5 pt-1 text-xs sm:text-sm text-stone-600 font-sans border-t border-stone-100 leading-relaxed bg-stone-50/40">
                        {faq.answer}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </section>
        )}

        {/* Page 7: CTA Banner Section */}
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-10">
          <div className="bg-gradient-to-r from-[#0F172A] to-[#1E293B] text-white rounded-3xl p-8 sm:p-12 relative overflow-hidden shadow-xl text-center space-y-6">
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold font-display !text-white tracking-tight leading-tight">
              Ready to Start Your Education Journey?
            </h2>
            <p className="text-slate-200 text-sm sm:text-base max-w-3xl mx-auto font-sans leading-relaxed">
              Connect with Kinderbee, India’s trusted education and school development partner. Explore zero-royalty preschool franchise opportunities, CBSE school setup, NTT teacher training programs, preschool teacher training, and complete school education solutions designed for long-term growth and success.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center pt-2">
              <button 
                onClick={handleConsultationCTA} 
                className="px-8 py-3.5 bg-[#E1007A] hover:bg-[#c20068] text-white text-sm font-bold rounded-full transition-all shadow-md cursor-pointer flex items-center justify-center gap-2"
              >
                <span>Book a Free Consultation</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <button 
                onClick={() => handleOpenBrochure('NTT Teacher Training & Preschool Franchise Guide')}
                className="px-8 py-3.5 border border-stone-600 hover:border-white text-white text-sm font-bold rounded-full transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                <Download className="w-4 h-4 text-amber-400" />
                <span>Download NTT Teacher Training Brochure</span>
              </button>
            </div>
          </div>
        </section>

      </div>
    );
  };

  // --- 2. ABOUT KINDERBEE VIEW (Pages 8 & 9) ---
  const renderAbout = () => {
    const preschoolPillars = [
      {
        title: 'Play-Based Learning',
        desc: 'Engaging activities that develop creativity, curiosity and confidence.'
      },
      {
        title: 'Finnish-Inspired Curriculum',
        desc: 'Modern early learning practices focused on holistic child development.'
      },
      {
        title: 'Expert Teacher Training',
        desc: 'Professional preschool teacher training and NTT programs that empower educators with effective teaching methodologies.'
      },
      {
        title: 'Holistic Development',
        desc: "Supporting children's cognitive, social, emotional, physical and language development."
      },
      {
        title: 'Safe & Nurturing Environment',
        desc: 'Creating a welcoming preschool environment where every child feels valued and encouraged.'
      }
    ];

    const galleryPhotos = [
      {
        url: 'https://images.unsplash.com/photo-1503676260728-1c00da094a0b?auto=format&fit=crop&q=80&w=800',
        title: 'Interactive Playroom'
      },
      {
        url: 'https://images.unsplash.com/photo-1587654780291-39c9404d746b?auto=format&fit=crop&q=80&w=800',
        title: 'Creative Art Studio'
      },
      {
        url: 'https://images.unsplash.com/photo-1577896851231-70ef18881754?auto=format&fit=crop&q=80&w=800',
        title: 'Outdoor Play Garden'
      },
      {
        url: 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&q=80&w=800',
        title: 'STEM Discovery Lab'
      }
    ];

    return (
      <div className="space-y-16 py-8 animate-fade-in" id="about-view">
        
        {/* Top Header */}
        <div className="max-w-4xl mx-auto text-center space-y-4">
          <span className="text-xs font-bold text-[#E1007A] uppercase tracking-wider font-display">OUR JOURNEY & CORE MISSION</span>
          <h1 className="text-4xl sm:text-5xl font-extrabold text-stone-900 font-display">
            Nurturing Young Minds. Shaping Bright Futures.
          </h1>
          <p className="text-stone-600 text-sm sm:text-base leading-relaxed font-sans max-w-2xl mx-auto">
            Kinderbee Preschool is committed to delivering high-quality early childhood education through play-based learning, innovative teaching practices, and a child-centric approach. We empower children, educators, and preschool entrepreneurs to build a strong foundation for lifelong learning.
          </p>
        </div>

        {/* Three Decades of Educational Excellence */}
        <section className="max-w-5xl mx-auto bg-white p-8 sm:p-12 rounded-3xl border border-stone-200 shadow-sm grid grid-cols-1 md:grid-cols-2 gap-10 items-center">
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-[#E1007A] font-bold text-xs uppercase tracking-wider">
              <Award className="w-5 h-5 text-[#F97316]" />
              <span>Three Decades of Educational Excellence</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-stone-950 font-display">
              30+ Years in Education Sector
            </h2>
            <p className="text-stone-600 text-sm leading-relaxed font-sans">
              With a commitment to early childhood education, Kinderbee Preschool creates nurturing, engaging and future-ready learning environments where children can learn, explore and grow. Our approach combines play-based learning, child-centric teaching, Finnish-inspired education and NEP 2020-aligned practices to give every child a strong foundation for lifelong learning.
            </p>
            <div className="pt-2 flex flex-wrap gap-4 text-xs text-stone-600 font-bold">
              <span className="flex items-center gap-1.5"><Check className="w-4 h-4 text-emerald-600" /> NEP 2020 Aligned</span>
              <span className="flex items-center gap-1.5"><Check className="w-4 h-4 text-emerald-600" /> Finnish-Inspired Learning</span>
              <span className="flex items-center gap-1.5"><Check className="w-4 h-4 text-emerald-600" /> Child-Centric Education</span>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="font-extrabold text-stone-900 text-base font-display">
              What Makes Kinderbee Preschool Different?
            </h3>
            <div className="space-y-3">
              {preschoolPillars.map((pillar, idx) => (
                <div key={idx} className="flex items-start gap-3 bg-stone-50 p-3.5 rounded-xl border border-stone-200/60">
                  <span className="w-6 h-6 rounded-full bg-[#E1007A]/10 text-[#E1007A] flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
                    {idx + 1}
                  </span>
                  <div>
                    <strong className="text-stone-900 text-xs block font-display">{pillar.title}</strong>
                    <p className="text-stone-600 text-xs font-sans mt-0.5">{pillar.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Photo Gallery Grid */}
        <section className="max-w-6xl mx-auto space-y-6">
          <div className="text-center space-y-2">
            <h2 className="text-2xl font-bold font-display">Inside Kinderbee Learning Spaces</h2>
            <p className="text-stone-500 text-xs font-sans">Designed for safety, creative curiosity, and active sensory engagement.</p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {galleryPhotos.map((photo, idx) => (
              <div key={idx} className="relative rounded-2xl overflow-hidden shadow-sm group aspect-[4/3]">
                <img referrerPolicy="no-referrer" src={photo.url} alt={photo.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"></div>
                <span className="absolute bottom-3 left-3 text-white text-xs font-bold font-sans">{photo.title}</span>
              </div>
            ))}
          </div>
        </section>

        {/* Core Integration Scope Details */}
        <section className="max-w-7xl mx-auto space-y-8">
          <div className="text-center">
            <h2 className="text-2xl font-bold font-display">Our Complete Integration Scope</h2>
            <p className="text-stone-500 text-xs mt-1 font-sans">We handle multiple vendor layers, giving you one unified, hassle-free partner experience.</p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              'Preschool Curriculum', 'Teacher Training & Certification', 'School Infrastructure Planning', 
              'Branding & Digital Designs', 'Admissions Launch Plan', 'Parent Engagement Apps',
              'Continuous Academic Audits', 'School ERP Softwares', 'Teacher Recruitment',
              'Leadership Development', 'ECCE Compliance Support', 'Quality Assurance Checklists'
            ].map((item, idx) => (
              <div key={idx} className="bg-white p-4 rounded-xl border border-stone-200 text-center flex flex-col items-center justify-center space-y-2">
                <span className="w-2 h-2 rounded-full bg-[#E1007A]"></span>
                <span className="text-stone-800 text-xs font-bold font-sans">{item}</span>
              </div>
            ))}
          </div>
        </section>

        {/* CTA Banner */}
        <section className="max-w-4xl mx-auto bg-white p-8 rounded-3xl border border-stone-200 text-center space-y-4 shadow-sm">
          <h3 className="text-xl font-bold text-stone-900 font-display">Start Your Education Business with Confidence</h3>
          <p className="text-xs text-stone-600 leading-relaxed font-sans max-w-lg mx-auto">
            Whether you're planning a Preschool Franchise, CBSE School, IB School, Degree College, or a Complete School Setup, KIPS provides the systems, support, and zero-royalty structure to succeed.
          </p>
          <div className="flex justify-center gap-3 pt-2">
            <button onClick={handleConsultationCTA} className="px-6 py-2.5 bg-[#E1007A] hover:bg-[#c20068] text-white text-xs font-bold rounded-full transition-all cursor-pointer">
              Speak with our Franchise Advisors
            </button>
          </div>
        </section>

      </div>
    );
  };

  // --- 3. FRANCHISE & PARTNERSHIPS VIEW (Pages 10 to 17) ---
  const renderPartnerships = () => {
    const deliverables = [
      { name: 'Official Brand License', desc: 'Full authority to operate under the Kinderbee brand in your designated territory.' },
      { name: 'Custom Local Curriculum', desc: 'Integrated Finnish-ECCE & NEP 2020 age-graded syllabus for playgroup to UKG.' },
      { name: 'Staff Recruitment Guides', desc: 'Standardized job profiles, screening tests, and interview scorecards for educators.' },
      { name: 'Comprehensive Training', desc: 'Continuous teacher upskilling with FinnishWay Academy certificates and mentorship.' },
      { name: 'School Design Blueprint', desc: 'Architectural classroom layouts, color palette guidelines, and child-safe material lists.' },
      { name: 'SEO Micro-Websites', desc: 'Dedicated digital landing web pages optimized for regional parent search discovery.' },
      { name: 'Admissions Playbooks', desc: 'Lead inquiry scripts, parent demo kits, and seasonal enrollment drive strategies.' },
      { name: 'School Management ERP', desc: 'Cloud student records, digital attendance, fee invoicing, and parent app integration.' },
      { name: 'Continuous Quality Audits', desc: 'Termly academic visits and instructional audits to guarantee premium standards.' },
      { name: 'Franchise Operations Manual', desc: 'Complete day-to-day administrative guidelines and safety protocols.' },
      { name: 'Monthly Marketing Campaigns', desc: 'Ready-to-post social media assets, flyers, banners, and digital marketing support.' },
      { name: 'Mentorship Advisory Support', desc: 'Direct advisory line with experienced senior education directors and analysts.' }
    ];

    const preschoolFocusItems = [
      'Play-Based Learning',
      'NEP 2020-Aligned Curriculum',
      'Experiential Early Childhood Education',
      'Holistic Child Development',
      'STEM & Activity-Based Learning',
      'Social & Emotional Learning',
      'Life Skills Development',
      'Finnish-Inspired Early Learning'
    ];

    return (
      <div className="space-y-16 py-8 animate-fade-in" id="partnerships-view">
        
        {/* Model Navigation Switcher Bar */}
        <div className="max-w-4xl mx-auto flex flex-wrap justify-center gap-2 p-1.5 bg-stone-100 rounded-full border border-stone-200">
          {[
            { id: 'preschool', label: 'Preschool Franchise (Pages 10-11)' },
            { id: 'cbse', label: 'CBSE School Setup (Pages 12-13)' },
            { id: 'ib', label: 'IB School Setup (Pages 14-15)' },
            { id: 'college', label: 'Degree College Setup (Pages 16-17)' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActivePartnershipTab(tab.id as any)}
              className={`px-5 py-2.5 text-xs font-extrabold rounded-full transition-all cursor-pointer ${
                activePartnershipTab === tab.id
                  ? 'bg-[#E1007A] text-white shadow-md'
                  : 'text-stone-700 hover:text-stone-900 hover:bg-stone-200/60'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Model 1: Preschool Franchise View */}
        {activePartnershipTab === 'preschool' && (
          <div className="space-y-16 animate-fade-in">
            {/* Header */}
            <div className="max-w-4xl mx-auto text-center space-y-4">
              <span className="text-xs font-bold text-[#E1007A] uppercase tracking-wider font-display">Preschool Franchise Opportunity</span>
              <h1 className="text-4xl sm:text-5xl font-extrabold text-stone-900 font-display">
                Why Partner with Kinderbee Franchise
              </h1>
              <p className="text-stone-600 text-sm sm:text-base leading-relaxed max-w-2xl mx-auto font-sans">
                Establish a thriving early learning center in your territory with 100% Zero Royalty fees, proven Finnish-inspired curriculum frameworks, and comprehensive pre-launch to ongoing setup support.
              </p>
            </div>

            {/* Core Preschool Education Focus (Page 11) */}
            <section className="max-w-5xl mx-auto bg-white rounded-3xl border border-stone-200 p-8 sm:p-12 shadow-sm space-y-6">
              <div className="text-center space-y-2">
                <span className="text-xs font-bold text-[#E1007A] uppercase tracking-wider font-display">Pedagogical Framework</span>
                <h2 className="text-2xl sm:text-3xl font-extrabold text-stone-950 font-display">Core Preschool Education Focus</h2>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
                {preschoolFocusItems.map((item, idx) => (
                  <div key={idx} className="bg-pink-50/50 p-4 rounded-xl border border-pink-100 flex items-center gap-2.5">
                    <Sparkles className="w-4 h-4 text-[#E1007A] shrink-0" />
                    <span className="text-xs font-bold text-stone-900 font-sans">{item}</span>
                  </div>
                ))}
              </div>
            </section>

            {/* What You Receive - 12 Deliverables Grid */}
            <section className="max-w-6xl mx-auto space-y-8">
              <div className="text-center max-w-2xl mx-auto space-y-2">
                <span className="text-xs font-bold text-[#E1007A] uppercase tracking-wider font-display">Comprehensive Partner Kit</span>
                <h2 className="text-3xl font-extrabold text-stone-950 font-display">What You Receive as a KIPS Partner</h2>
                <p className="text-stone-500 text-xs font-sans">12 essential pillars included in your turnkey franchise setup package.</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {deliverables.map((item, idx) => (
                  <div key={idx} className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm space-y-2.5 hover:border-[#E1007A]/50 transition-all">
                    <div className="flex items-center gap-2">
                      <span className="w-6 h-6 rounded-full bg-[#E1007A]/10 text-[#E1007A] flex items-center justify-center font-bold text-xs font-mono">
                        {idx + 1}
                      </span>
                      <h4 className="font-bold text-stone-900 text-sm font-display">{item.name}</h4>
                    </div>
                    <p className="text-stone-600 text-xs font-sans leading-relaxed">{item.desc}</p>
                  </div>
                ))}
              </div>
            </section>

            {/* Investment & Space Specifications (Page 11) */}
            <section className="max-w-5xl mx-auto space-y-6">
              <div className="text-center space-y-2">
                <h2 className="text-2xl font-bold font-display">Preschool Investment & Space Requirements</h2>
                <p className="text-stone-500 text-xs font-sans">Standard spatial and capital allocations for high-return preschool setups.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm space-y-3">
                  <span className="text-[10px] text-[#E1007A] uppercase font-bold tracking-wider font-display">Investment Bracket</span>
                  <div className="text-2xl font-black text-stone-900 font-display">₹15 Lakhs – ₹35 Lakhs</div>
                  <p className="text-stone-500 text-xs font-sans">
                    Includes initial curriculum kits, branding materials, teacher certifications, and ERP license.
                  </p>
                </div>

                <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm space-y-3">
                  <span className="text-[10px] text-[#E1007A] uppercase font-bold tracking-wider font-display">Land Space</span>
                  <div className="text-2xl font-black text-stone-900 font-display">2,500 – 5,000 sq. ft.</div>
                  <p className="text-stone-500 text-xs font-sans">
                    Ground floor or independent property with safe outdoor play access and secure boundary fencing.
                  </p>
                </div>

                <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm space-y-3">
                  <span className="text-[10px] text-[#E1007A] uppercase font-bold tracking-wider font-display">Minimum Built-Up</span>
                  <div className="text-2xl font-black text-stone-900 font-display">1,800 – 3,500 sq. ft.</div>
                  <p className="text-stone-500 text-xs font-sans">
                    Provides capacity for 6–10 spacious smart classrooms, reception, activity studio, and play areas.
                  </p>
                </div>
              </div>

              {/* Recommended Campus Facilities checklist */}
              <div className="bg-stone-50 p-6 rounded-2xl border border-stone-200 space-y-4">
                <h4 className="font-bold text-stone-900 text-sm font-display">Recommended Campus Facilities</h4>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2 text-xs text-stone-700 font-medium font-sans">
                  {[
                    '6–10 Classrooms', 'Welcome Reception', 'Principal Cabin', 'Activity Studio',
                    'Indoor Play Area', 'Outdoor Play Zone', 'Child Washrooms', 'Parent Waiting Lounge',
                    '24/7 CCTV Monitoring', 'Digital Smart Panels'
                  ].map((item, idx) => (
                    <div key={idx} className="flex items-center gap-1.5 bg-white p-2 rounded-lg border border-stone-200/60">
                      <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                      <span>{item}</span>
                    </div>
                  ))}
                </div>
              </div>
            </section>

            {/* Call to action */}
            <div className="text-center space-y-3">
              <button onClick={handleConsultationCTA} className="px-8 py-3.5 bg-[#E1007A] hover:bg-[#c20068] text-white font-bold rounded-full text-sm transition-all shadow-md cursor-pointer">
                Begin Your Franchise Registration
              </button>
            </div>
          </div>
        )}

        {/* Model 2: CBSE School Setup (Pages 12-13) */}
        {activePartnershipTab === 'cbse' && (
          <CBSEModelView
            onRegisterClick={handleConsultationCTA}
            onBrochureClick={handleOpenBrochure}
          />
        )}

        {/* Model 3: IB School Setup (Pages 14-15) */}
        {activePartnershipTab === 'ib' && (
          <IBModelView
            onRegisterClick={handleConsultationCTA}
            onBrochureClick={handleOpenBrochure}
          />
        )}

        {/* Model 4: Degree College Setup (Pages 16-17) */}
        {activePartnershipTab === 'college' && (
          <DegreeCollegeModelView
            onRegisterClick={handleConsultationCTA}
            onBrochureClick={handleOpenBrochure}
          />
        )}

      </div>
    );
  };

  // --- 4. FINNISH WAY ACADEMY / NTT TEACHER TRAINING VIEW ---
  const renderFwa = () => {
    return (
      <div className="space-y-16 py-8 animate-fade-in" id="fwa-view">
        
        {/* Academic Header Banner */}
        <div className="max-w-4xl mx-auto text-center space-y-4">
          <div className="inline-flex items-center gap-1.5 bg-[#7E22CE]/10 text-[#7E22CE] px-3.5 py-1.5 rounded-full text-xs font-bold tracking-widest uppercase font-display">
            <Award className="w-4 h-4" />
            <span>FinnishWay Academy</span>
          </div>
          <h1 className="text-4xl sm:text-5xl font-extrabold text-stone-900 font-display leading-tight">
            NTT & Preschool Teacher Training
          </h1>
          <div className="border-l-4 border-[#7E22CE] pl-4 max-w-xl mx-auto italic text-sm text-stone-600 font-sans font-medium">
            "Empowering Educators Through Nordic-Inspired Excellence"
          </div>
          <p className="text-stone-600 text-sm leading-relaxed max-w-2xl mx-auto font-sans">
            FinnishWay Academy is a premier teacher training and professional development institution dedicated to preparing educators, school leaders, and caregivers through globally inspired, research-driven curriculum frameworks.
          </p>
        </div>

        {/* Vision details */}
        <section className="max-w-5xl mx-auto bg-white rounded-3xl border border-stone-200 p-8 sm:p-10 shadow-sm grid grid-cols-1 md:grid-cols-2 gap-10 items-center">
          <div className="space-y-4">
            <span className="text-xs font-bold text-[#7E22CE] uppercase tracking-wider font-display font-semibold">Our Vision</span>
            <h2 className="text-2xl font-bold text-stone-950 font-display">Nordic-Inspired Education for Every Classroom</h2>
            <p className="text-stone-600 text-sm leading-relaxed font-sans">
              We envision creating a new generation of Indian educators who inspire curiosity, empathy, and lifelong learning. Inspired by Finland's world-renowned early education frameworks, we focus on:
            </p>
            <div className="grid grid-cols-2 gap-2 text-xs text-stone-700 font-semibold font-sans">
              <span className="flex items-center gap-1"><Check className="w-3.5 h-3.5 text-[#7E22CE]" /> Child-Centred play</span>
              <span className="flex items-center gap-1"><Check className="w-3.5 h-3.5 text-[#7E22CE]" /> Experiential tools</span>
              <span className="flex items-center gap-1"><Check className="w-3.5 h-3.5 text-[#7E22CE]" /> Inclusive styles</span>
              <span className="flex items-center gap-1"><Check className="w-3.5 h-3.5 text-[#7E22CE]" /> Emotional skills</span>
              <span className="flex items-center gap-1"><Check className="w-3.5 h-3.5 text-[#7E22CE]" /> Critical thinking</span>
              <span className="flex items-center gap-1"><Check className="w-3.5 h-3.5 text-[#7E22CE]" /> Teacher wellbeing</span>
            </div>
          </div>

          <div className="bg-stone-50 p-6 rounded-2xl border border-stone-200 space-y-3.5">
            <h3 className="font-bold text-stone-900 text-sm font-display">KIPS Academic Initiative</h3>
            <p className="text-stone-500 text-xs font-sans">
              Through FinnishWay Academy, KIPS bridges the gap between abstract academic theories and practical classroom application.
            </p>
            <div className="space-y-2 text-xs text-stone-600 font-medium">
              <div className="flex items-start gap-1.5">
                <span className="w-1.5 h-1.5 bg-[#7E22CE] rounded-full shrink-0 mt-1.5"></span>
                <span>Prepare certified educators matching modern school structures</span>
              </div>
              <div className="flex items-start gap-1.5">
                <span className="w-1.5 h-1.5 bg-[#7E22CE] rounded-full shrink-0 mt-1.5"></span>
                <span>Accelerate classroom quality with termly mentoring cycles</span>
              </div>
              <div className="flex items-start gap-1.5">
                <span className="w-1.5 h-1.5 bg-[#7E22CE] rounded-full shrink-0 mt-1.5"></span>
                <span>Elevate preschool operations with localized academic calendars</span>
              </div>
            </div>
            
            <div className="pt-3 border-t border-stone-200">
              <div className="text-[10px] text-[#7E22CE] uppercase font-bold tracking-wider font-display mb-1">Accreditation Benefits</div>
              <span className="text-[10px] text-stone-500 font-semibold font-sans">Industry-Recognised Certification • Practical Portfolio • Internship Placements</span>
            </div>
          </div>
        </section>

        {/* Teacher Training Programs Selector tabs */}
        <section className="max-w-5xl mx-auto space-y-6">
          <div className="text-center">
            <h2 className="text-2xl font-bold font-display">Teacher Training Programs</h2>
            <p className="text-stone-500 text-xs font-sans">We deliver structured curricula suited for every stage of an educator's career.</p>
          </div>

          <div className="flex flex-wrap justify-center gap-2 border-b border-stone-200 pb-3">
            {[
              { id: 'diploma', label: 'Diploma Programs' },
              { id: 'cert', label: 'Certificate Courses' },
              { id: 'prof', label: 'Professional Dev' },
              { id: 'lead', label: 'Leadership' },
              { id: 'care', label: 'Caregiver Training' }
            ].map((cat) => (
              <button
                key={cat.id}
                onClick={() => setActiveFwaCategory(cat.id as any)}
                className={`px-4 py-2 text-xs font-bold rounded-full transition-colors cursor-pointer ${
                  activeFwaCategory === cat.id
                    ? 'bg-[#7E22CE] text-white shadow-sm'
                    : 'bg-stone-100 hover:bg-stone-200 text-stone-700'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          <div className="bg-white p-6 sm:p-8 rounded-2xl border border-stone-200 shadow-sm animate-fade-in">
            {activeFwaCategory === 'diploma' && (
              <div className="space-y-4">
                <div className="flex justify-between items-center flex-wrap gap-2">
                  <h3 className="font-extrabold text-stone-900 text-base font-display">Comprehensive Professional Diplomas (6 - 12 Months)</h3>
                  <span className="px-2.5 py-1 bg-purple-50 text-xs font-bold text-[#7E22CE] rounded border border-purple-100">National & Global Fit</span>
                </div>
                <p className="text-stone-600 text-xs font-sans">Our primary credential paths preparing high-standard preschool directors, subject coordinators, and early developmental educators.</p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  {[
                    'Diploma in Nursery Teacher Training (NTT)',
                    'Diploma in Early Childhood Care & Education (ECCE)',
                    'Diploma in Preschool Education & Operations',
                    'Diploma in Child Development & Mental Health',
                    'Diploma in Educational Leadership & School Setup'
                  ].map((course, idx) => (
                    <div key={idx} className="flex items-center justify-between bg-stone-50 p-3.5 rounded-xl border border-stone-200/50">
                      <div className="flex items-center gap-2">
                        <BookOpen className="w-4 h-4 text-[#7E22CE] shrink-0" />
                        <span className="text-stone-800 text-xs font-bold">{course}</span>
                      </div>
                      <button 
                        onClick={() => handleOpenBrochure(`${course} Syllabus Brochure`)}
                        className="text-[10px] font-bold text-[#7E22CE] hover:underline shrink-0"
                      >
                        Brochure
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeFwaCategory === 'cert' && (
              <div className="space-y-4">
                <h3 className="font-extrabold text-stone-900 text-base font-display">Short-Term Certificate Courses (1 Week - 3 Months)</h3>
                <p className="text-stone-600 text-xs font-sans">Ideal for skill enhancement, parent guides, and beginner teachers who need practical pedagogical upgrades.</p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  {[
                    'Introduction to Early Childhood Education',
                    'Modern Classroom & Behaviour Management',
                    'Creative Play-Based Teaching Techniques',
                    'Child Psychology Foundations',
                    'Inclusive Education Practices',
                    'Montessori Fundamentals & Tools',
                    'Digital Pedagogy & Coding Readiness'
                  ].map((course, idx) => (
                    <div key={idx} className="flex items-center gap-2 bg-stone-50 p-3 rounded-lg border border-stone-200/50">
                      <Award className="w-4 h-4 text-[#F97316] shrink-0" />
                      <span className="text-stone-800 text-xs font-bold">{course}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeFwaCategory === 'prof' && (
              <div className="space-y-4">
                <h3 className="font-extrabold text-stone-900 text-base font-display">Professional Development (For Working Educators)</h3>
                <p className="text-stone-600 text-xs font-sans">Topics designed to address emerging challenges in classroom delivery, assessment compliance, and creative curriculum adaptations.</p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  {['Curriculum & Lesson Planning', 'Student Evaluation Tools', 'Classroom Technology Integration', 'STEM & Science Exploration', 'Inquiry-Based Learning Methods', 'Effective Parent-Teacher Communication'].map((item, idx) => (
                    <div key={idx} className="flex items-center gap-2 bg-stone-50 p-3 rounded-lg border border-stone-200/50">
                      <span className="w-2 h-2 rounded-full bg-amber-500 shrink-0"></span>
                      <span className="text-stone-800 text-xs font-bold">{item}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeFwaCategory === 'lead' && (
              <div className="space-y-4">
                <h3 className="font-extrabold text-stone-900 text-base font-display">Leadership Programs (For Administrators & Directors)</h3>
                <p className="text-stone-600 text-xs font-sans">Equipping directors, founders, and academic leaders with administrative planning skills, quality control, and strategic school expansion checklists.</p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  {['Academic Leadership & Strategy', 'School Administration & Compliance', 'Teacher Mentoring Cycles', 'School Rebranding Process', 'Annual Budget & Asset Tracking'].map((item, idx) => (
                    <div key={idx} className="flex items-center gap-2 bg-stone-50 p-3 rounded-lg border border-stone-200/50">
                      <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span className="text-stone-800 text-xs font-bold">{item}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeFwaCategory === 'care' && (
              <div className="space-y-4">
                <h3 className="font-extrabold text-stone-900 text-base font-display">Caregiver & Childcare Provider Training</h3>
                <p className="text-stone-600 text-xs font-sans">Essential technical courses for daycare staff, preschool nannies, and parents focusing on infant safety, pediatric nutrition, and child protection.</p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  {['Infant & Toddler Care Basics', 'Child Safety & First Aid', 'Pediatric Nutrition Guides', 'Emotional Attachment Styles', 'Special Needs Support'].map((item, idx) => (
                    <div key={idx} className="flex items-center gap-2 bg-stone-50 p-3 rounded-lg border border-stone-200/50">
                      <HeartIcon className="w-4 h-4 text-rose-500 shrink-0" />
                      <span className="text-stone-800 text-xs font-bold">{item}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </section>

        {/* Admission Process roadmap */}
        <section className="max-w-4xl mx-auto space-y-8 bg-stone-50 p-8 rounded-3xl border border-stone-200 shadow-inner">
          <div className="text-center">
            <h2 className="text-xl font-bold font-display">Simple Admission Process</h2>
            <p className="text-stone-500 text-xs mt-0.5 font-sans">Student-friendly, transparent registration cycle.</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 text-center">
            <div className="space-y-2">
              <div className="w-8 h-8 rounded-full bg-[#7E22CE] text-white flex items-center justify-center mx-auto text-sm font-bold">1</div>
              <h4 className="font-bold text-stone-950 text-xs font-display">Choose Course</h4>
              <p className="text-stone-500 text-[10px] font-sans">Select NTT, ECCE, or leadership courses based on your academic background.</p>
            </div>
            <div className="space-y-2">
              <div className="w-8 h-8 rounded-full bg-[#7E22CE] text-white flex items-center justify-center mx-auto text-sm font-bold">2</div>
              <h4 className="font-bold text-stone-950 text-xs font-display">Apply Online</h4>
              <p className="text-stone-500 text-[10px] font-sans">Submit qualifications and required documentation via our secure form.</p>
            </div>
            <div className="space-y-2">
              <div className="w-8 h-8 rounded-full bg-[#7E22CE] text-white flex items-center justify-center mx-auto text-sm font-bold">3</div>
              <h4 className="font-bold text-stone-950 text-xs font-display">Counseling & Admit</h4>
              <p className="text-stone-500 text-[10px] font-sans">Attend our introductory callback and finalize your certification enrollment.</p>
            </div>
          </div>
        </section>

        {/* Placement Support details */}
        <section className="max-w-5xl mx-auto space-y-6">
          <h2 className="text-2xl font-bold text-center font-display">Career & Placement Support</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-2xl border border-stone-200 space-y-2.5">
              <h4 className="font-bold text-stone-900 text-sm font-display">Internship Opportunities</h4>
              <p className="text-stone-500 text-xs font-sans leading-relaxed">Gain physical classroom experience with guided internships, observations, and structured teacher portfolios inside partner schools.</p>
            </div>
            <div className="bg-white p-6 rounded-2xl border border-stone-200 space-y-2.5">
              <h4 className="font-bold text-stone-900 text-sm font-display">Placement Assistance</h4>
              <p className="text-stone-500 text-xs font-sans leading-relaxed">Resume reviews, professional mock interviews, career mapping, and active placement calls into recognized educational trusts.</p>
            </div>
            <div className="bg-white p-6 rounded-2xl border border-stone-200 space-y-2.5">
              <h4 className="font-bold text-stone-900 text-sm font-display">Franchise Employment</h4>
              <p className="text-stone-500 text-xs font-sans leading-relaxed">Qualified certified top graduates receive immediate hiring priorities within the Kinderbee preschool and CBSE partner network.</p>
            </div>
          </div>
        </section>

        {/* Course enquiry CTA */}
        <section className="max-w-xl mx-auto text-center space-y-4">
          <h3 className="text-xl font-bold font-display">Start Your Teaching Journey Today</h3>
          <p className="text-xs text-stone-500 font-sans">
            Join FinnishWay Academy and become part of a growing community of passionate educators committed to transforming childhood learning.
          </p>
          <div className="flex justify-center gap-3">
            <button
              onClick={() => {
                setCurrentTab('partner-with-us');
                window.scrollTo({ top: 350, behavior: 'smooth' });
              }}
              className="px-6 py-2.5 bg-[#7E22CE] hover:bg-[#6b1dae] text-white font-bold rounded-full text-xs transition-colors cursor-pointer"
            >
              Apply for Course Program
            </button>
            <button
              onClick={() => handleOpenBrochure('NTT Teacher Training Complete Prospectus')}
              className="px-6 py-2.5 border border-stone-300 hover:bg-stone-50 text-stone-800 font-bold rounded-full text-xs transition-colors cursor-pointer flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5 text-[#7E22CE]" />
              <span>Get Prospectus</span>
            </button>
          </div>
        </section>

      </div>
    );
  };

  // --- 5. INVESTORS VIEW ---
  const renderInvestors = () => {
    const investorFaqs = faqs.filter(f => f.section === 'investor');
    return (
      <div className="space-y-16 py-8 animate-fade-in" id="investors-view">
        
        {/* Investor Header */}
        <div className="max-w-4xl mx-auto text-center space-y-4">
          <span className="text-xs font-bold text-[#E1007A] uppercase tracking-wider font-display">Strategic Financial Growth</span>
          <h1 className="text-4xl sm:text-5xl font-extrabold text-stone-900 font-display">Investors & Capital Partners</h1>
          <p className="text-stone-600 text-sm sm:text-base leading-relaxed max-w-2xl mx-auto font-sans">
            Through the Kinderbee Integrated Partnership System (KIPS), we deliver tailored business setups, asset models, and 100% Zero Royalty frameworks to secure premium investment returns.
          </p>
        </div>

        {/* ROI & Financial planning details */}
        <section className="max-w-5xl mx-auto bg-white rounded-3xl border border-stone-200 p-8 sm:p-10 shadow-sm grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch">
          
          {/* Left Column: Context & KIPS Value */}
          <div className="lg:col-span-6 flex flex-col justify-between space-y-6">
            <div className="space-y-4">
              <span className="text-xs font-bold text-[#E1007A] uppercase tracking-wider font-display">Investment Modeling</span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-[#0F172A] tracking-tight font-display">ROI & Strategic Financial Planning</h2>
              <p className="text-stone-600 text-sm leading-relaxed font-sans">
                Every educational project is structurally unique. Our financial planning process helps capital investors make highly informed choices through market feasibility analysis and long-term asset models.
              </p>
            </div>

            <div className="bg-stone-50 p-5 rounded-2xl border border-stone-200/60 space-y-3">
              <h4 className="font-bold text-stone-900 text-xs font-display uppercase tracking-wider text-[#E1007A]">How KIPS Optimizes Your Capital</h4>
              <ul className="space-y-2 text-xs text-stone-600 font-medium">
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-600 shrink-0" /> Market feasibility & site location pre-audits</li>
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-600 shrink-0" /> 100% Zero Royalty fees - keep all tuition revenues</li>
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-600 shrink-0" /> Comprehensive pre-lease and budget projections</li>
                <li className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-600 shrink-0" /> Turnkey support from affiliation guides to marketing</li>
              </ul>
            </div>
          </div>

          {/* Right Column: Interactive ROI & Budget Calculator */}
          <div className="lg:col-span-6 bg-[#0F172A] text-white p-6 sm:p-8 rounded-2xl border border-[#1E293B] shadow-lg flex flex-col justify-between space-y-5" id="roi-calculator">
            <div className="space-y-1.5 text-center">
              <h3 className="font-bold text-sm font-display tracking-wide uppercase text-amber-400">Interactive Budget & ROI Calculator</h3>
              <p className="text-[11px] text-slate-300 font-sans">Estimate your capacity, return rates, and Zero Royalty savings instantly.</p>
            </div>

            {/* Model Selection Tabs */}
            <div className="grid grid-cols-3 gap-1 bg-[#0B0F19] p-1 rounded-xl border border-[#1E293B]">
              {(['preschool', 'school', 'college'] as const).map((m) => (
                <button
                  key={m}
                  onClick={() => {
                    setCalcModel(m);
                    setCalcBudget(m === 'preschool' ? 25 : m === 'school' ? 200 : 500);
                  }}
                  className={`py-1.5 text-[10px] font-bold rounded-lg transition-all capitalize cursor-pointer ${
                    calcModel === m
                      ? 'bg-[#E1007A] text-white shadow'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {m === 'preschool' ? 'Preschool' : m === 'school' ? 'K-12 School' : 'College'}
                </button>
              ))}
            </div>

            {/* Slider control */}
            <div className="space-y-2">
              <div className="flex justify-between text-xs font-semibold">
                <span className="text-slate-300">Capital Allocation Budget</span>
                <span className="text-amber-400 font-mono font-bold">
                  {calcModel === 'preschool' ? `₹${calcBudget} Lakhs` : `₹${(calcBudget / 100).toFixed(1)} Crores`}
                </span>
              </div>
              <input
                type="range"
                min={calcModel === 'preschool' ? 15 : calcModel === 'school' ? 100 : 300}
                max={calcModel === 'preschool' ? 35 : calcModel === 'school' ? 300 : 1000}
                step={calcModel === 'preschool' ? 1 : calcModel === 'school' ? 10 : 50}
                value={calcBudget}
                onChange={(e) => setCalcBudget(Number(e.target.value))}
                className="w-full h-1.5 bg-[#0B0F19] rounded-lg appearance-none cursor-pointer accent-[#E1007A]"
              />
              <div className="flex justify-between text-[9px] text-slate-500 font-bold">
                <span>
                  {calcModel === 'preschool' ? '₹15L' : calcModel === 'school' ? '₹1Cr' : '₹3Cr'}
                </span>
                <span>
                  {calcModel === 'preschool' ? '₹35L' : calcModel === 'school' ? '₹3Cr' : '₹10Cr'}
                </span>
              </div>
            </div>

            {/* Projected Outputs Grid */}
            <div className="grid grid-cols-2 gap-3.5 bg-[#0B0F19] p-4 rounded-xl border border-[#1E293B]">
              <div className="space-y-0.5">
                <span className="text-[9px] text-slate-400 font-bold uppercase tracking-wider block font-sans">Est. Student Capacity</span>
                <span className="text-base font-black font-display text-white">
                  {calcModel === 'preschool' ? Math.round(calcBudget * 6) : calcModel === 'school' ? Math.round(calcBudget * 4) : Math.round(calcBudget * 3)}
                </span>
              </div>

              <div className="space-y-0.5">
                <span className="text-[9px] text-slate-400 font-bold uppercase tracking-wider block font-sans">Projected Annual Surplus</span>
                <span className="text-base font-black font-display text-emerald-400">
                  {calcModel === 'preschool' ? `₹${Math.round(calcBudget * 0.8)}L/yr` : `₹${(calcBudget * 0.25).toFixed(1)}Cr/yr`}
                </span>
              </div>

              <div className="space-y-0.5">
                <span className="text-[9px] text-slate-400 font-bold uppercase tracking-wider block font-sans">Est. ROI Percentage</span>
                <span className="text-base font-black font-display text-purple-400">
                  {calcModel === 'preschool' ? '38% - 45%' : calcModel === 'school' ? '25% - 32%' : '22% - 28%'}
                </span>
              </div>

              <div className="space-y-0.5">
                <span className="text-[9px] text-slate-400 font-bold uppercase tracking-wider block font-sans">KIPS Royalty Savings</span>
                <span className="text-base font-black font-display text-amber-400">
                  {calcModel === 'preschool' ? `₹${(calcBudget * 0.12).toFixed(1)}L/yr` : `₹${(calcBudget * 0.04).toFixed(1)}L/yr`}
                </span>
              </div>
            </div>

            <div className="text-[10px] text-slate-400 font-medium text-center font-sans border-t border-[#1E293B] pt-3">
              🎯 Estimated Break-Even Period: <span className="text-white font-bold">{calcModel === 'preschool' ? '12 - 18 months' : calcModel === 'school' ? '18 - 24 months' : '24 - 36 months'}</span>
            </div>
          </div>

        </section>

        {/* Investment Opportunities list */}
        <section className="max-w-6xl mx-auto space-y-8">
          <div className="text-center max-w-xl mx-auto">
            <h2 className="text-2xl font-bold font-display">Investment Opportunities</h2>
            <p className="text-stone-500 text-xs mt-0.5 font-sans">Select the academic model matching your capital budget.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            
            <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm space-y-3">
              <span className="text-[10px] font-bold text-[#E1007A] uppercase tracking-wider font-display">Micro Capital</span>
              <h3 className="font-bold text-stone-950 text-base font-display">Preschool / Kindergarten</h3>
              <p className="text-stone-600 text-xs leading-relaxed font-sans">
                Establish high-quality preschools (2,500 - 5,000 sq ft) offering play-based early childhood learning with direct teacher certifications.
              </p>
              <div className="pt-2 text-[10px] text-stone-400 font-bold uppercase">Budget Fit: ₹15L - ₹35L</div>
            </div>

            <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm space-y-3">
              <span className="text-[10px] font-bold text-[#F97316] uppercase tracking-wider font-display">Mid-Scale Asset</span>
              <h3 className="font-bold text-stone-950 text-base font-display">CBSE / IB School Setup</h3>
              <p className="text-stone-600 text-xs leading-relaxed font-sans">
                Build full K-12 campuses (minimum 1 - 2 acres) with modern classrooms, science labs, libraries, smart features, and central affiliation guides.
              </p>
              <div className="pt-2 text-[10px] text-stone-400 font-bold uppercase">Budget Fit: ₹1Cr - ₹3Cr</div>
            </div>

            <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm space-y-3">
              <span className="text-[10px] font-bold text-[#7E22CE] uppercase tracking-wider font-display">Large Scale Enterprise</span>
              <h3 className="font-bold text-stone-950 text-base font-display">Teacher Training & Degree Colleges</h3>
              <p className="text-stone-600 text-xs leading-relaxed font-sans">
                Launch multi-disciplinary teacher training institutes or degree colleges with direct university approvals and infrastructure norms.
              </p>
              <div className="pt-2 text-[10px] text-stone-400 font-bold uppercase">Budget Fit: ₹3Cr+</div>
            </div>

          </div>
        </section>

        {/* Lead Application trigger */}
        <section className="max-w-xl mx-auto text-center space-y-4">
          <h3 className="text-xl font-extrabold text-stone-900 font-display">Let's Build the Future of Education Together</h3>
          <p className="text-xs text-stone-500 leading-relaxed font-sans">
            Our consultants will help you understand the most suitable investment model, project scope, and territory availability based on your goals.
          </p>
          <button onClick={handleConsultationCTA} className="px-6 py-3 bg-[#E1007A] hover:bg-[#c20068] text-white font-bold rounded-full text-xs transition-colors cursor-pointer">
            Register as a Capital Investor
          </button>
        </section>

      </div>
    );
  };

  // --- 6. BLOGS LIST VIEW ---
  const renderBlogs = () => {
    const handleBlogOpen = async (blog: BlogPost) => {
      setSelectedBlog(blog);
      window.scrollTo({ top: 350, behavior: 'smooth' });
      try {
        const res = await api.recordBlogView(blog.id);
        if (res.success && res.views !== undefined) {
          setSelectedBlog(prev => prev && prev.id === blog.id ? { ...prev, views: res.views } : prev);
          setBlogs(prev => prev.map(b => b.id === blog.id ? { ...b, views: res.views } : b));
        }
      } catch (err) {
        console.error("Failed to record blog view:", err);
      }
    };

    const filteredBlogs = blogs.filter(blog => {
      const matchSearch = blog.title.toLowerCase().includes(blogSearch.toLowerCase()) || 
                          blog.excerpt.toLowerCase().includes(blogSearch.toLowerCase()) ||
                          blog.content.toLowerCase().includes(blogSearch.toLowerCase());
      const matchFilter = blogFilter === 'All' || blog.category === blogFilter;
      return matchSearch && matchFilter;
    });

    const categories = ['All', 'Nordic Education', 'Investment', 'School Setup', 'Curriculum'];

    return (
      <div className="py-8 animate-fade-in max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12" id="blogs-view">
        
        {/* Header Block */}
        <div className="max-w-3xl mx-auto text-center space-y-3 mb-12">
          <span className="text-xs font-bold text-[#E1007A] uppercase tracking-wider font-display">Education Insights & News</span>
          <h1 className="text-4xl font-extrabold text-[#0F172A] font-display">Blogs & Articles</h1>
          <p className="text-stone-500 text-xs sm:text-sm font-sans max-w-xl mx-auto">
            Stay up to date with professional pedagogical reviews, KIPS franchise reports, and NEP 2020 development guides.
          </p>
        </div>

        {/* Main 2-column Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* LEFT-HAND MAIN CONTENT COLUMN (8 cols) */}
          <div className="lg:col-span-8 space-y-8">
            {blogsLoading ? (
              <div className="text-center py-20 bg-white rounded-2xl border border-stone-200 shadow-sm space-y-2">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#E1007A] mx-auto"></div>
                <p className="text-stone-500 text-xs font-bold">Fetching latest articles...</p>
              </div>
            ) : selectedBlog ? (
              <article className="bg-white rounded-2xl border border-stone-200 overflow-hidden shadow-sm p-6 sm:p-10 space-y-6 animate-scale-up">
                
                {/* Back Button */}
                <button 
                  onClick={() => setSelectedBlog(null)}
                  className="inline-flex items-center gap-1 text-xs font-bold text-[#E1007A] hover:text-[#c20068] cursor-pointer mb-2"
                >
                  <ChevronRight className="w-4 h-4 transform rotate-180" />
                  <span>Back to All Articles</span>
                </button>

                {/* Feature Image */}
                <div className="h-64 sm:h-96 rounded-2xl overflow-hidden relative">
                  <img referrerPolicy="no-referrer" src={selectedBlog.image} alt={selectedBlog.title} className="w-full h-full object-cover" />
                  <span className="absolute top-4 left-4 px-3 py-1 bg-[#E1007A] text-white text-xs font-bold uppercase rounded-lg">
                    {selectedBlog.category}
                  </span>
                </div>

                {/* Article Header Details */}
                <div className="space-y-3">
                  <div className="flex flex-wrap items-center gap-3 text-stone-500 text-xs font-semibold">
                    <span>Published by {selectedBlog.author}</span>
                    <span>•</span>
                    <span>{selectedBlog.date || 'August 2026'}</span>
                    <span>•</span>
                    <span className="inline-flex items-center gap-1 text-sky-600 font-bold bg-sky-50 px-2 py-0.5 rounded border border-sky-200">
                      <Clock className="w-3.5 h-3.5 text-sky-500" />
                      {selectedBlog.readTime}
                    </span>
                    <span>•</span>
                    <span className="inline-flex items-center gap-1 text-[#E1007A] font-bold bg-pink-50 px-2 py-0.5 rounded border border-pink-200">
                      <Eye className="w-3.5 h-3.5 text-[#E1007A]" />
                      {(selectedBlog.views || 0).toLocaleString()} views
                    </span>
                  </div>

                  <h1 className="text-2xl sm:text-3.5xl font-extrabold text-[#0F172A] font-display tracking-tight leading-tight">
                    {selectedBlog.title}
                  </h1>
                </div>

                <hr className="border-stone-100" />

                {/* Mobile Inline Table of Contents */}
                {getTableOfContents(selectedBlog.content).length > 0 && (
                  <div className="lg:hidden bg-slate-50 rounded-xl border border-stone-200 p-4 space-y-2">
                    <button 
                      type="button"
                      onClick={() => setMobileTocOpen(!mobileTocOpen)}
                      className="w-full flex items-center justify-between font-bold text-xs text-[#0F172A] cursor-pointer"
                    >
                      <div className="flex items-center gap-2">
                        <List className="w-4 h-4 text-[#E1007A]" />
                        <span>Table of Contents ({getTableOfContents(selectedBlog.content).length} Sections)</span>
                      </div>
                      <ChevronDown className={`w-4 h-4 text-stone-400 transform transition-transform ${mobileTocOpen ? 'rotate-180' : ''}`} />
                    </button>
                    {mobileTocOpen && (
                      <nav className="pt-2 border-t border-stone-200/60 space-y-1 animate-fade-in">
                        {getTableOfContents(selectedBlog.content).map((heading, idx) => {
                          const isActive = activeHeadingId === heading.id;
                          return (
                            <button
                              key={idx}
                              type="button"
                              onClick={() => {
                                setActiveHeadingId(heading.id);
                                const el = document.getElementById(heading.id);
                                if (el) {
                                  el.scrollIntoView({ behavior: 'smooth' });
                                }
                              }}
                              className={`block w-full text-left text-xs py-1 transition-colors cursor-pointer ${
                                isActive 
                                  ? 'text-[#E1007A] font-extrabold pl-1 border-l-2 border-[#E1007A]' 
                                  : heading.level === 3 
                                    ? 'pl-4 text-stone-500 text-[11px]' 
                                    : 'text-stone-800 font-bold'
                              }`}
                            >
                              {heading.level === 2 ? '• ' : '  - '}{heading.text}
                            </button>
                          );
                        })}
                      </nav>
                    )}
                  </div>
                )}

                {/* Article Body Content */}
                <div className="prose max-w-none text-stone-700 leading-relaxed font-sans text-sm sm:text-base space-y-4">
                  {parseContentToParagraphs(selectedBlog.content)}
                </div>

                <div className="pt-6 border-t border-stone-100 flex justify-between items-center">
                  <button 
                    onClick={() => setSelectedBlog(null)}
                    className="px-5 py-2.5 bg-[#0F172A] hover:bg-[#1E293B] text-white font-bold rounded-lg text-xs transition-colors cursor-pointer"
                  >
                    Back to Blogs
                  </button>
                  <span className="text-xs text-stone-400 italic font-serif">Thank you for reading</span>
                </div>
              </article>
            ) : filteredBlogs.length === 0 ? (
              <div className="text-center py-20 border border-dashed border-stone-200 rounded-2xl bg-white p-8 space-y-3 shadow-sm">
                <AlertCircle className="w-10 h-10 text-stone-300 mx-auto" />
                <h3 className="font-bold text-stone-800 text-base font-display">No Articles Found</h3>
                <p className="text-stone-500 text-xs font-sans">We couldn't find any articles matching your search filter.</p>
              </div>
            ) : (
              <div className="space-y-8">
                {filteredBlogs.map((blog) => (
                  <article key={blog.id} className="bg-white rounded-2xl border border-stone-200 overflow-hidden shadow-sm hover:shadow-md transition-all flex flex-col h-full">
                    
                    <div className="h-64 sm:h-80 bg-stone-100 overflow-hidden relative cursor-pointer" onClick={() => handleBlogOpen(blog)}>
                      <img referrerPolicy="no-referrer" src={blog.image} alt={blog.title} className="w-full h-full object-cover hover:scale-105 transition-transform duration-500" />
                      <span className="absolute top-4 left-4 px-2.5 py-1 bg-[#0F172A] text-white text-[10px] font-bold uppercase rounded">
                        {blog.category}
                      </span>
                    </div>

                    <div className="p-6 sm:p-8 space-y-4">
                      <div className="flex items-center gap-3 text-stone-500 text-[11px] font-semibold flex-wrap">
                        <span>By {blog.author}</span>
                        <span>•</span>
                        <span>{blog.date || 'August 2026'}</span>
                        <span>•</span>
                        <span className="inline-flex items-center gap-1 text-sky-600 font-bold bg-sky-50 px-2 py-0.5 rounded border border-sky-100">
                          <Clock className="w-3 h-3 text-sky-500" />
                          {blog.readTime}
                        </span>
                        <span>•</span>
                        <span className="inline-flex items-center gap-1 text-[#E1007A] font-bold bg-pink-50 px-2 py-0.5 rounded border border-pink-100">
                          <Eye className="w-3 h-3 text-[#E1007A]" />
                          {(blog.views || 0).toLocaleString()} views
                        </span>
                      </div>

                      <h2 
                        onClick={() => handleBlogOpen(blog)}
                        className="text-xl sm:text-2xl font-extrabold text-[#0F172A] font-display leading-snug hover:text-[#E1007A] transition-colors cursor-pointer"
                      >
                        {blog.title}
                      </h2>

                      <p className="text-[#334155] text-xs sm:text-sm font-sans leading-relaxed">
                        {blog.excerpt}
                      </p>

                      <div className="pt-2">
                        <button 
                          onClick={() => handleBlogOpen(blog)} 
                          className="px-5 py-2.5 bg-[#E1007A] hover:bg-[#c20068] text-white text-xs font-bold rounded-lg transition-all shadow-sm hover:shadow-md flex items-center gap-1.5 cursor-pointer"
                        >
                          <span>Read More</span>
                          <ArrowRight className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                  </article>
                ))}
              </div>
            )}
          </div>

          {/* RIGHT-HAND SIDEBAR COLUMN (4 cols) */}
          <div className="lg:col-span-4 space-y-6 lg:sticky lg:top-28">
            
            {/* Search Widget */}
            <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-sm">
              <h3 className="font-extrabold text-[#0F172A] text-xs mb-3 font-display border-b border-stone-100 pb-2 uppercase tracking-wider">Search Insights</h3>
              <div className="relative">
                <Search className="absolute left-3 top-2.5 w-4 h-4 text-stone-400" />
                <input
                  type="text"
                  value={blogSearch}
                  onChange={(e) => setBlogSearch(e.target.value)}
                  placeholder="Search articles..."
                  className="w-full pl-9 pr-4 py-2 text-xs border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#E1007A]/15 focus:border-[#E1007A]"
                />
              </div>
            </div>

            {/* Categories Widget */}
            <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-sm">
              <h3 className="font-extrabold text-[#0F172A] text-xs mb-3 font-display border-b border-stone-100 pb-2 uppercase tracking-wider">Categories</h3>
              <div className="space-y-2">
                {categories.map((cat) => {
                  const count = blogs.filter(b => cat === 'All' || b.category === cat).length;
                  return (
                    <button
                      key={cat}
                      onClick={() => {
                        setBlogFilter(cat);
                        setSelectedBlog(null);
                        window.scrollTo({ top: 350, behavior: 'smooth' });
                      }}
                      className={`w-full flex items-center justify-between text-xs py-1 transition-colors text-left font-sans ${
                        blogFilter === cat ? 'text-[#E1007A] font-bold border-l-2 border-[#E1007A] pl-1.5' : 'text-stone-600 hover:text-stone-950'
                      }`}
                    >
                      <span>{cat}</span>
                      <span className="px-2 py-0.5 bg-stone-100 text-stone-500 rounded-full text-[10px] font-semibold">{count}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Recent Posts Widget */}
            <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-sm">
              <h3 className="font-extrabold text-[#0F172A] text-xs mb-3 font-display border-b border-stone-100 pb-2 uppercase tracking-wider">Recent Posts</h3>
              <div className="space-y-4">
                {blogs.slice(0, 4).map((post) => (
                  <div 
                    key={post.id} 
                    onClick={() => {
                      setSelectedBlog(post);
                      window.scrollTo({ top: 350, behavior: 'smooth' });
                    }}
                    className="flex items-start gap-3 group cursor-pointer"
                  >
                    <div className="w-12 h-12 rounded-lg bg-stone-100 overflow-hidden shrink-0">
                      <img referrerPolicy="no-referrer" src={post.image} alt={post.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                    </div>
                    <div className="space-y-0.5 flex-1">
                      <h4 className="text-[11px] font-bold text-stone-900 group-hover:text-[#E1007A] transition-colors line-clamp-2 leading-snug">
                        {post.title}
                      </h4>
                      <span className="text-[9px] text-stone-400 font-medium block">{post.date || 'August 2026'}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

          </div>

        </div>

      </div>
    );
  };

  // --- 7. CONTACT US VIEW ---
  const renderContact = () => {
    return (
      <div className="space-y-12 py-8 animate-fade-in" id="contact-view">
        <div className="max-w-4xl mx-auto text-center space-y-3">
          <span className="text-xs font-bold text-[#E1007A] uppercase tracking-wider font-display">Speak with our consultants</span>
          <h1 className="text-4xl font-extrabold text-stone-900 font-display">Contact Us</h1>
          <p className="text-stone-500 text-sm max-w-lg mx-auto font-sans leading-relaxed">
            Our central educational advisors are available to guide you on launching or expanding your institution.
          </p>
        </div>

        {/* Headquarters Info Grid */}
        <div className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="flex flex-col items-center text-center p-6 bg-white rounded-2xl border border-stone-200/80 shadow-sm hover:shadow-md transition-all">
            <div className="w-12 h-12 bg-pink-50 rounded-full flex items-center justify-center border border-pink-100 mb-4">
              <MapPin className="w-6 h-6 text-[#E1007A]" />
            </div>
            <h4 className="font-extrabold text-stone-900 text-sm font-display">Office Location</h4>
            <p className="text-stone-600 text-xs leading-relaxed mt-2 font-sans">
              {settings.officeAddress || "Opp Vijay Bakery, Old UCO Bank road, Ramamurthy Nagar, Bangalore, 560016"}
            </p>
          </div>

          <div className="flex flex-col items-center text-center p-6 bg-white rounded-2xl border border-stone-200/80 shadow-sm hover:shadow-md transition-all">
            <div className="w-12 h-12 bg-orange-50 rounded-full flex items-center justify-center border border-orange-100 mb-4">
              <Phone className="w-6 h-6 text-orange-500" />
            </div>
            <h4 className="font-extrabold text-stone-900 text-sm font-display">Telephone Contact</h4>
            <p className="text-stone-600 text-xs mt-2 font-sans font-semibold">
              {settings.phone || "+91 99013 32233"}
            </p>
          </div>

          <div className="flex flex-col items-center text-center p-6 bg-white rounded-2xl border border-stone-200/80 shadow-sm hover:shadow-md transition-all">
            <div className="w-12 h-12 bg-yellow-50 rounded-full flex items-center justify-center border border-yellow-100 mb-4">
              <Mail className="w-6 h-6 text-[#F79F33]" />
            </div>
            <h4 className="font-extrabold text-stone-900 text-sm font-display">Email Address</h4>
            <p className="text-stone-600 text-xs mt-2 font-sans break-all select-all font-semibold">
              {settings.email || "kinderbeeschools@gmail.com"}
            </p>
          </div>
        </div>

        {/* Lead Form Standalone Panel */}
        <div className="max-w-4xl mx-auto">
          <div className="mb-6 text-center md:text-left">
            <h3 className="text-xl font-extrabold text-stone-900 font-display">Submit a Consultation Request</h3>
            <p className="text-xs text-stone-500 mt-1 font-sans">Choose your strategic interest below to load our secure registration system.</p>
          </div>
          <LeadForms initialType="general" />
        </div>
      </div>
    );
  };


  return (
    <main className="flex-grow w-full bg-[#FAF9F6]" id="public-main-content">
      {currentTab === 'home' && renderHome()}
      {currentTab !== 'home' && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {currentTab === 'about' && renderAbout()}
          {currentTab === 'partnerships' && renderPartnerships()}
          {currentTab === 'fwa' && renderFwa()}
          {currentTab === 'investors' && renderInvestors()}
          {currentTab === 'blogs' && renderBlogs()}
          {currentTab === 'contact' && renderContact()}

          {currentTab === 'partner-with-us' && (
            <div className="py-8 space-y-8 animate-scale-up" id="partner-with-us-page">
              <div className="max-w-2xl mx-auto text-center space-y-2">
                <span className="text-xs font-bold text-[#E1007A] uppercase tracking-wider font-display font-semibold">Join KIPS Network</span>
                <h1 className="text-3xl sm:text-4xl font-extrabold text-stone-950 font-display">Partnership Registration</h1>
                <p className="text-stone-500 text-xs font-sans">
                  Submit your educational proposal. Our automated scoring agent routes your inquiry to local directors within 24 hours.
                </p>
              </div>
              <LeadForms />
            </div>
          )}
        </div>
      )}

      {/* Global Brochure Modal */}
      <BrochureModal
        isOpen={brochureOpen}
        onClose={() => setBrochureOpen(false)}
        brochureTitle={brochureTitle}
      />
    </main>
  );
}

// Inline fallback for courses
function HeartIcon({ className = "w-5 h-5" }) {
  return (
    <svg className={className} fill="currentColor" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.5">
      <path strokeLinecap="round" strokeLinejoin="round" d="M21 8.25c0-2.485-2.099-4.5-4.688-4.5-1.935 0-3.597 1.126-4.312 2.733-.715-1.607-2.377-2.733-4.313-2.733C5.1 3.75 3 5.765 3 8.25c0 7.22 9 12 9 12s9-4.78 9-12z" />
    </svg>
  );
}
