import React, { useState } from 'react';
import { Menu, X, MessageSquareHeart } from 'lucide-react';
import Logo from './Logo';
import { SystemSettings } from '../types';

interface HeaderProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  isAdmin: boolean;
  settings: SystemSettings;
  onLogout: () => void;
}

export default function Header({ currentTab, setCurrentTab, settings }: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const menuItems = [
    { id: 'home', label: 'Home' },
    { id: 'about', label: 'About Kinderbee' },
    { id: 'partnerships', label: 'Franchise' },
    { id: 'fwa', label: 'NTT Teacher Training' },
    { id: 'investors', label: 'Partner with us' },
    { id: 'blogs', label: 'Blogs' },
    { id: 'contact', label: 'Contact Us' },
  ];

  const handleNav = (tabId: string) => {
    setCurrentTab(tabId);
    setMobileMenuOpen(false);
  };

  const handleTalkToExpert = () => {
    if (typeof window !== 'undefined' && window.openLeadPopup) {
      window.openLeadPopup();
    } else {
      setCurrentTab('contact');
      window.scrollTo({ top: 300, behavior: 'smooth' });
    }
  };

  return (
    <>
      <header className="sticky top-0 z-50 w-full bg-white/95 backdrop-blur-md border-b border-stone-200/90 shadow-xs text-stone-900" id="main-header">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16 sm:h-18">
            
            {/* Logo Brand (Left) */}
            <div className="cursor-pointer shrink-0 flex items-center" onClick={() => handleNav('home')}>
              <Logo isSmall={false} className="h-6 sm:h-7" />
            </div>

            {/* Desktop Navigation Links (Center) */}
            <nav className="hidden lg:flex flex-1 justify-center items-center space-x-1 xl:space-x-2 px-4" aria-label="Main Navigation">
              {menuItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => handleNav(item.id)}
                  className={`px-2.5 xl:px-3 py-1.5 text-xs xl:text-[13px] font-bold rounded-lg transition-all duration-200 cursor-pointer whitespace-nowrap ${
                    currentTab === item.id
                      ? 'text-[#E1007A] bg-[#E1007A]/10 font-extrabold'
                      : 'text-stone-700 hover:text-[#E1007A] hover:bg-stone-50'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </nav>

            {/* Action Callouts (Right) */}
            <div className="hidden lg:flex items-center justify-end gap-2 xl:gap-2.5 shrink-0">
              {/* "Talk to an Expert" Button */}
              <button 
                onClick={handleTalkToExpert}
                className="flex items-center gap-1.5 px-3 py-1.5 xl:px-3.5 xl:py-1.5 text-stone-800 hover:text-[#E1007A] bg-stone-100 hover:bg-[#E1007A]/10 text-xs xl:text-[13px] font-bold rounded-full transition-all duration-200 border border-stone-200 cursor-pointer whitespace-nowrap"
                title="Talk to an Educational Setup Expert"
              >
                <div className="w-4.5 h-4.5 bg-[#E1007A]/10 rounded-full flex items-center justify-center">
                  <MessageSquareHeart className="w-3 h-3 text-[#E1007A]" />
                </div>
                <span>Talk to an Expert</span>
              </button>

              {/* Main Primary CTA Button */}
              <button
                onClick={() => handleNav('investors')}
                className="px-3.5 py-1.5 xl:px-4 xl:py-1.5 text-xs xl:text-[13px] font-bold text-white rounded-full transition-all duration-200 shadow-xs hover:shadow-md bg-gradient-to-r from-[#E1007A] via-[#9D2B84] to-[#F79F33] hover:opacity-95 active:scale-95 cursor-pointer whitespace-nowrap"
              >
                Partner With Us
              </button>
            </div>

            {/* Mobile Right Corner Triggers */}
            <div className="flex lg:hidden items-center gap-2">
              <button 
                onClick={handleTalkToExpert}
                className="flex items-center gap-1.5 px-2.5 py-1 bg-[#E1007A]/10 text-[#E1007A] text-xs font-bold rounded-full border border-[#E1007A]/20"
              >
                <MessageSquareHeart className="w-3.5 h-3.5" />
                <span className="hidden xs:inline">Talk to Expert</span>
              </button>
              
              {/* Hamburger Button */}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-2 text-stone-700 hover:text-[#E1007A] hover:bg-stone-100 rounded-lg transition-colors cursor-pointer"
                aria-label="Toggle Menu"
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>

          </div>
        </div>
      </header>

      {/* Left-to-Right Off-Canvas Mobile Drawer Overlay */}
      {mobileMenuOpen && (
        <div 
          className="lg:hidden fixed inset-0 bg-stone-950/60 z-[100] backdrop-blur-sm transition-opacity duration-300 ease-out"
          onClick={() => setMobileMenuOpen(false)}
        />
      )}

      {/* Left-to-Right Off-Canvas Mobile Drawer Sidebar Panel */}
      <div 
        className={`lg:hidden fixed inset-y-0 left-0 w-64 max-w-[75vw] bg-white z-[110] shadow-2xl flex flex-col transform transition-transform duration-300 ease-out ${
          mobileMenuOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
        id="mobile-nav-slider-drawer"
      >
        <div className="p-3.5 border-b border-stone-100 flex items-center justify-between bg-stone-50">
          <Logo isSmall={false} className="h-5" />
          <button 
            onClick={() => setMobileMenuOpen(false)}
            className="p-1 rounded-full hover:bg-stone-200 text-stone-500 hover:text-stone-900 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable menu options with compact size */}
        <div className="flex-1 overflow-y-auto py-2.5 px-2.5 space-y-0.5">
          {menuItems.map((item) => (
            <button
              key={item.id + '-drawer'}
              onClick={() => handleNav(item.id)}
              className={`flex items-center justify-between w-full px-3 py-2 text-xs sm:text-[13px] font-semibold rounded-lg transition-all duration-150 ${
                currentTab === item.id
                  ? 'text-[#E1007A] bg-[#E1007A]/10 font-bold'
                  : 'text-stone-700 hover:text-[#E1007A] hover:bg-stone-50'
              }`}
            >
              <span>{item.label}</span>
              {currentTab === item.id && (
                <span className="w-1.5 h-1.5 rounded-full bg-[#E1007A]"></span>
              )}
            </button>
          ))}
        </div>

        {/* Drawer Bottom CTA and Info */}
        <div className="p-3 border-t border-stone-100 bg-stone-50 space-y-2">
          <button 
            onClick={() => {
              handleTalkToExpert();
              setMobileMenuOpen(false);
            }}
            className="w-full flex items-center justify-center gap-1.5 px-3 py-2 bg-white rounded-lg border border-stone-200 text-stone-900 font-bold text-xs shadow-xs hover:bg-stone-50 transition-colors"
          >
            <MessageSquareHeart className="w-3.5 h-3.5 text-[#E1007A]" />
            <span>Talk to an Expert</span>
          </button>

          <button
            onClick={() => handleNav('investors')}
            className="w-full py-2 bg-gradient-to-r from-[#E1007A] via-[#9D2B84] to-[#F79F33] text-white text-center font-bold text-xs rounded-lg transition-all shadow-xs active:scale-95"
          >
            Partner With Us
          </button>
        </div>
      </div>
    </>
  );
}
