import React from 'react';

interface LogoProps {
  className?: string;
  showTagline?: boolean;
  isSmall?: boolean;
}

export default function Logo({ className = "h-12", showTagline = true, isSmall = false }: LogoProps) {
  return (
    <div className={`flex items-center ${isSmall ? 'gap-1.5' : 'gap-4'} select-none ${className}`} id="kinderbee-logo">
      {/* Brand Icon & Main Typographic Mark */}
      <div className="flex flex-col items-start leading-none">
        <div className={`flex items-end font-bold tracking-tight ${isSmall ? 'text-sm sm:text-base' : 'text-3xl sm:text-4xl'}`}>
          {/* 'Kin' in Bright Magenta Pink */}
          <span className="text-[#E1007A] font-extrabold font-display">Kin</span>
          
          {/* 'd' as an adorable little bee */}
          <span className="relative inline-flex items-center mx-[1px] text-[#FFD200]">
            <span className="font-extrabold font-display">d</span>
            {/* Cute Bee Antennas, Wings, and Stripes inside d */}
            <span className={`absolute ${isSmall ? '-top-2 gap-[1px]' : '-top-3 gap-[2px]'} left-1/2 -translate-x-1/2 flex`}>
              <span className={`${isSmall ? 'w-[1px] h-2' : 'w-[1.5px] h-3'} bg-stone-800 rounded-full rotate-[-15deg] origin-bottom`}></span>
              <span className={`${isSmall ? 'w-[1px] h-2' : 'w-[1.5px] h-3'} bg-stone-800 rounded-full rotate-[15deg] origin-bottom`}></span>
            </span>
            <span className={`absolute ${isSmall ? '-right-1 w-2 h-2' : '-right-2 w-3 h-3'} top-0 bg-[#E0F2FE] border border-[#38BDF8] rounded-full opacity-80 rotate-[30deg]`}></span>
          </span>

          {/* 'e' in Deep Purple */}
          <span className="text-[#9D2B84] font-extrabold font-display">e</span>

          {/* 'r' in Light Lavender Purple */}
          <span className="text-[#AB82C5] font-extrabold font-display">r</span>

          {/* 'b' as an adorable bee */}
          <span className="relative inline-flex items-center mx-[1px] text-[#FFD200]">
            <span className="font-extrabold font-display">b</span>
            {/* Cute Bee Antennas, Wings, and Stripes inside b */}
            <span className={`absolute ${isSmall ? '-top-2 gap-[1px]' : '-top-3 gap-[2px]'} left-1/2 -translate-x-1/2 flex`}>
              <span className={`${isSmall ? 'w-[1px] h-2' : 'w-[1.5px] h-3'} bg-stone-800 rounded-full rotate-[-15deg] origin-bottom`}></span>
              <span className={`${isSmall ? 'w-[1px] h-2' : 'w-[1.5px] h-3'} bg-stone-800 rounded-full rotate-[15deg] origin-bottom`}></span>
            </span>
            <span className={`absolute ${isSmall ? '-left-1 w-2 h-2' : '-left-2 w-3 h-3'} top-0 bg-[#E0F2FE] border border-[#38BDF8] rounded-full opacity-80 rotate-[-30deg]`}></span>
          </span>

          {/* 'e' in Yellow */}
          <span className="text-[#FFD200] font-extrabold font-display">e</span>

          {/* 'e' in Warm Orange */}
          <span className="text-[#F79F33] font-extrabold font-display">e</span>

          {/* TM Symbol */}
          <span className={`text-[#AB82C5] font-medium self-start ml-[2px] ${isSmall ? 'text-[7px] mt-0.5' : 'text-[10px] mt-1'}`}>TM</span>
        </div>

        {/* Tagline "wings of joy" in beautiful script */}
        {showTagline && !isSmall && (
          <div className="flex items-center justify-center w-full mt-[1px] px-1">
            <div className="h-[1px] flex-1 bg-stone-300"></div>
            <span className="mx-2 text-[10px] sm:text-[11px] text-stone-700 italic font-serif font-semibold tracking-wide flex items-center gap-1">
              wings of joy
            </span>
            <div className="h-[1px] flex-1 bg-stone-300"></div>
          </div>
        )}
      </div>
    </div>
  );
}
