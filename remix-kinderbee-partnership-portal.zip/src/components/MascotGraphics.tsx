import React from 'react';

// Reusable SVG Bee Graduate Mascot & 3D Educational Graphics
export function BeeGraduateMascot({ className = "w-24 h-24", subtitle }: { className?: string; subtitle?: string }) {
  return (
    <div className={`flex flex-col items-center select-none ${className}`} id="bee-graduate-mascot">
      <svg viewBox="0 0 160 160" className="w-full h-full drop-shadow-md overflow-visible">
        <defs>
          <linearGradient id="beeBodyGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FFE033" />
            <stop offset="60%" stopColor="#FFC700" />
            <stop offset="100%" stopColor="#F59E0B" />
          </linearGradient>
          <linearGradient id="beeWingGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#E0F2FE" stopOpacity="0.95" />
            <stop offset="100%" stopColor="#BAE6FD" stopOpacity="0.7" />
          </linearGradient>
          <linearGradient id="gradCapGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#1E293B" />
            <stop offset="100%" stopColor="#0F172A" />
          </linearGradient>
        </defs>

        {/* Wings with Soft Glow */}
        <g id="wings">
          <ellipse cx="48" cy="55" rx="22" ry="34" transform="rotate(-35 48 55)" fill="url(#beeWingGrad)" stroke="#38BDF8" strokeWidth="2" />
          <ellipse cx="112" cy="55" rx="22" ry="34" transform="rotate(35 112 55)" fill="url(#beeWingGrad)" stroke="#38BDF8" strokeWidth="2" />
          <ellipse cx="42" cy="70" rx="14" ry="22" transform="rotate(-40 42 70)" fill="url(#beeWingGrad)" stroke="#38BDF8" strokeWidth="1.5" />
          <ellipse cx="118" cy="70" rx="14" ry="22" transform="rotate(40 118 70)" fill="url(#beeWingGrad)" stroke="#38BDF8" strokeWidth="1.5" />
        </g>

        {/* Antennas */}
        <g id="antennas">
          <path d="M 68 40 Q 60 22 52 24" fill="none" stroke="#0F172A" strokeWidth="3" strokeLinecap="round" />
          <circle cx="50" cy="24" r="5" fill="#E1007A" />
          <path d="M 92 40 Q 100 22 108 24" fill="none" stroke="#0F172A" strokeWidth="3" strokeLinecap="round" />
          <circle cx="110" cy="24" r="5" fill="#E1007A" />
        </g>

        {/* Bee Body */}
        <ellipse cx="80" cy="90" rx="44" ry="46" fill="url(#beeBodyGrad)" stroke="#0F172A" strokeWidth="3" />

        {/* Stripes */}
        <path d="M 42 76 C 54 82 106 82 118 76 C 114 85 104 88 46 88 Z" fill="#0F172A" />
        <path d="M 43 98 C 55 104 105 104 117 98 C 114 107 104 110 46 110 Z" fill="#0F172A" />

        {/* Cute Face */}
        {/* Blush */}
        <circle cx="58" cy="88" r="6" fill="#F472B6" opacity="0.6" />
        <circle cx="102" cy="88" r="6" fill="#F472B6" opacity="0.6" />

        {/* Big Sparkly Eyes */}
        <ellipse cx="64" cy="74" rx="7" ry="9" fill="#0F172A" />
        <circle cx="62" cy="71" r="3" fill="#FFFFFF" />
        <circle cx="66" cy="76" r="1.5" fill="#FFFFFF" />

        <ellipse cx="96" cy="74" rx="7" ry="9" fill="#0F172A" />
        <circle cx="94" cy="71" r="3" fill="#FFFFFF" />
        <circle cx="98" cy="76" r="1.5" fill="#FFFFFF" />

        {/* Joyful Smile */}
        <path d="M 72 84 Q 80 94 88 84" fill="none" stroke="#0F172A" strokeWidth="3" strokeLinecap="round" />

        {/* Little Stinger */}
        <polygon points="80,138 74,130 86,130" fill="#0F172A" />

        {/* Tiny Hands holding Diploma */}
        <ellipse cx="50" cy="102" rx="6" ry="6" fill="#FFC700" stroke="#0F172A" strokeWidth="2" />
        <ellipse cx="110" cy="102" rx="6" ry="6" fill="#FFC700" stroke="#0F172A" strokeWidth="2" />

        {/* Graduate Cap (Mortarboard) */}
        <g id="graduation-cap">
          <polygon points="80,16 130,32 80,48 30,32" fill="url(#gradCapGrad)" stroke="#0F172A" strokeWidth="2" />
          <path d="M 52 42 L 52 56 Q 80 66 108 56 L 108 42 Z" fill="#1E293B" stroke="#0F172A" strokeWidth="2" />
          {/* Tassel Button and Golden Tassel */}
          <circle cx="80" cy="32" r="3.5" fill="#FFD200" />
          <path d="M 80 32 Q 105 34 116 52" fill="none" stroke="#FFD200" strokeWidth="2.5" strokeLinecap="round" />
          <rect x="112" y="52" width="8" height="12" rx="2" fill="#E1007A" />
        </g>
      </svg>
      {subtitle && (
        <span className="text-[11px] font-extrabold text-stone-700 uppercase tracking-wider font-display mt-1">
          {subtitle}
        </span>
      )}
    </div>
  );
}

// 3D Graduation Cap on Books with Globe Asset
export function Education3DCapGlobe({ className = "w-20 h-20" }: { className?: string }) {
  return (
    <div className={`flex items-center justify-center select-none ${className}`} id="education-cap-globe-asset">
      <svg viewBox="0 0 120 120" className="w-full h-full drop-shadow-lg">
        {/* Globe Base */}
        <circle cx="82" cy="74" r="24" fill="#0284C7" stroke="#0369A1" strokeWidth="2" />
        <ellipse cx="82" cy="74" rx="22" ry="10" fill="none" stroke="#7DD3FC" strokeWidth="1.5" opacity="0.8" />
        <ellipse cx="82" cy="74" rx="10" ry="22" fill="none" stroke="#7DD3FC" strokeWidth="1.5" opacity="0.8" />
        <path d="M 70 65 Q 85 60 92 72 Q 88 84 76 80 Z" fill="#22C55E" opacity="0.9" />

        {/* Stack of Books */}
        {/* Book 3 (Bottom - Pink) */}
        <path d="M 20 88 L 70 88 L 76 96 L 26 96 Z" fill="#E1007A" />
        <rect x="20" y="94" width="56" height="10" rx="3" fill="#BE185D" stroke="#0F172A" strokeWidth="1.5" />
        <rect x="24" y="96" width="50" height="6" fill="#FFFBEB" />

        {/* Book 2 (Middle - Yellow) */}
        <path d="M 24 76 L 68 76 L 74 84 L 30 84 Z" fill="#F59E0B" />
        <rect x="24" y="82" width="50" height="9" rx="3" fill="#D97706" stroke="#0F172A" strokeWidth="1.5" />
        <rect x="28" y="84" width="44" height="5" fill="#FFFBEB" />

        {/* Book 1 (Top - Purple) */}
        <path d="M 28 66 L 66 66 L 72 73 L 34 73 Z" fill="#9333EA" />
        <rect x="28" y="71" width="44" height="8" rx="3" fill="#7E22CE" stroke="#0F172A" strokeWidth="1.5" />
        <rect x="32" y="73" width="38" height="4" fill="#FFFBEB" />

        {/* Cap on top of books */}
        <polygon points="50,28 85,38 50,48 15,38" fill="#0F172A" stroke="#1E293B" strokeWidth="1.5" />
        <path d="M 32 43 L 32 52 Q 50 58 68 52 L 68 43 Z" fill="#1E293B" />
        <circle cx="50" cy="38" r="2.5" fill="#FFD200" />
        <path d="M 50 38 Q 68 40 74 50" fill="none" stroke="#FFD200" strokeWidth="2" strokeLinecap="round" />
        <rect x="72" y="50" width="5" height="8" rx="1" fill="#E1007A" />
      </svg>
    </div>
  );
}

// 3D Coin Growth Chart with School Building
export function GrowthCoinsSchool({ className = "w-20 h-20" }: { className?: string }) {
  return (
    <div className={`flex items-center justify-center select-none ${className}`} id="growth-coins-school-asset">
      <svg viewBox="0 0 120 120" className="w-full h-full drop-shadow-lg">
        {/* School Building */}
        <g id="school-building">
          <rect x="18" y="46" width="48" height="46" rx="4" fill="#FFFFFF" stroke="#0F172A" strokeWidth="2" />
          <polygon points="42,22 14,46 70,46" fill="#E1007A" stroke="#0F172A" strokeWidth="2" />
          {/* Bell Tower */}
          <rect x="36" y="14" width="12" height="12" fill="#FFD200" stroke="#0F172A" strokeWidth="1.5" />
          <polygon points="42,6 34,14 50,14" fill="#F97316" stroke="#0F172A" strokeWidth="1.5" />
          <circle cx="42" cy="20" r="2" fill="#0F172A" />

          {/* Windows and Door */}
          <rect x="24" y="54" width="10" height="10" rx="2" fill="#93C5FD" stroke="#0F172A" strokeWidth="1.2" />
          <rect x="50" y="54" width="10" height="10" rx="2" fill="#93C5FD" stroke="#0F172A" strokeWidth="1.2" />
          <rect x="36" y="72" width="12" height="20" rx="2" fill="#9D2B84" stroke="#0F172A" strokeWidth="1.5" />
          <circle cx="45" cy="82" r="1" fill="#FFD200" />
        </g>

        {/* Stacked Golden Coins with Upward Trend */}
        <g id="coins-stack">
          {/* Coin Column 1 */}
          <ellipse cx="76" cy="86" rx="9" ry="4" fill="#F59E0B" stroke="#0F172A" strokeWidth="1.2" />
          <ellipse cx="76" cy="80" rx="9" ry="4" fill="#FFD200" stroke="#0F172A" strokeWidth="1.2" />

          {/* Coin Column 2 */}
          <ellipse cx="92" cy="82" rx="9" ry="4" fill="#F59E0B" stroke="#0F172A" strokeWidth="1.2" />
          <ellipse cx="92" cy="76" rx="9" ry="4" fill="#F59E0B" stroke="#0F172A" strokeWidth="1.2" />
          <ellipse cx="92" cy="70" rx="9" ry="4" fill="#FFD200" stroke="#0F172A" strokeWidth="1.2" />

          {/* Coin Column 3 */}
          <ellipse cx="106" cy="74" rx="9" ry="4" fill="#F59E0B" stroke="#0F172A" strokeWidth="1.2" />
          <ellipse cx="106" cy="68" rx="9" ry="4" fill="#F59E0B" stroke="#0F172A" strokeWidth="1.2" />
          <ellipse cx="106" cy="62" rx="9" ry="4" fill="#F59E0B" stroke="#0F172A" strokeWidth="1.2" />
          <ellipse cx="106" cy="56" rx="9" ry="4" fill="#FFD200" stroke="#0F172A" strokeWidth="1.2" />

          {/* Growth Trend Arrow */}
          <path d="M 68 68 Q 88 50 110 32" fill="none" stroke="#22C55E" strokeWidth="3.5" strokeLinecap="round" />
          <polygon points="112,28 102,32 110,40" fill="#22C55E" />
        </g>
      </svg>
    </div>
  );
}
