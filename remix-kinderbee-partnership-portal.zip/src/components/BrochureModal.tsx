import React, { useState } from 'react';
import { X, Download, CheckCircle2, BookOpen, Sparkles, FileText, Phone, Mail, User, MapPin } from 'lucide-react';
import { api } from '../utils/api';

interface BrochureModalProps {
  isOpen: boolean;
  onClose: () => void;
  brochureTitle?: string;
  brochureType?: string;
}

export default function BrochureModal({
  isOpen,
  onClose,
  brochureTitle = "NTT Teacher Training & KIPS Franchise Brochure",
  brochureType = "fwa_course"
}: BrochureModalProps) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [city, setCity] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    if (!name || !email || !phone) {
      setError("Please provide your name, email, and phone number.");
      setLoading(false);
      return;
    }

    try {
      await api.submitEnquiry('fwa_course', {
        name,
        email,
        phone,
        city,
        courseOfInterest: brochureTitle,
        message: `Requested official brochure: ${brochureTitle}`
      });
      setSubmitted(true);
    } catch (err: any) {
      setError("Failed to register. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleDownloadTrigger = () => {
    // Generate brochure document simulation / trigger
    const element = document.createElement("a");
    const file = new Blob([
      `KINDERBEE INTEGRATED PARTNERSHIP SYSTEM (KIPS) - OFFICIAL BROCHURE\n\n` +
      `Program / Model: ${brochureTitle}\n` +
      `Date: ${new Date().toLocaleDateString()}\n\n` +
      `ABOUT KINDERBEE:\n` +
      `The Kinderbee Integrated Partnership System (KIPS) is India's trusted school education and preschool development partner.\n` +
      `Zero Royalty Model • 30+ Years of Legacy • Finnish-Inspired Learning Frameworks • NEP 2020 Aligned.\n\n` +
      `HEADQUARTERS & CONTACT:\n` +
      `Address: Opp Vijay Bakery, Old UCO Bank road, Ramamurthy Nagar, Bangalore, 560016\n` +
      `Email: kinderbeeschools@gmail.com\n` +
      `Phone: +91 99013 32233\n` +
      `Hours: 10 AM - 5 PM (Mon - Sat)\n\n` +
      `Thank you for connecting with Kinderbee! Our team will contact you shortly.`
    ], { type: 'text/plain' });
    element.href = URL.createObjectURL(file);
    element.download = `Kinderbee_${brochureTitle.replace(/[^a-zA-Z0-9]/g, '_')}_Brochure.txt`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  return (
    <div className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-stone-950/70 backdrop-blur-sm animate-fade-in" id="brochure-modal-overlay">
      <div className="bg-white rounded-3xl shadow-2xl max-w-lg w-full overflow-hidden border border-stone-200 animate-scale-up relative">
        
        {/* Header Ribbon */}
        <div className="bg-gradient-to-r from-[#E1007A] via-[#9D2B84] to-[#F79F33] p-6 text-white text-left relative">
          <button 
            onClick={onClose}
            className="absolute top-5 right-5 p-1.5 rounded-full bg-black/20 hover:bg-black/40 text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
          
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-white/20 rounded-full text-[11px] font-extrabold uppercase tracking-wider mb-2 font-display">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Instant Access</span>
          </div>

          <h3 className="text-xl sm:text-2xl font-extrabold font-display leading-tight">
            Download Official Brochure
          </h3>
          <p className="text-white/90 text-xs sm:text-sm font-sans mt-1">
            {brochureTitle}
          </p>
        </div>

        {/* Content Body */}
        <div className="p-6 sm:p-8">
          {submitted ? (
            <div className="text-center space-y-6">
              <div className="w-16 h-16 bg-emerald-50 border border-emerald-200 rounded-full flex items-center justify-center mx-auto text-emerald-500">
                <CheckCircle2 className="w-9 h-9" />
              </div>

              <div className="space-y-1.5">
                <h4 className="text-xl font-bold text-stone-900 font-display">Your Brochure Is Ready!</h4>
                <p className="text-xs text-stone-600 font-sans">
                  A copy has been routed to <span className="font-bold text-[#E1007A]">{email}</span>. You can also download it right now.
                </p>
              </div>

              <div className="pt-2 flex flex-col gap-3">
                <button
                  onClick={handleDownloadTrigger}
                  className="w-full py-3.5 bg-[#E1007A] hover:bg-[#c20068] text-white font-extrabold text-sm rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Download className="w-4.5 h-4.5" />
                  <span>Download Brochure Now</span>
                </button>
                <button
                  onClick={onClose}
                  className="w-full py-2.5 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold text-xs rounded-xl transition-all"
                >
                  Close Window
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <p className="text-xs text-stone-600 font-sans">
                Please enter your contact details to receive our comprehensive curriculum handbook, fee matrices, and school setup roadmap.
              </p>

              {error && (
                <div className="p-3 bg-rose-50 text-rose-800 text-xs font-bold rounded-lg border border-rose-200">
                  {error}
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Full Name *</label>
                <div className="relative">
                  <User className="w-4 h-4 text-stone-400 absolute left-3.5 top-3.5" />
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Ramesh Sharma"
                    className="w-full pl-10 pr-4 py-2.5 text-sm border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#E1007A]/20 focus:border-[#E1007A]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Email *</label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-stone-400 absolute left-3.5 top-3.5" />
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="name@gmail.com"
                      className="w-full pl-10 pr-4 py-2.5 text-sm border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#E1007A]/20 focus:border-[#E1007A]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 uppercase mb-1">Phone *</label>
                  <div className="relative">
                    <Phone className="w-4 h-4 text-stone-400 absolute left-3.5 top-3.5" />
                    <input
                      type="tel"
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="+91 98765 43210"
                      className="w-full pl-10 pr-4 py-2.5 text-sm border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#E1007A]/20 focus:border-[#E1007A]"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 uppercase mb-1">City / Location</label>
                <div className="relative">
                  <MapPin className="w-4 h-4 text-stone-400 absolute left-3.5 top-3.5" />
                  <input
                    type="text"
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    placeholder="e.g. Bangalore, Hyderabad, Pune"
                    className="w-full pl-10 pr-4 py-2.5 text-sm border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#E1007A]/20 focus:border-[#E1007A]"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3.5 bg-[#E1007A] hover:bg-[#c20068] disabled:bg-stone-300 text-white font-extrabold text-sm rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer mt-2"
              >
                {loading ? (
                  <span>Preparing Document...</span>
                ) : (
                  <>
                    <Download className="w-4.5 h-4.5" />
                    <span>Download Brochure</span>
                  </>
                )}
              </button>
            </form>
          )}
        </div>

      </div>
    </div>
  );
}
