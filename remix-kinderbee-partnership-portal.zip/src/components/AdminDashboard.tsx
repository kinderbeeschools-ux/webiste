import React, { useState, useEffect } from 'react';
import { 
  Lock, LayoutDashboard, FileText, HelpCircle, Settings, LogOut, 
  Sparkles, Check, Phone, Mail, MapPin, Search, Calendar, 
  ArrowRight, Trash, Edit, Plus, AlertCircle, Copy, CheckSquare, RefreshCw, Download,
  Globe, Eye, Gauge, Sliders, CheckCircle, Info, Menu, X, Clock, BarChart2, TrendingUp
} from 'lucide-react';
import { api } from '../utils/api';
import { Enquiry, BlogPost, FAQItem, SystemSettings, DashboardStats } from '../types';

interface AdminDashboardProps {
  isAdmin: boolean;
  setIsAdmin: (auth: boolean) => void;
  settings: SystemSettings;
  setSettings: (settings: SystemSettings) => void;
  pages?: any[];
  setPages?: React.Dispatch<React.SetStateAction<any[]>>;
}

type AdminTab = 'dashboard' | 'enquiries' | 'blogs' | 'faqs' | 'settings' | 'pages';

export default function AdminDashboard({ isAdmin, setIsAdmin, settings, setSettings, pages, setPages }: AdminDashboardProps) {
  const [password, setPassword] = useState('');
  const [authError, setAuthError] = useState<string | null>(null);
  const [authLoading, setAuthLoading] = useState(false);
  const [activeAdminTab, setActiveAdminTab] = useState<AdminTab>('dashboard');
  const [mobileNavOpen, setMobileNavOpen] = useState(false);

  // Pages Edit State
  const [editingPage, setEditingPage] = useState<any | null>(null);
  const [pageForm, setPageForm] = useState({
    title: '', subtitle: '', metaTitle: '', metaDescription: '', keywords: '', badgeText: '', content1: ''
  });
  const [pageSuccess, setPageSuccess] = useState<string | null>(null);
  const [seoPreviewDevice, setSeoPreviewDevice] = useState<'desktop' | 'mobile'>('desktop');

  // Dashboard Data State
  const [analytics, setAnalytics] = useState<DashboardStats | null>(null);
  const [enquiries, setEnquiries] = useState<Enquiry[]>([]);
  const [blogs, setBlogs] = useState<BlogPost[]>([]);
  const [faqs, setFaqs] = useState<FAQItem[]>([]);
  const [loading, setLoading] = useState(true);

  // Focus Items for Modals / Editing
  const [selectedEnquiry, setSelectedEnquiry] = useState<Enquiry | null>(null);
  const [aiDraftLoading, setAiLoading] = useState(false);
  const [aiDraft, setAiDraft] = useState<string | null>(null);
  const [draftCopied, setDraftCopied] = useState(false);
  const [adminNotes, setAdminNotes] = useState('');
  const [leadStatus, setLeadStatus] = useState<Enquiry['status']>('pending');

  // Blog Form State
  const [editingBlog, setEditingBlog] = useState<BlogPost | null>(null);
  const [isCreatingBlog, setIsCreatingBlog] = useState(false);
  const [blogForm, setBlogForm] = useState({
    title: '', category: 'Nordic Education', excerpt: '', content: '',
    image: 'https://images.unsplash.com/photo-1502086223501-7ea6ecd79368?auto=format&fit=crop&q=80&w=800',
    author: 'KIPS Academic Team', readTime: '5 min read', views: 0,
    metaTitle: '', metaDescription: '', keywords: ''
  });

  // FAQ Form State
  const [editingFaq, setEditingFaq] = useState<FAQItem | null>(null);
  const [isCreatingFaq, setIsCreatingFaq] = useState(false);
  const [faqForm, setFaqForm] = useState({
    question: '', answer: '', section: 'home' as FAQItem['section']
  });

  // Settings Forms
  const [settingsForm, setSettingsForm] = useState<SystemSettings>({ ...settings });
  const [newPassword, setNewPassword] = useState('');
  const [settingsSuccess, setSettingsFormSuccess] = useState<string | null>(null);

  // Search/Filters
  const [enqSearch, setEnqSearch] = useState('');
  const [enqFilter, setEnqFilter] = useState('All');

  useEffect(() => {
    if (isAdmin) {
      loadAdminData();
    }
  }, [isAdmin]);

  const loadAdminData = async () => {
    setLoading(true);
    try {
      const enqsData = await api.getEnquiries();
      setEnquiries(enqsData);

      const blogsData = await api.getBlogs();
      setBlogs(blogsData);

      const faqsData = await api.getFAQs();
      setFaqs(faqsData);

      const analyticsData = await api.getAnalytics();
      setAnalytics(analyticsData);
    } catch (err) {
      console.error("Failed to load secure admin data:", err);
      // If token expired
      setIsAdmin(false);
      localStorage.removeItem("kips_admin_token");
    } finally {
      setLoading(false);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthLoading(true);
    setAuthError(null);
    try {
      const res = await api.login(password);
      if (res.success && res.token) {
        localStorage.setItem("kips_admin_token", res.token);
        setIsAdmin(true);
        setPassword('');
      } else {
        setAuthError(res.error || "Incorrect security password.");
      }
    } catch (err: any) {
      setAuthError(err.message || "Failed to log in.");
    } finally {
      setAuthLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("kips_admin_token");
    setIsAdmin(false);
    setEnquiries([]);
  };

  // --- Lead Operations ---
  const selectLead = (enq: Enquiry) => {
    setSelectedEnquiry(enq);
    setAdminNotes(enq.notes);
    setLeadStatus(enq.status);
    setAiDraft(null);
    setDraftCopied(false);
  };

  const saveLeadNotes = async () => {
    if (!selectedEnquiry) return;
    try {
      const updated = await api.updateEnquiry(selectedEnquiry.id, {
        status: leadStatus,
        notes: adminNotes
      });
      // Update local state
      setEnquiries(prev => prev.map(e => e.id === updated.id ? updated : e));
      setSelectedEnquiry(updated);
      
      // Refresh stats
      const stats = await api.getAnalytics();
      setAnalytics(stats);
      
      alert("Lead follow-up logs saved successfully!");
    } catch (err: any) {
      alert("Error saving notes: " + err.message);
    }
  };

  const generateAIDraft = async () => {
    if (!selectedEnquiry) return;
    setAiLoading(true);
    setAiDraft(null);
    try {
      const result = await api.getAISuggestedReply(selectedEnquiry.id);
      if (result.success) {
        setAiDraft(result.emailDraft);
      }
    } catch (err: any) {
      alert("AI Service Timeout. Check if Gemini Key is configured: " + err.message);
    } finally {
      setAiLoading(false);
    }
  };

  const deleteLead = async (id: string) => {
    if (!window.confirm("Are you sure you want to permanently delete this lead?")) return;
    try {
      await api.deleteEnquiry(id);
      setEnquiries(prev => prev.filter(e => e.id !== id));
      setSelectedEnquiry(null);
      // Refresh stats
      const stats = await api.getAnalytics();
      setAnalytics(stats);
    } catch (err: any) {
      alert("Failed to delete lead: " + err.message);
    }
  };

  // --- Blog Operations ---
  const saveBlog = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingBlog) {
        const res = await api.updateBlog(editingBlog.id, blogForm);
        setBlogs(prev => prev.map(b => b.id === editingBlog.id ? res.blog : b));
      } else {
        const res = await api.createBlog(blogForm);
        setBlogs(prev => [res.blog, ...prev]);
      }
      setIsCreatingBlog(false);
      setEditingBlog(null);
      // Reset form
      setBlogForm({
        title: '', category: 'Nordic Education', excerpt: '', content: '',
        image: 'https://images.unsplash.com/photo-1502086223501-7ea6ecd79368?auto=format&fit=crop&q=80&w=800',
        author: 'KIPS Academic Team', readTime: '5 min read', views: 0,
        metaTitle: '', metaDescription: '', keywords: ''
      });
    } catch (err: any) {
      alert("Error saving blog: " + err.message);
    }
  };

  const deleteBlog = async (id: string) => {
    if (!window.confirm("Are you sure you want to delete this blog post?")) return;
    try {
      await api.deleteBlog(id);
      setBlogs(prev => prev.filter(b => b.id !== id));
    } catch (err: any) {
      alert("Failed to delete blog post.");
    }
  };

  // --- FAQ Operations ---
  const saveFaq = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingFaq) {
        const res = await api.updateFAQ(editingFaq.id, faqForm);
        setFaqs(prev => prev.map(f => f.id === editingFaq.id ? res.faq : f));
      } else {
        const res = await api.createFAQ(faqForm);
        setFaqs(prev => [...prev, res.faq]);
      }
      setIsCreatingFaq(false);
      setEditingFaq(null);
      setFaqForm({ question: '', answer: '', section: 'home' });
    } catch (err: any) {
      alert("Error saving FAQ: " + err.message);
    }
  };

  const deleteFaq = async (id: string) => {
    if (!window.confirm("Are you sure you want to delete this FAQ item?")) return;
    try {
      await api.deleteFAQ(id);
      setFaqs(prev => prev.filter(f => f.id !== id));
    } catch (err: any) {
      alert("Failed to delete FAQ.");
    }
  };

  // --- Configuration ---
  const saveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setSettingsFormSuccess(null);
    try {
      const res = await api.updateSettings(settingsForm);
      setSettings(res.settings);
      setSettingsFormSuccess("Contact configuration settings updated successfully!");
    } catch (err: any) {
      alert("Failed to update settings: " + err.message);
    }
  };

  const savePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setSettingsFormSuccess(null);
    try {
      await api.changePassword(newPassword);
      setNewPassword('');
      setSettingsFormSuccess("Administrator password changed successfully!");
    } catch (err: any) {
      alert("Failed to change password. Password must be at least 4 characters.");
    }
  };

  const exportDb = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify({ enquiries, blogs, faqs, settings }, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", "kips_portal_backup.json");
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const selectPage = (page: any) => {
    setEditingPage(page);
    setPageForm({
      title: page.title || '',
      subtitle: page.subtitle || '',
      metaTitle: page.metaTitle || '',
      metaDescription: page.metaDescription || '',
      keywords: page.keywords || '',
      badgeText: page.badgeText || '',
      content1: page.content1 || ''
    });
    setPageSuccess(null);
  };

  const savePage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingPage) return;
    try {
      const res = await api.updatePage(editingPage.id, pageForm);
      if (res.success) {
        if (setPages) {
          setPages(prev => prev.map(p => p.id === editingPage.id ? res.page : p));
        }
        setEditingPage(null);
        setPageSuccess("Page content and SEO tags updated successfully!");
        setTimeout(() => setPageSuccess(null), 5000);
      } else {
        alert("Failed to save page contents.");
      }
    } catch (err: any) {
      alert("Error saving page contents: " + err.message);
    }
  };

  // --- Render Login Screen ---
  if (!isAdmin) {
    return (
      <div className="min-h-[70vh] flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8" id="admin-login-view">
        <div className="max-w-md w-full space-y-8 bg-white p-8 rounded-3xl border border-stone-200 shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1.5 bg-[#E1007A]"></div>
          
          <div className="text-center space-y-2">
            <div className="w-12 h-12 bg-stone-100 rounded-full flex items-center justify-center mx-auto text-stone-700 border">
              <Lock className="w-6 h-6 text-[#E1007A]" />
            </div>
            <h2 className="text-2xl font-extrabold text-stone-900 font-display">KIPS Secure Control Tower</h2>
            <p className="text-xs text-stone-500 font-sans">
              Enter the administrator access key to view lead scoring and edit blog articles.
            </p>
          </div>

          <form className="mt-8 space-y-4" onSubmit={handleLogin}>
            {authError && (
              <div className="flex items-center gap-2 p-3 bg-rose-50 border border-rose-200 text-rose-800 text-xs font-semibold rounded-lg">
                <AlertCircle className="w-4.5 h-4.5 text-rose-600 shrink-0" />
                <span>{authError}</span>
              </div>
            )}

            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">Security Access Code</label>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Default: admin"
                className="w-full px-3.5 py-2.5 text-sm border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#E1007A]/20 focus:border-[#E1007A] bg-stone-50/50"
              />
            </div>

            <button
              type="submit"
              disabled={authLoading}
              className="w-full py-3 bg-[#E1007A] hover:bg-[#c20068] text-white text-sm font-bold rounded-xl transition-all shadow-md hover:shadow-lg disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
            >
              {authLoading ? "Verifying Credentials..." : "Authenticate Access Token"}
            </button>
          </form>

          <div className="text-center text-[10px] text-stone-400 font-sans border-t border-stone-100 pt-4">
            Security audits active. Unauthorized attempts are logged.
          </div>
        </div>
      </div>
    );
  }

  // --- Render Dashboard UI ---
  return (
    <div className="bg-[#0B0F19] text-slate-100 min-h-screen -mx-4 sm:-mx-6 lg:-mx-8 -my-8 p-0 animate-fade-in font-sans flex flex-col lg:flex-row relative" id="admin-panel-portal">
      
      {/* Sidebar - left side of Tailwindadmin */}
      <aside className="w-full lg:w-72 bg-[#0F172A] border-r border-[#1E293B] flex flex-col shrink-0 lg:min-h-screen">
        {/* Brand header */}
        <div className="p-4 sm:p-6 border-b border-[#1E293B] flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-cyan-400 to-blue-600 flex items-center justify-center text-white font-extrabold text-sm shadow-lg shadow-cyan-500/20">
              K
            </div>
            <div>
              <span className="font-extrabold text-white text-base tracking-wide font-display">KIPS Control Tower</span>
              <span className="block text-[10px] text-cyan-400 font-bold uppercase tracking-widest leading-none mt-0.5">Tailwindadmin Edition</span>
            </div>
          </div>

          {/* Mobile close toggle */}
          <button
            onClick={() => setMobileNavOpen(!mobileNavOpen)}
            className="lg:hidden p-2 rounded-lg bg-[#0B0F19] text-slate-300 border border-[#1E293B] hover:text-white"
            aria-label="Toggle menu"
          >
            {mobileNavOpen ? <X className="w-5 h-5 text-rose-400" /> : <Menu className="w-5 h-5 text-cyan-400" />}
          </button>
        </div>

        {/* Navigation Categories */}
        <div className={`p-4 flex-grow space-y-6 overflow-y-auto ${mobileNavOpen ? 'block' : 'hidden lg:block'}`}>
          <div>
            <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-3 mb-2 font-display">HOME</div>
            <button
              onClick={() => { setActiveAdminTab('dashboard'); setMobileNavOpen(false); }}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 text-xs font-bold rounded-xl transition-all cursor-pointer ${
                activeAdminTab === 'dashboard' 
                  ? 'bg-blue-600/15 text-blue-400 border border-blue-500/30' 
                  : 'text-slate-300 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <LayoutDashboard className="w-4.5 h-4.5" />
              <span>Operational Stats</span>
            </button>
          </div>

          <div>
            <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-3 mb-2 font-display">PAGES & SEO</div>
            <div className="space-y-1">
              <button
                onClick={() => { setActiveAdminTab('pages'); setMobileNavOpen(false); }}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 text-xs font-bold rounded-xl transition-all cursor-pointer ${
                  activeAdminTab === 'pages' 
                    ? 'bg-blue-600/15 text-blue-400 border border-blue-500/30' 
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <Edit className="w-4.5 h-4.5" />
                <span>Edit Page Content</span>
              </button>
            </div>
          </div>

          <div>
            <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-3 mb-2 font-display">APPS</div>
            <div className="space-y-1">
              <button
                onClick={() => { setActiveAdminTab('enquiries'); setMobileNavOpen(false); }}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 text-xs font-bold rounded-xl transition-all cursor-pointer ${
                  activeAdminTab === 'enquiries' 
                    ? 'bg-blue-600/15 text-blue-400 border border-blue-500/30' 
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-3">
                  <CheckSquare className="w-4.5 h-4.5" />
                  <span>Leads & Enquiries</span>
                </div>
                {enquiries.filter(e => e.status === 'pending').length > 0 && (
                  <span className="px-2 py-0.5 bg-rose-500 text-white rounded-full text-[9px] font-black shadow-lg shadow-rose-500/30">
                    {enquiries.filter(e => e.status === 'pending').length}
                  </span>
                )}
              </button>

              <button
                onClick={() => { setActiveAdminTab('blogs'); setMobileNavOpen(false); }}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 text-xs font-bold rounded-xl transition-all cursor-pointer ${
                  activeAdminTab === 'blogs' 
                    ? 'bg-blue-600/15 text-blue-400 border border-blue-500/30' 
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <FileText className="w-4.5 h-4.5" />
                <span>Blog Publisher</span>
              </button>

              <button
                onClick={() => { setActiveAdminTab('faqs'); setMobileNavOpen(false); }}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 text-xs font-bold rounded-xl transition-all cursor-pointer ${
                  activeAdminTab === 'faqs' 
                    ? 'bg-blue-600/15 text-blue-400 border border-blue-500/30' 
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <HelpCircle className="w-4.5 h-4.5" />
                <span>FAQ Builder</span>
              </button>
            </div>
          </div>

          <div>
            <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-3 mb-2 font-display">SYSTEM</div>
            <div className="space-y-1.5">
              <button
                onClick={() => { setActiveAdminTab('settings'); setMobileNavOpen(false); }}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 text-xs font-bold rounded-xl transition-all cursor-pointer ${
                  activeAdminTab === 'settings' 
                    ? 'bg-blue-600/15 text-blue-400 border border-blue-500/30' 
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <Settings className="w-4.5 h-4.5" />
                <span>System Configuration</span>
              </button>

              <button
                onClick={exportDb}
                className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-[10px] font-bold rounded-lg flex items-center justify-center gap-1.5 cursor-pointer mt-3 transition-all"
              >
                <Download className="w-3.5 h-3.5 text-slate-400" />
                <span>Export DB to JSON</span>
              </button>
            </div>
          </div>
        </div>

        {/* Terminate Session footer */}
        <div className={`p-4 border-t border-[#1E293B] bg-[#0B0F19]/50 items-center justify-between gap-2 ${mobileNavOpen ? 'flex' : 'hidden lg:flex'}`}>
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></div>
            <span className="text-[10px] font-semibold text-slate-400">Admin Session Active</span>
          </div>
          <button
            onClick={handleLogout}
            className="p-1.5 border border-rose-500/30 text-rose-400 hover:bg-rose-500/10 text-xs font-bold rounded-lg transition-all flex items-center gap-1 cursor-pointer"
            title="Terminate Session"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </aside>

      {/* Main Container Area - right side of Tailwindadmin */}
      <div className="flex-grow flex flex-col min-w-0 font-sans">
        
        {/* Top Header of Tailwindadmin */}
        <header className="h-14 sm:h-16 bg-[#0F172A] border-b border-[#1E293B] px-4 sm:px-6 flex items-center justify-between gap-3 sm:gap-4 z-10 shrink-0 sticky top-0 shadow-md">
          
          {/* Mobile menu trigger button & current section badge */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setMobileNavOpen(!mobileNavOpen)}
              className="lg:hidden p-2 bg-[#0B0F19] border border-[#1E293B] text-slate-300 rounded-lg hover:text-white cursor-pointer"
              aria-label="Toggle navigation"
            >
              <Menu className="w-4.5 h-4.5 text-cyan-400" />
            </button>

            {/* Active section title badge */}
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-1 bg-blue-500/10 border border-blue-500/20 text-blue-400 text-[10px] font-extrabold uppercase rounded-full tracking-wider">
                {activeAdminTab === 'dashboard' && 'Dashboard'}
                {activeAdminTab === 'pages' && 'Pages & SEO'}
                {activeAdminTab === 'enquiries' && 'Leads'}
                {activeAdminTab === 'blogs' && 'Blog Publisher'}
                {activeAdminTab === 'faqs' && 'FAQ Builder'}
                {activeAdminTab === 'settings' && 'Settings'}
              </span>
            </div>
          </div>

          {/* Center/Left search */}
          <div className="flex-1 max-w-xs md:max-w-md hidden sm:block">
            <div className="relative">
              <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
              <input 
                type="text" 
                placeholder="Search portal records..." 
                className="w-full pl-9 pr-4 py-1.5 sm:py-2 bg-[#0B0F19] text-slate-200 border border-[#1E293B] rounded-full text-xs focus:outline-none focus:border-blue-500/50 focus:ring-1 focus:ring-blue-500/30 placeholder-slate-500"
              />
            </div>
          </div>

          {/* Right actions */}
          <div className="flex items-center gap-2 sm:gap-3 ml-auto">
            
            {/* Sync trigger */}
            <button 
              onClick={loadAdminData}
              className="p-2 bg-[#0B0F19] border border-[#1E293B] hover:bg-slate-800 text-slate-300 hover:text-white rounded-lg transition-colors cursor-pointer"
              title="Sync Database"
            >
              <RefreshCw className="w-4 h-4" />
            </button>

            {/* AI/Sparkles badge icon */}
            <button className="p-2 bg-[#0B0F19] border border-[#1E293B] text-slate-300 rounded-lg hidden sm:block" title="System Assistant">
              <Sparkles className="w-4 h-4 text-amber-400" />
            </button>

            {/* Bell/Notification trigger */}
            <div 
              onClick={() => { setActiveAdminTab('enquiries'); setMobileNavOpen(false); }}
              className="relative p-2 bg-[#0B0F19] border border-[#1E293B] text-slate-300 rounded-lg cursor-pointer hover:bg-slate-800"
              title="Pending Enquiries"
            >
              <CheckSquare className="w-4 h-4" />
              {enquiries.filter(e => e.status === 'pending').length > 0 && (
                <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-rose-500 rounded-full animate-pulse border border-[#0F172A]"></span>
              )}
            </div>

            {/* User profile with initials */}
            <div className="flex items-center gap-2 border-l border-[#1E293B] pl-3 sm:pl-4">
              <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center font-bold text-xs text-white shadow-sm shrink-0">
                AD
              </div>
              <div className="hidden md:block text-left leading-none">
                <span className="font-bold text-xs block text-white">Administrator</span>
                <span className="text-[10px] text-slate-400 mt-0.5 block">KIPS Partner Desk</span>
              </div>
            </div>

          </div>
        </header>

        {/* Page Content viewport */}
        <div className="p-6 md:p-8 flex-grow overflow-y-auto space-y-6">
          
          {loading ? (
            <div className="bg-[#0F172A] rounded-2xl border border-[#1E293B] p-20 text-center space-y-4 shadow-sm">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500 mx-auto"></div>
              <p className="text-slate-400 text-xs font-bold">Synchronizing administrative databases...</p>
            </div>
          ) : (
            <>
              {/* --- 1. DASHBOARD HUB VIEW --- */}
              {activeAdminTab === 'dashboard' && analytics && (
                <div className="space-y-6">
                  
                  {/* Welcome banner matching Tailwindadmin reference */}
                  <div className="bg-gradient-to-r from-[#1E293B] via-[#0F172A] to-[#1E293B] rounded-2xl border border-[#1E293B] p-6 relative overflow-hidden flex flex-col md:flex-row items-center justify-between gap-4">
                    <div className="space-y-2 relative z-10 text-center md:text-left">
                      <h2 className="text-xl sm:text-2xl font-black text-white font-display">Welcome back, Administrator 👋</h2>
                      <p className="text-xs text-slate-300 max-w-md font-sans">
                        Here's your real-time operational status overview. AI scoring models are analyzing pipeline value and scoring franchisee inquiries.
                      </p>
                    </div>
                    <div className="px-4 py-2 bg-blue-600/10 border border-blue-500/20 rounded-xl text-center shrink-0">
                      <span className="text-[10px] uppercase font-bold text-blue-400 block tracking-widest">Active Engines</span>
                      <span className="text-xs font-black text-white block mt-0.5">gemini-2.5-flash</span>
                    </div>
                  </div>

                  {/* Metric Cards Grid - 6 cards exactly like Tailwindadmin reference */}
                  <div className="grid grid-cols-2 lg:grid-cols-6 gap-4">
                    <div className="bg-[#0F172A] p-4 rounded-xl border border-[#1E293B] shadow-sm relative overflow-hidden">
                      <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Total Leads</div>
                      <div className="text-xl font-black text-white mt-1.5 font-display">{analytics.totalLeads}</div>
                      <div className="absolute top-3 right-3 w-6 h-6 rounded-lg bg-blue-500/10 flex items-center justify-center text-blue-400 text-[10px] font-bold">👥</div>
                    </div>

                    <div className="bg-[#0F172A] p-4 rounded-xl border border-rose-500/30 bg-rose-500/[0.02] shadow-sm relative overflow-hidden">
                      <div className="text-[10px] font-bold text-rose-400 uppercase tracking-wider">Pending</div>
                      <div className="text-xl font-black text-rose-500 mt-1.5 font-display">{analytics.pendingLeads}</div>
                      <div className="absolute top-3 right-3 w-6 h-6 rounded-lg bg-rose-500/10 flex items-center justify-center text-rose-400 text-[10px] font-bold">⏳</div>
                    </div>

                    <div className="bg-[#0F172A] p-4 rounded-xl border border-emerald-500/30 bg-emerald-500/[0.02] shadow-sm relative overflow-hidden">
                      <div className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider">Closed Won</div>
                      <div className="text-xl font-black text-emerald-500 mt-1.5 font-display">{analytics.closedLeads}</div>
                      <div className="absolute top-3 right-3 w-6 h-6 rounded-lg bg-emerald-500/10 flex items-center justify-center text-emerald-400 text-[10px] font-bold">✓</div>
                    </div>

                    <div className="bg-[#0F172A] p-4 rounded-xl border border-[#1E293B] shadow-sm relative overflow-hidden">
                      <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider font-sans">Pipeline Potential</div>
                      <div className="text-base font-black text-blue-400 mt-2 font-display">{analytics.estimatedRevenuePotential}</div>
                      <div className="absolute top-3 right-3 w-6 h-6 rounded-lg bg-blue-500/10 flex items-center justify-center text-blue-400 text-[10px] font-bold">₹</div>
                    </div>

                    <div className="bg-[#0F172A] p-4 rounded-xl border border-cyan-500/30 bg-cyan-500/[0.02] shadow-sm relative overflow-hidden">
                      <div className="text-[10px] font-bold text-cyan-400 uppercase tracking-wider">Active Ventures</div>
                      <div className="text-xl font-black text-cyan-400 mt-1.5 font-display">12</div>
                      <div className="absolute top-3 right-3 w-6 h-6 rounded-lg bg-cyan-500/10 flex items-center justify-center text-cyan-400 text-[10px] font-bold">🏫</div>
                    </div>

                    <div className="bg-[#0F172A] p-4 rounded-xl border border-amber-500/30 bg-amber-500/[0.02] shadow-sm relative overflow-hidden">
                      <div className="text-[10px] font-bold text-amber-400 uppercase tracking-wider">Conversion %</div>
                      <div className="text-xl font-black text-amber-500 mt-1.5 font-display">84.2%</div>
                      <div className="absolute top-3 right-3 w-6 h-6 rounded-lg bg-amber-500/10 flex items-center justify-center text-amber-400 text-[10px] font-bold">📈</div>
                    </div>
                  </div>

                  {/* Secondary analytics grids */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Leads by Vertical list */}
                    <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm space-y-4">
                      <h3 className="font-bold text-stone-900 text-sm font-display border-b border-stone-100 pb-2">Leads by Education Vertical</h3>
                      <div className="space-y-3">
                        {analytics.leadsByType.map((item, idx) => {
                          const total = analytics.totalLeads || 1;
                          const pct = Math.round((item.value / total) * 100);
                          return (
                            <div key={idx} className="space-y-1">
                              <div className="flex justify-between text-xs font-semibold">
                                <span className="text-stone-700">{item.name}</span>
                                <span className="text-stone-500">{item.value} ({pct}%)</span>
                              </div>
                              <div className="w-full bg-stone-100 h-2 rounded-full overflow-hidden">
                                <div className="bg-[#E1007A] h-full rounded-full" style={{ width: `${pct}%` }}></div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    {/* Quick activity summary feed */}
                    <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm space-y-4">
                      <h3 className="font-bold text-stone-900 text-sm font-display border-b border-stone-100 pb-2">Recent Submissions Feed</h3>
                      {enquiries.length === 0 ? (
                        <p className="text-stone-400 text-xs text-center py-8">No leads logged yet. Submit a front-end enquiry form to test!</p>
                      ) : (
                        <div className="space-y-3.5 max-h-60 overflow-y-auto pr-1">
                          {enquiries.slice(0, 4).map((enq) => (
                            <div 
                              key={enq.id} 
                              onClick={() => { selectLead(enq); setActiveAdminTab('enquiries'); }}
                              className="p-3 bg-stone-50 hover:bg-[#E1007A]/5 hover:border-[#E1007A]/20 transition-all border border-stone-200/60 rounded-xl cursor-pointer flex justify-between items-center text-xs"
                            >
                              <div className="space-y-1">
                                <div className="font-bold text-stone-900">{enq.fields.name}</div>
                                <div className="text-[10px] text-stone-500">{enq.fields.city || "General Location"} • {enq.fields.partnershipModel || enq.fields.courseOfInterest || "General Enquiry"}</div>
                              </div>
                              <span className={`px-2 py-0.5 rounded text-[9px] font-black uppercase ${
                                enq.status === 'pending' ? 'bg-rose-100 text-rose-700 border border-rose-200' :
                                enq.status === 'reviewed' ? 'bg-amber-100 text-amber-700 border border-amber-200' :
                                enq.status === 'contacted' ? 'bg-blue-100 text-blue-700 border border-blue-200' :
                                'bg-emerald-100 text-emerald-700 border border-emerald-200'
                              }`}>
                                {enq.status}
                              </span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* --- 2. ENQUIRIES / LEADS MANAGER --- */}
              {activeAdminTab === 'enquiries' && (
                <div className="space-y-6">
                  
                  {/* Lead Manager Header Search bar */}
                  <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4">
                    <div className="relative w-full sm:max-w-xs">
                      <Search className="absolute left-3 top-2.5 w-4 h-4 text-stone-400" />
                      <input
                        type="text"
                        value={enqSearch}
                        onChange={(e) => setEnqSearch(e.target.value)}
                        placeholder="Search leads by name, email, or city..."
                        className="w-full pl-9 pr-4 py-2 border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#E1007A]/15 focus:border-[#E1007A] text-xs"
                      />
                    </div>

                    <div className="flex gap-2.5 w-full sm:w-auto">
                      {['All', 'pending', 'reviewed', 'contacted', 'closed'].map((status) => (
                        <button
                          key={status}
                          onClick={() => setEnqFilter(status)}
                          className={`px-3 py-1.5 text-xs font-bold rounded-lg border transition-all cursor-pointer capitalize ${
                            enqFilter === status
                              ? 'bg-[#E1007A]/10 text-[#E1007A] border-[#E1007A]/25'
                              : 'bg-transparent text-stone-600 border-stone-200 hover:bg-stone-50'
                          }`}
                        >
                          {status}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                    
                    {/* Left side table (7 columns) */}
                    <div className="lg:col-span-7 bg-white rounded-2xl border border-stone-200 shadow-sm overflow-hidden">
                      <div className="p-4 bg-stone-50 font-bold text-stone-900 text-xs uppercase tracking-wider border-b border-stone-200">
                        Lead Database
                      </div>
                      
                      {enquiries.length === 0 ? (
                        <div className="p-8 text-center text-stone-400 text-xs font-sans">No lead queries logged inside the database.</div>
                      ) : (
                        <div className="divide-y divide-stone-100 max-h-[60vh] overflow-y-auto">
                          {enquiries
                            .filter(e => {
                              const matchSearch = e.fields.name.toLowerCase().includes(enqSearch.toLowerCase()) || 
                                                  e.fields.email.toLowerCase().includes(enqSearch.toLowerCase()) || 
                                                  (e.fields.city || '').toLowerCase().includes(enqSearch.toLowerCase());
                              const matchFilter = enqFilter === 'All' || e.status === enqFilter;
                              return matchSearch && matchFilter;
                            })
                            .map((enq) => (
                              <div
                                key={enq.id}
                                onClick={() => selectLead(enq)}
                                className={`p-4 hover:bg-stone-50 transition-all cursor-pointer flex justify-between items-start text-xs ${
                                  selectedEnquiry?.id === enq.id ? 'bg-[#E1007A]/5 border-l-4 border-[#E1007A]' : ''
                                }`}
                              >
                                <div className="space-y-1.5">
                                  <div className="font-bold text-stone-950 flex items-center gap-1.5">
                                    <span>{enq.fields.name}</span>
                                    {enq.status === 'pending' && <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse"></span>}
                                  </div>
                                  <div className="text-stone-500 text-[10px] leading-relaxed">
                                    <div className="font-semibold text-stone-700">{enq.fields.partnershipModel || enq.fields.courseOfInterest || 'General Enquiry'}</div>
                                    <div>{enq.fields.city}, {enq.fields.state || 'India'} • Budget: {enq.fields.budget || 'N/A'}</div>
                                    <div className="flex items-center gap-1 text-[9px] text-stone-400 mt-1">
                                      <Calendar className="w-3 h-3" />
                                      <span>{new Date(enq.createdAt).toLocaleDateString()}</span>
                                    </div>
                                  </div>
                                </div>

                                <div className="flex flex-col items-end gap-2">
                                  <span className={`px-2 py-0.5 rounded text-[9px] font-black uppercase ${
                                    enq.status === 'pending' ? 'bg-rose-100 text-rose-700 border border-rose-200' :
                                    enq.status === 'reviewed' ? 'bg-amber-100 text-amber-700 border border-amber-200' :
                                    enq.status === 'contacted' ? 'bg-blue-100 text-blue-700 border border-blue-200' :
                                    'bg-emerald-100 text-emerald-700 border border-emerald-200'
                                  }`}>
                                    {enq.status}
                                  </span>
                                </div>
                              </div>
                            ))}
                        </div>
                      )}
                    </div>

                    {/* Right side Details Pane (5 columns) */}
                    <div className="lg:col-span-5 bg-white rounded-2xl border border-stone-200 shadow-sm p-5 space-y-5 sticky top-28 max-h-[80vh] overflow-y-auto" id="lead-details-card">
                      {selectedEnquiry ? (
                        <div className="space-y-4 text-xs animate-fade-in">
                          <div className="flex justify-between items-center border-b border-stone-100 pb-3">
                            <div>
                              <h3 className="font-extrabold text-stone-900 text-sm font-display">Lead Verification Sheet</h3>
                              <span className="text-[10px] text-stone-400 font-mono">ID: {selectedEnquiry.id}</span>
                            </div>
                            <button
                              onClick={() => deleteLead(selectedEnquiry.id)}
                              className="p-1.5 text-stone-400 hover:text-rose-600 rounded transition-colors"
                              title="Delete Lead Record"
                            >
                              <Trash className="w-4 h-4" />
                            </button>
                          </div>

                          {/* Submitted fields list */}
                          <div className="space-y-2 bg-stone-50 p-4 rounded-xl border border-stone-200/50">
                            <div>
                              <div className="text-[9px] text-stone-400 font-bold uppercase font-sans">Full Name</div>
                              <div className="font-bold text-stone-900 text-xs mt-0.5">{selectedEnquiry.fields.name}</div>
                            </div>
                            <div className="grid grid-cols-2 gap-2 border-t border-stone-100 pt-1.5">
                              <div>
                                <div className="text-[9px] text-stone-400 font-bold uppercase font-sans">Email</div>
                                <div className="font-medium text-stone-700 text-xs mt-0.5 break-all">{selectedEnquiry.fields.email}</div>
                              </div>
                              <div>
                                <div className="text-[9px] text-stone-400 font-bold uppercase font-sans">Phone</div>
                                <div className="font-medium text-stone-700 text-xs mt-0.5">{selectedEnquiry.fields.phone}</div>
                              </div>
                            </div>
                            {selectedEnquiry.fields.organization && (
                              <div className="border-t border-stone-100 pt-1.5">
                                <div className="text-[9px] text-stone-400 font-bold uppercase font-sans">Organization / Trust</div>
                                <div className="font-semibold text-stone-800 mt-0.5">{selectedEnquiry.fields.organization}</div>
                              </div>
                            )}
                            <div className="grid grid-cols-2 gap-2 border-t border-stone-100 pt-1.5">
                              <div>
                                <div className="text-[9px] text-stone-400 font-bold uppercase font-sans">City / State</div>
                                <div className="font-semibold text-stone-700 mt-0.5">{selectedEnquiry.fields.city}, {selectedEnquiry.fields.state || 'N/A'}</div>
                              </div>
                              <div>
                                <div className="text-[9px] text-stone-400 font-bold uppercase font-sans">Proposed Budget</div>
                                <div className="font-bold text-[#E1007A] mt-0.5">{selectedEnquiry.fields.budget || 'Not Specified'}</div>
                              </div>
                            </div>
                            {selectedEnquiry.fields.courseOfInterest && (
                              <div className="border-t border-stone-100 pt-1.5">
                                <div className="text-[9px] text-stone-400 font-bold uppercase font-sans">Course Program</div>
                                <div className="font-semibold text-stone-800 mt-0.5">{selectedEnquiry.fields.courseOfInterest} ({selectedEnquiry.fields.learningMode || 'Hybrid'})</div>
                              </div>
                            )}
                            {selectedEnquiry.fields.message && (
                              <div className="border-t border-stone-100 pt-1.5">
                                <div className="text-[9px] text-stone-400 font-bold uppercase font-sans">Message Query</div>
                                <div className="text-stone-700 mt-0.5 leading-relaxed bg-white p-2 rounded border border-stone-200">{selectedEnquiry.fields.message}</div>
                              </div>
                            )}
                          </div>

                          {/* AI Score details */}
                          {selectedEnquiry.aiSummary && (
                            <div className="bg-gradient-to-br from-purple-50 to-pink-50 p-4 rounded-xl border border-purple-100 space-y-1.5">
                              <div className="flex items-center gap-1.5 text-[#7E22CE] font-bold text-[10px] uppercase tracking-wider">
                                <Sparkles className="w-3.5 h-3.5" />
                                <span>AI Strategic Lead Assessment</span>
                              </div>
                              <p className="text-stone-700 text-xs italic font-sans leading-normal">
                                "{selectedEnquiry.aiSummary}"
                              </p>
                            </div>
                          )}

                          {/* Gemini Draft response box */}
                          <div className="border-t border-stone-100 pt-3.5 space-y-2">
                            <div className="flex items-center justify-between">
                              <h4 className="font-bold text-stone-900 font-display">Response Drafting Engine</h4>
                              <button
                                onClick={generateAIDraft}
                                disabled={aiDraftLoading}
                                className="px-3 py-1 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-bold rounded-full text-[10px] transition-colors cursor-pointer flex items-center gap-1 disabled:opacity-50"
                              >
                                <Sparkles className="w-3 h-3 animate-pulse" />
                                <span>{aiDraftLoading ? 'AI Thinking...' : 'Draft Email with Gemini'}</span>
                              </button>
                            </div>

                            {aiDraft && (
                              <div className="bg-stone-50 rounded-xl p-3.5 border border-stone-200 relative">
                                <button
                                  onClick={() => {
                                    navigator.clipboard.writeText(aiDraft);
                                    setDraftCopied(true);
                                    setTimeout(() => setDraftCopied(false), 2000);
                                  }}
                                  className="absolute top-2.5 right-2.5 p-1 bg-white hover:bg-stone-100 rounded border border-stone-200 text-stone-500 hover:text-stone-800 transition-colors"
                                  title="Copy response to clipboard"
                                >
                                  {draftCopied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                                </button>
                                <div className="text-[10px] text-stone-400 font-bold uppercase tracking-wide mb-1 flex items-center gap-1">
                                  <span>Draft Response</span>
                                  {draftCopied && <span className="text-emerald-600">(Copied!)</span>}
                                </div>
                                <pre className="whitespace-pre-wrap text-[10px] text-stone-700 leading-normal font-sans max-h-48 overflow-y-auto">
                                  {aiDraft}
                                </pre>
                              </div>
                            )}
                          </div>

                          {/* Update panel */}
                          <div className="border-t border-stone-100 pt-4 space-y-3">
                            <div className="grid grid-cols-2 gap-2">
                              <div>
                                <label className="block text-[10px] font-bold text-stone-500 mb-1 uppercase tracking-wider font-sans">Lead Status</label>
                                <select
                                  value={leadStatus}
                                  onChange={(e) => setLeadStatus(e.target.value as any)}
                                  className="w-full px-2.5 py-1.5 border border-stone-300 rounded-lg text-xs bg-stone-50 focus:outline-none"
                                >
                                  <option value="pending">Pending Review</option>
                                  <option value="reviewed">Reviewed Lead</option>
                                  <option value="contacted">Contacted / Call</option>
                                  <option value="closed">Closed Account</option>
                                </select>
                              </div>
                            </div>

                            <div>
                              <label className="block text-[10px] font-bold text-stone-500 mb-1 uppercase tracking-wider font-sans">Internal Activity Notes</label>
                              <textarea
                                value={adminNotes}
                                onChange={(e) => setAdminNotes(e.target.value)}
                                rows={2}
                                placeholder="Add logs from your sales call..."
                                className="w-full px-2.5 py-1.5 border border-stone-300 rounded-lg text-xs bg-stone-50 focus:outline-none resize-none"
                              ></textarea>
                            </div>

                            <button
                              onClick={saveLeadNotes}
                              className="w-full py-2 bg-stone-900 hover:bg-stone-800 text-white font-bold rounded-lg text-xs transition-colors cursor-pointer"
                            >
                              Save Lead Update
                            </button>
                          </div>
                        </div>
                      ) : (
                        <div className="text-center py-20 text-stone-400 text-xs font-sans">
                          Select an active enquiry lead from the database left pane to view specific details and use Gemini response draft.
                        </div>
                      )}
                    </div>

                  </div>
                </div>
              )}

              {/* --- 3. BLOG PUBLISHER CRUD VIEW --- */}
              {activeAdminTab === 'blogs' && (
                <div className="space-y-6">
                  
                  {/* Blog Admin header */}
                  <div className="flex justify-between items-center flex-wrap gap-4">
                    <div>
                      <h2 className="text-lg font-bold text-white font-display">Manage Insights & Blogs</h2>
                      <p className="text-[11px] text-slate-400 font-sans">Track article performance analytics, view counts, reading times, and publish updates.</p>
                    </div>

                    {!isCreatingBlog && !editingBlog && (
                      <button
                        onClick={() => {
                          setIsCreatingBlog(true);
                          setEditingBlog(null);
                          setBlogForm({
                            title: '', category: 'Nordic Education', excerpt: '', content: '',
                            image: 'https://images.unsplash.com/photo-1502086223501-7ea6ecd79368?auto=format&fit=crop&q=80&w=800',
                            author: 'KIPS Academic Team', readTime: '5 min read', views: 0,
                            metaTitle: '', metaDescription: '', keywords: ''
                          });
                        }}
                        className="px-4 py-2 bg-[#E1007A] hover:bg-[#c20068] text-white text-xs font-bold rounded-lg flex items-center gap-1 cursor-pointer"
                      >
                        <Plus className="w-4 h-4" />
                        <span>Publish New Article</span>
                      </button>
                    )}
                  </div>

                  {/* Blog Performance Analytics Bar */}
                  {!isCreatingBlog && !editingBlog && (
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
                      <div className="bg-[#0F172A] p-4 rounded-xl border border-[#1E293B] space-y-1">
                        <div className="text-slate-400 text-[10px] uppercase font-bold tracking-wider flex items-center gap-1">
                          <FileText className="w-3.5 h-3.5 text-blue-400" /> Total Published
                        </div>
                        <div className="text-xl font-black text-white font-display">{blogs.length} Articles</div>
                        <div className="text-[10px] text-slate-400">Active on public portal</div>
                      </div>

                      <div className="bg-[#0F172A] p-4 rounded-xl border border-[#1E293B] space-y-1">
                        <div className="text-slate-400 text-[10px] uppercase font-bold tracking-wider flex items-center gap-1">
                          <Eye className="w-3.5 h-3.5 text-[#E1007A]" /> Total View Impressions
                        </div>
                        <div className="text-xl font-black text-[#E1007A] font-display">
                          {blogs.reduce((acc, b) => acc + (b.views || 0), 0).toLocaleString()}
                        </div>
                        <div className="text-[10px] text-slate-400">Cumulative reader views</div>
                      </div>

                      <div className="bg-[#0F172A] p-4 rounded-xl border border-[#1E293B] space-y-1">
                        <div className="text-slate-400 text-[10px] uppercase font-bold tracking-wider flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5 text-sky-400" /> Avg Reading Time
                        </div>
                        <div className="text-xl font-black text-sky-400 font-display">
                          {blogs.length > 0 
                            ? `${Math.round(blogs.reduce((acc, b) => acc + (parseInt(b.readTime || '5') || 5), 0) / blogs.length)} min` 
                            : '0 min'}
                        </div>
                        <div className="text-[10px] text-slate-400">~200 words/min reader pace</div>
                      </div>

                      <div className="bg-[#0F172A] p-4 rounded-xl border border-[#1E293B] space-y-1">
                        <div className="text-slate-400 text-[10px] uppercase font-bold tracking-wider flex items-center gap-1">
                          <TrendingUp className="w-3.5 h-3.5 text-emerald-400" /> Top Performing
                        </div>
                        <div className="text-xs font-bold text-emerald-400 font-display truncate">
                          {blogs.length > 0 ? [...blogs].sort((a,b) => (b.views||0)-(a.views||0))[0].title : 'N/A'}
                        </div>
                        <div className="text-[10px] text-slate-400">
                          {blogs.length > 0 ? `${([...blogs].sort((a,b) => (b.views||0)-(a.views||0))[0].views || 0).toLocaleString()} views` : '0 views'}
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Blog Create / Edit Form panel */}
                  {(isCreatingBlog || editingBlog) ? (
                    <form onSubmit={saveBlog} className="bg-[#0F172A] p-6 rounded-2xl border border-[#1E293B] shadow-sm space-y-4 animate-scale-up text-xs text-slate-100">
                      <h3 className="font-extrabold text-white text-sm font-display border-b border-[#1E293B] pb-2 flex justify-between items-center">
                        <span>{editingBlog ? `Edit: ${editingBlog.title}` : 'Draft New Educational Article'}</span>
                        <span className="text-xs font-normal text-slate-400 font-mono">Word Count: {blogForm.content ? blogForm.content.trim().split(/\s+/).filter(Boolean).length : 0} words</span>
                      </h3>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div className="sm:col-span-2">
                          <label className="block font-bold text-slate-300 mb-1">Article Title</label>
                          <input
                            type="text"
                            required
                            value={blogForm.title}
                            onChange={(e) => setBlogForm({ ...blogForm, title: e.target.value })}
                            placeholder="e.g. Preparing Indian Classrooms for the Foundational Stage"
                            className="w-full px-3 py-2 border border-[#1E293B] rounded-lg bg-[#0B0F19] text-white focus:outline-none focus:border-blue-500"
                          />
                        </div>

                        <div>
                          <label className="block font-bold text-slate-300 mb-1">Category</label>
                          <select
                            value={blogForm.category}
                            onChange={(e) => setBlogForm({ ...blogForm, category: e.target.value })}
                            className="w-full px-3 py-2 border border-[#1E293B] rounded-lg bg-[#0B0F19] text-white focus:outline-none focus:border-blue-500"
                          >
                            <option value="Nordic Education">Nordic Education</option>
                            <option value="Investment">Investment</option>
                            <option value="School Setup">School Setup</option>
                            <option value="Curriculum">Curriculum</option>
                          </select>
                        </div>

                        <div>
                          <div className="flex justify-between items-center mb-1">
                            <label className="font-bold text-slate-300 flex items-center gap-1">
                              <Clock className="w-3.5 h-3.5 text-sky-400" />
                              Estimated Reading Time
                            </label>
                            <button
                              type="button"
                              onClick={() => {
                                const words = blogForm.content ? blogForm.content.trim().split(/\s+/).filter(Boolean).length : 0;
                                const mins = Math.max(1, Math.ceil(words / 200));
                                setBlogForm({ ...blogForm, readTime: `${mins} min read` });
                              }}
                              className="text-[10px] text-sky-400 hover:text-sky-300 font-bold underline cursor-pointer"
                              title="Auto calculate based on article word count (~200 wpm)"
                            >
                              Auto-Calculate
                            </button>
                          </div>
                          <input
                            type="text"
                            required
                            value={blogForm.readTime}
                            onChange={(e) => setBlogForm({ ...blogForm, readTime: e.target.value })}
                            placeholder="e.g. 5 min read"
                            className="w-full px-3 py-2 border border-[#1E293B] rounded-lg bg-[#0B0F19] text-white focus:outline-none focus:border-blue-500"
                          />
                        </div>

                        <div>
                          <label className="block font-bold text-slate-300 mb-1">Author Credit Name</label>
                          <input
                            type="text"
                            required
                            value={blogForm.author}
                            onChange={(e) => setBlogForm({ ...blogForm, author: e.target.value })}
                            className="w-full px-3 py-2 border border-[#1E293B] rounded-lg bg-[#0B0F19] text-white focus:outline-none focus:border-blue-500"
                          />
                        </div>

                        <div>
                          <label className="block font-bold text-slate-300 mb-1 flex items-center gap-1">
                            <Eye className="w-3.5 h-3.5 text-[#E1007A]" />
                            View Count Tracker
                          </label>
                          <input
                            type="number"
                            min="0"
                            value={blogForm.views}
                            onChange={(e) => setBlogForm({ ...blogForm, views: Math.max(0, parseInt(e.target.value) || 0) })}
                            className="w-full px-3 py-2 border border-[#1E293B] rounded-lg bg-[#0B0F19] text-white focus:outline-none focus:border-blue-500"
                          />
                        </div>

                        <div className="sm:col-span-2">
                          <label className="block font-bold text-slate-300 mb-1">Cover Image Link (Unsplash/Web)</label>
                          <input
                            type="text"
                            required
                            value={blogForm.image}
                            onChange={(e) => setBlogForm({ ...blogForm, image: e.target.value })}
                            className="w-full px-3 py-2 border border-[#1E293B] rounded-lg bg-[#0B0F19] text-white focus:outline-none focus:border-blue-500"
                          />
                        </div>

                        <div className="sm:col-span-2">
                          <label className="block font-bold text-slate-300 mb-1">Card Excerpt Summary (Quick overview)</label>
                          <textarea
                            required
                            rows={2}
                            value={blogForm.excerpt}
                            onChange={(e) => setBlogForm({ ...blogForm, excerpt: e.target.value })}
                            placeholder="Provide a 1-2 sentence description visible inside the catalog cards..."
                            className="w-full px-3 py-2 border border-[#1E293B] rounded-lg bg-[#0B0F19] text-white focus:outline-none focus:border-blue-500 resize-none"
                          ></textarea>
                        </div>

                        <div className="sm:col-span-2">
                          <div className="flex justify-between items-center mb-1">
                            <label className="font-bold text-slate-300">Article Body Content (Markdown supported)</label>
                            <span className="text-[11px] text-slate-400 font-mono">
                              Words: {blogForm.content ? blogForm.content.trim().split(/\s+/).filter(Boolean).length : 0} • Estimated Read: {Math.max(1, Math.ceil((blogForm.content ? blogForm.content.trim().split(/\s+/).filter(Boolean).length : 0) / 200))} min
                            </span>
                          </div>
                          <textarea
                            required
                            rows={8}
                            value={blogForm.content}
                            onChange={(e) => setBlogForm({ ...blogForm, content: e.target.value })}
                            placeholder="Write your article in markdown. Use ## for headers and - for bullet lists..."
                            className="w-full px-3 py-2 border border-[#1E293B] rounded-lg bg-[#0B0F19] text-white focus:outline-none focus:border-blue-500 resize-y font-mono"
                          ></textarea>
                        </div>

                        {/* On-Page SEO Section */}
                        <div className="sm:col-span-2 border-t border-[#1E293B] pt-4 mt-2 space-y-4">
                          <h4 className="font-bold text-amber-400 text-xs uppercase tracking-wider font-display">On-Page SEO Settings (WordPress Style)</h4>
                          
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div className="sm:col-span-2">
                              <label className="block font-bold text-slate-300 mb-1">SEO Title (metaTitle)</label>
                              <input
                                type="text"
                                value={blogForm.metaTitle}
                                onChange={(e) => setBlogForm({ ...blogForm, metaTitle: e.target.value })}
                                placeholder="Custom browser tab title. Defaults to Article Title if left blank."
                                className="w-full px-3 py-2 border border-[#1E293B] rounded-lg bg-[#0B0F19] text-white focus:outline-none focus:border-blue-500"
                              />
                            </div>

                            <div className="sm:col-span-2">
                              <label className="block font-bold text-slate-300 mb-1">Meta Description (metaDescription)</label>
                              <textarea
                                rows={2}
                                value={blogForm.metaDescription}
                                onChange={(e) => setBlogForm({ ...blogForm, metaDescription: e.target.value })}
                                placeholder="Short meta description summarizing article. Visible to search engine crawlers."
                                className="w-full px-3 py-2 border border-[#1E293B] rounded-lg bg-[#0B0F19] text-white focus:outline-none focus:border-blue-500 resize-none"
                              ></textarea>
                            </div>

                            <div className="sm:col-span-2">
                              <label className="block font-bold text-slate-300 mb-1">Target SEO Keywords (Comma separated)</label>
                              <input
                                type="text"
                                value={blogForm.keywords}
                                onChange={(e) => setBlogForm({ ...blogForm, keywords: e.target.value })}
                                placeholder="e.g. school setup guide, zero royalty school franchise, NEP 2020 curriculum"
                                className="w-full px-3 py-2 border border-[#1E293B] rounded-lg bg-[#0B0F19] text-white focus:outline-none focus:border-blue-500"
                              />
                            </div>
                          </div>
                        </div>

                      </div>

                      <div className="flex justify-end gap-3 pt-4 border-t border-[#1E293B]">
                        <button
                          type="button"
                          onClick={() => { setIsCreatingBlog(false); setEditingBlog(null); }}
                          className="px-4 py-2 border border-[#1E293B] hover:bg-slate-800 text-slate-300 font-bold rounded-lg cursor-pointer"
                        >
                          Cancel Draft
                        </button>
                        <button
                          type="submit"
                          className="px-6 py-2 bg-[#E1007A] hover:bg-[#c20068] text-white font-bold rounded-lg cursor-pointer"
                        >
                          {editingBlog ? 'Save Article Changes' : 'Publish Article Now'}
                        </button>
                      </div>
                    </form>
                  ) : (
                    /* Grid of existing blogs */
                    <div className="bg-[#0F172A] rounded-2xl border border-[#1E293B] shadow-sm overflow-hidden text-xs text-slate-100">
                      <div className="p-4 bg-[#0B0F19] font-bold text-white border-b border-[#1E293B] flex justify-between items-center">
                        <span>Published Catalog ({blogs.length} articles)</span>
                        <span className="text-[10px] text-slate-400 font-sans">Sorted by publish recency</span>
                      </div>
                      
                      {blogs.length === 0 ? (
                        <p className="p-8 text-center text-slate-400">No blogs in database catalog.</p>
                      ) : (
                        <div className="divide-y divide-[#1E293B]">
                          {blogs.map((blog) => {
                            const wordCount = blog.content ? blog.content.trim().split(/\s+/).filter(Boolean).length : 0;
                            return (
                              <div key={blog.id} className="p-4 hover:bg-slate-800/50 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                                <div className="space-y-1 flex-1">
                                  <div className="font-bold text-white text-sm leading-snug">{blog.title}</div>
                                  <div className="text-slate-400 text-[10px] flex items-center gap-2 flex-wrap">
                                    <span className="text-slate-300 font-medium">{blog.category}</span>
                                    <span>•</span>
                                    <span>By {blog.author}</span>
                                    <span>•</span>
                                    <span>{blog.date}</span>
                                    <span>•</span>
                                    <span className="text-slate-400">({wordCount} words)</span>
                                  </div>
                                </div>
                                
                                <div className="flex items-center gap-3 shrink-0">
                                  {/* Performance Trackers: Views & Read Time */}
                                  <div className="flex items-center gap-2 font-mono">
                                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-[#E1007A]/10 text-[#E1007A] font-bold text-[11px] border border-[#E1007A]/20" title="Public View Count Tracker">
                                      <Eye className="w-3.5 h-3.5 text-[#E1007A]" />
                                      {(blog.views || 0).toLocaleString()}
                                    </span>

                                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-sky-500/10 text-sky-300 font-bold text-[11px] border border-sky-500/20" title="Estimated Reading Time Tracker">
                                      <Clock className="w-3.5 h-3.5 text-sky-400" />
                                      {blog.readTime}
                                    </span>
                                  </div>

                                  <button
                                    onClick={() => {
                                      setEditingBlog(blog);
                                      setBlogForm({
                                        title: blog.title, category: blog.category, excerpt: blog.excerpt,
                                        content: blog.content, image: blog.image, author: blog.author, readTime: blog.readTime,
                                        views: blog.views || 0,
                                        metaTitle: blog.metaTitle || '', metaDescription: blog.metaDescription || '', keywords: blog.keywords || ''
                                      });
                                    }}
                                    className="p-1.5 border border-[#1E293B] hover:bg-slate-800 text-slate-300 hover:text-white rounded transition-colors cursor-pointer"
                                    title="Edit Post"
                                  >
                                    <Edit className="w-4.5 h-4.5" />
                                  </button>
                                  <button
                                    onClick={() => deleteBlog(blog.id)}
                                    className="p-1.5 border border-rose-500/30 hover:bg-rose-500/10 text-rose-400 rounded transition-colors cursor-pointer"
                                    title="Delete Post"
                                  >
                                    <Trash className="w-4.5 h-4.5" />
                                  </button>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  )}

                </div>
              )}

              {/* --- 4. FAQ MANAGER CRUD VIEW --- */}
              {activeAdminTab === 'faqs' && (
                <div className="space-y-6">
                  
                  <div className="flex justify-between items-center flex-wrap gap-4">
                    <div>
                      <h2 className="text-lg font-bold text-stone-950 font-display">Manage Portal FAQs</h2>
                      <p className="text-[11px] text-stone-500 font-sans">Add or modify sitemap questions displayed on the portal.</p>
                    </div>

                    {!isCreatingFaq && !editingFaq && (
                      <button
                        onClick={() => {
                          setIsCreatingFaq(true);
                          setEditingFaq(null);
                          setFaqForm({ question: '', answer: '', section: 'home' });
                        }}
                        className="px-4 py-2 bg-[#E1007A] hover:bg-[#c20068] text-white text-xs font-bold rounded-lg flex items-center gap-1 cursor-pointer"
                      >
                        <Plus className="w-4 h-4" />
                        <span>Add FAQ Question</span>
                      </button>
                    )}
                  </div>

                  {/* FAQ Create / Edit panel */}
                  {(isCreatingFaq || editingFaq) ? (
                    <form onSubmit={saveFaq} className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm space-y-4 animate-scale-up text-xs">
                      <h3 className="font-extrabold text-stone-900 text-sm font-display border-b border-stone-100 pb-2">
                        {editingFaq ? 'Modify FAQ Entry' : 'Create New FAQ Entry'}
                      </h3>

                      <div className="grid grid-cols-1 gap-4">
                        <div>
                          <label className="block font-bold text-stone-700 mb-1">FAQ Section Placement</label>
                          <select
                            value={faqForm.section}
                            onChange={(e) => setFaqForm({ ...faqForm, section: e.target.value as any })}
                            className="w-full px-3 py-2 border border-stone-300 rounded-lg bg-stone-50 focus:outline-none"
                          >
                            <option value="home">Home Page Portal FAQs</option>
                            <option value="investor">Investor Financial FAQs</option>
                            <option value="fwa">Finnish Way Academy Academic FAQs</option>
                          </select>
                        </div>

                        <div>
                          <label className="block font-bold text-stone-700 mb-1">Question Text</label>
                          <input
                            type="text"
                            required
                            value={faqForm.question}
                            onChange={(e) => setFaqForm({ ...faqForm, question: e.target.value })}
                            placeholder="e.g. What is the typical capital break-even timeline?"
                            className="w-full px-3 py-2 border border-stone-300 rounded-lg bg-stone-50 focus:outline-none"
                          />
                        </div>

                        <div>
                          <label className="block font-bold text-stone-700 mb-1">Answer Text</label>
                          <textarea
                            required
                            rows={4}
                            value={faqForm.answer}
                            onChange={(e) => setFaqForm({ ...faqForm, answer: e.target.value })}
                            placeholder="Provide a clear, helpful and thorough response..."
                            className="w-full px-3 py-2 border border-stone-300 rounded-lg bg-stone-50 focus:outline-none resize-y"
                          ></textarea>
                        </div>
                      </div>

                      <div className="flex justify-end gap-3 pt-4 border-t border-stone-100">
                        <button
                          type="button"
                          onClick={() => { setIsCreatingFaq(false); setEditingFaq(null); }}
                          className="px-4 py-2 border border-stone-300 hover:bg-stone-50 text-stone-700 font-bold rounded-lg cursor-pointer"
                        >
                          Cancel
                        </button>
                        <button
                          type="submit"
                          className="px-6 py-2 bg-[#E1007A] hover:bg-[#c20068] text-white font-bold rounded-lg cursor-pointer"
                        >
                          {editingFaq ? 'Save FAQ Item' : 'Publish FAQ Item'}
                        </button>
                      </div>
                    </form>
                  ) : (
                    /* List of existing FAQs */
                    <div className="bg-white rounded-2xl border border-stone-200 shadow-sm overflow-hidden text-xs">
                      <div className="p-4 bg-stone-50 font-bold text-stone-900 border-b border-stone-200">
                        Frequently Asked Questions Database
                      </div>
                      
                      {faqs.length === 0 ? (
                        <p className="p-8 text-center text-stone-400">No FAQ entries stored.</p>
                      ) : (
                        <div className="divide-y divide-stone-100">
                          {faqs.map((faq) => (
                            <div key={faq.id} className="p-4 hover:bg-stone-50/50 flex justify-between items-start gap-4">
                              <div className="space-y-1">
                                <div className="font-bold text-stone-900">{faq.question}</div>
                                <p className="text-stone-500 text-[10px] max-w-xl font-sans mt-0.5">{faq.answer}</p>
                                <span className="inline-block px-1.5 py-0.5 bg-stone-100 text-[9px] font-bold text-stone-500 rounded uppercase font-mono">Section: {faq.section}</span>
                              </div>
                              
                              <div className="flex items-center gap-1.5 shrink-0">
                                <button
                                  onClick={() => {
                                    setEditingFaq(faq);
                                    setFaqForm({ question: faq.question, answer: faq.answer, section: faq.section });
                                  }}
                                  className="p-1 border border-stone-200 hover:bg-stone-50 hover:border-stone-400 text-stone-700 rounded transition-colors cursor-pointer"
                                  title="Edit FAQ"
                                >
                                  <Edit className="w-4 h-4" />
                                </button>
                                <button
                                  onClick={() => deleteFaq(faq.id)}
                                  className="p-1 border border-stone-200 hover:bg-rose-50 hover:border-rose-300 text-rose-700 rounded transition-colors cursor-pointer"
                                  title="Delete FAQ"
                                >
                                  <Trash className="w-4 h-4" />
                                </button>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  )}

                </div>
              )}

              {/* --- 6. PAGE CONTENT & DEDICATED SEO MODULE --- */}
              {activeAdminTab === 'pages' && (
                <div className="space-y-6 animate-fade-in" id="admin-pages-tab">
                  
                  {pageSuccess && (
                    <div className="p-4 bg-emerald-500/10 border border-emerald-500/30 rounded-2xl text-emerald-300 text-xs font-bold flex items-center gap-2 shadow-sm">
                      <Check className="w-5 h-5 text-emerald-400 shrink-0" />
                      <span>{pageSuccess}</span>
                    </div>
                  )}

                  {!editingPage ? (
                    <div className="space-y-5">
                      <div className="bg-gradient-to-r from-slate-900 via-[#0F172A] to-slate-900 p-6 sm:p-7 rounded-3xl border border-[#1E293B] shadow-xl text-white flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="px-2.5 py-0.5 bg-[#E1007A]/20 border border-[#E1007A]/40 text-[#E1007A] text-[10px] font-extrabold uppercase rounded-full tracking-wider">SEO Control Center</span>
                            <span className="text-[10px] text-cyan-400 font-mono">Live Audit Mode</span>
                          </div>
                          <h2 className="text-xl font-black font-display mt-1">Page Meta Tags & Search Engine Indexing</h2>
                          <p className="text-slate-300 text-xs mt-1 font-sans max-w-2xl leading-relaxed">
                            Configure Meta Titles, Meta Descriptions, and target Keywords with live character length validation to maximize search ranking on Google & Bing.
                          </p>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {pages?.map((page: any) => {
                          const metaTitle = page.metaTitle || page.title || '';
                          const metaDesc = page.metaDescription || page.subtitle || '';
                          const keywords = page.keywords || '';
                          const titleLen = metaTitle.length;
                          const descLen = metaDesc.length;
                          const kwCount = keywords.split(',').filter((k: string) => k.trim().length > 0).length;

                          return (
                            <div key={page.id} className="bg-[#0F172A] p-5 rounded-2xl border border-[#1E293B] shadow-lg hover:border-slate-700 transition-all flex flex-col justify-between space-y-4">
                              <div className="space-y-3">
                                <div className="flex items-center justify-between">
                                  <span className="px-2.5 py-1 bg-[#0B0F19] border border-[#1E293B] text-cyan-400 rounded-md text-[10px] font-extrabold uppercase tracking-wide">
                                    Page ID: {page.id}
                                  </span>
                                  <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                                    titleLen >= 50 && titleLen <= 60 && descLen >= 120 && descLen <= 160
                                      ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                                      : 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                                  }`}>
                                    {titleLen >= 50 && titleLen <= 60 && descLen >= 120 && descLen <= 160 ? 'SEO Optimal' : 'SEO Needs Review'}
                                  </span>
                                </div>

                                <div>
                                  <h3 className="font-extrabold text-white text-sm font-display leading-tight">{page.title}</h3>
                                  <p className="text-slate-400 text-xs line-clamp-1 font-sans mt-0.5">{page.subtitle}</p>
                                </div>

                                <div className="pt-3 border-t border-[#1E293B] space-y-2 text-[11px] text-slate-300 font-sans">
                                  <div>
                                    <div className="flex justify-between font-semibold text-slate-300 text-[10px]">
                                      <span>Meta Title ({titleLen}/60 chars)</span>
                                      <span className={titleLen >= 50 && titleLen <= 60 ? 'text-emerald-400 font-bold' : 'text-amber-400'}>
                                        {titleLen === 0 ? 'Empty' : titleLen <= 60 ? `${60 - titleLen} left` : `${titleLen - 60} over limit`}
                                      </span>
                                    </div>
                                    <span className="truncate block font-medium text-slate-200 bg-[#0B0F19] px-2.5 py-1.5 rounded border border-[#1E293B] mt-0.5 text-[11px]">
                                      {metaTitle || <span className="text-slate-500 italic">Not specified</span>}
                                    </span>
                                  </div>

                                  <div>
                                    <div className="flex justify-between font-semibold text-slate-300 text-[10px]">
                                      <span>Meta Description ({descLen}/160 chars)</span>
                                      <span className={descLen >= 120 && descLen <= 160 ? 'text-emerald-400 font-bold' : 'text-amber-400'}>
                                        {descLen === 0 ? 'Empty' : descLen <= 160 ? `${160 - descLen} left` : `${descLen - 160} over limit`}
                                      </span>
                                    </div>
                                    <span className="line-clamp-2 block font-medium text-slate-300 bg-[#0B0F19] px-2.5 py-1.5 rounded border border-[#1E293B] mt-0.5 text-[10px] leading-tight">
                                      {metaDesc || <span className="text-slate-500 italic">Not specified</span>}
                                    </span>
                                  </div>

                                  <div className="flex items-center justify-between pt-1 text-[10px]">
                                    <span className="font-bold text-slate-400">Keywords Count:</span>
                                    <span className="px-2 py-0.5 bg-[#0B0F19] border border-[#1E293B] text-cyan-300 rounded font-bold font-mono">{kwCount} tags</span>
                                  </div>
                                </div>
                              </div>

                              <button
                                onClick={() => selectPage(page)}
                                className="w-full py-2.5 bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 hover:from-[#E1007A] hover:to-[#F79F33] text-white font-extrabold text-xs rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md"
                              >
                                <Edit className="w-3.5 h-3.5 text-white" />
                                <span>Edit SEO Settings & Content</span>
                              </button>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  ) : (
                    <form onSubmit={savePage} className="bg-[#0F172A] p-6 sm:p-8 rounded-3xl border border-[#1E293B] shadow-2xl space-y-7 text-xs text-slate-200">
                      
                      {/* Top Bar Header */}
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-[#1E293B] pb-5 gap-3">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="px-2.5 py-0.5 bg-[#E1007A]/20 text-[#E1007A] border border-[#E1007A]/30 font-extrabold rounded text-[10px] uppercase tracking-wider">
                              SEO Module Editor
                            </span>
                            <span className="text-[10px] font-mono text-cyan-400 bg-[#0B0F19] px-2 py-0.5 rounded border border-[#1E293B]">
                              Target ID: {editingPage.id}
                            </span>
                          </div>
                          <h3 className="font-black text-white text-xl font-display mt-1">
                            SEO & Metadata Settings: {editingPage.title}
                          </h3>
                        </div>

                        <div className="flex items-center gap-2.5 shrink-0">
                          <button
                            type="button"
                            onClick={() => {
                              // Auto optimize button
                              const autoTitle = pageForm.title ? (pageForm.title.length <= 45 ? `${pageForm.title} | KinderBee KIPS` : pageForm.title) : editingPage.title;
                              const autoDesc = pageForm.subtitle ? (pageForm.subtitle.length > 155 ? pageForm.subtitle.substring(0, 152) + '...' : pageForm.subtitle) : '';
                              const autoKw = pageForm.keywords || 'kinderbee, kips education, zero royalty school, preschool franchise, nep 2020 curriculum';
                              setPageForm({
                                ...pageForm,
                                metaTitle: autoTitle,
                                metaDescription: autoDesc,
                                keywords: autoKw
                              });
                            }}
                            className="px-3.5 py-2.5 bg-gradient-to-r from-[#E1007A] to-[#F79F33] hover:opacity-95 text-white font-extrabold rounded-xl transition-all flex items-center gap-1.5 cursor-pointer text-[11px] shadow-md"
                            title="Auto-fill recommended SEO title and description from page title"
                          >
                            <Sparkles className="w-4 h-4 text-white" />
                            <span>Auto-Generate SEO Metadata</span>
                          </button>
                          
                          <button
                            type="button"
                            onClick={() => setEditingPage(null)}
                            className="px-4 py-2.5 bg-[#1E293B] hover:bg-slate-700 text-slate-200 border border-slate-600 rounded-xl font-bold transition-all cursor-pointer text-[11px]"
                          >
                            Cancel
                          </button>
                        </div>
                      </div>

                      {/* --- 1. LIVE GOOGLE SEARCH SNIPPET PREVIEW --- */}
                      <div className="bg-[#0B0F19] text-white p-5 rounded-2xl border border-[#1E293B] space-y-3 shadow-inner">
                        <div className="flex items-center justify-between border-b border-[#1E293B] pb-2.5">
                          <div className="flex items-center gap-2">
                            <Globe className="w-4 h-4 text-[#E1007A]" />
                            <span className="font-extrabold text-xs text-slate-200 font-display">Live Google Search Snippet Preview</span>
                          </div>
                          <div className="flex items-center bg-[#1E293B] p-0.5 rounded-lg border border-slate-700 text-[10px]">
                            <button
                              type="button"
                              onClick={() => setSeoPreviewDevice('desktop')}
                              className={`px-2.5 py-1 rounded-md font-bold transition-all cursor-pointer ${
                                seoPreviewDevice === 'desktop' ? 'bg-[#E1007A] text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
                              }`}
                            >
                              Desktop Result
                            </button>
                            <button
                              type="button"
                              onClick={() => setSeoPreviewDevice('mobile')}
                              className={`px-2.5 py-1 rounded-md font-bold transition-all cursor-pointer ${
                                seoPreviewDevice === 'mobile' ? 'bg-[#E1007A] text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
                              }`}
                            >
                              Mobile Result
                            </button>
                          </div>
                        </div>

                        {/* Search Card Simulation */}
                        <div className={`bg-white text-stone-900 rounded-xl p-4 shadow-md font-sans transition-all ${
                          seoPreviewDevice === 'mobile' ? 'max-w-md mx-auto border-2 border-stone-300' : 'w-full'
                        }`}>
                          <div className="flex items-center gap-2 text-[11px] text-stone-600 mb-1">
                            <div className="w-4 h-4 rounded-full bg-[#E1007A] text-white flex items-center justify-center font-bold text-[9px]">K</div>
                            <span className="font-semibold text-stone-800">KinderBee KIPS</span>
                            <span className="text-stone-400">•</span>
                            <span className="text-stone-500 truncate">https://kips.kinderbee.in › {editingPage.id}</span>
                          </div>

                          {/* Simulated Blue Title Link */}
                          <h4 className="text-blue-700 hover:underline font-semibold text-base sm:text-lg cursor-pointer leading-snug line-clamp-1">
                            {(pageForm.metaTitle || pageForm.title || 'Page Title').substring(0, 60)}
                            {(pageForm.metaTitle || pageForm.title || '').length > 60 ? '...' : ''}
                          </h4>

                          {/* Simulated Description */}
                          <p className="text-stone-600 text-xs mt-1 leading-relaxed line-clamp-2">
                            {(pageForm.metaDescription || pageForm.subtitle || 'Configure a compelling meta description to attract organic search clicks on Google.').substring(0, 160)}
                            {(pageForm.metaDescription || pageForm.subtitle || '').length > 160 ? '...' : ''}
                          </p>
                        </div>
                      </div>

                      {/* --- 2. DEDICATED SEO INPUT FIELDS & LIVE CHARACTER COUNTING VALIDATION --- */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
                        
                        {/* Meta Title Field with Validation */}
                        <div className="space-y-2.5 md:col-span-2 bg-[#0B0F19] p-5 rounded-2xl border border-[#1E293B]">
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1.5">
                            <label className="font-extrabold text-white text-xs uppercase tracking-wider flex items-center gap-1.5">
                              <span>Meta Title</span>
                              <span className="text-[10px] text-slate-400 font-normal font-sans">(Browser Tab & Google Headline)</span>
                            </label>
                            
                            {/* Live Character Count Indicator */}
                            <div className="flex items-center gap-2 text-[11px] font-mono">
                              <span className="font-bold text-slate-300">
                                Length: <span className={
                                  pageForm.metaTitle.length >= 50 && pageForm.metaTitle.length <= 60
                                    ? 'text-emerald-400 font-extrabold'
                                    : pageForm.metaTitle.length > 60
                                    ? 'text-rose-400 font-extrabold'
                                    : 'text-amber-400 font-bold'
                                }>{pageForm.metaTitle.length}</span> / 60 Chars
                              </span>

                              {/* Status Badge */}
                              <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-extrabold font-sans border ${
                                pageForm.metaTitle.length === 0
                                  ? 'bg-slate-800 text-slate-300 border-slate-700'
                                  : pageForm.metaTitle.length >= 50 && pageForm.metaTitle.length <= 60
                                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                                  : pageForm.metaTitle.length > 60
                                  ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                                  : 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                              }`}>
                                {pageForm.metaTitle.length === 0 && 'Empty (Fallback to Title)'}
                                {pageForm.metaTitle.length > 0 && pageForm.metaTitle.length < 50 && 'Too Short (<50 chars)'}
                                {pageForm.metaTitle.length >= 50 && pageForm.metaTitle.length <= 60 && 'Optimal Length (50–60)'}
                                {pageForm.metaTitle.length > 60 && 'Too Long (>60 chars will cut off)'}
                              </span>
                            </div>
                          </div>

                          <input
                            type="text"
                            value={pageForm.metaTitle}
                            onChange={(e) => setPageForm({ ...pageForm, metaTitle: e.target.value })}
                            placeholder={pageForm.title || "e.g. KIPS Preschool Partnership & Franchise Models | KinderBee"}
                            className="w-full px-4 py-3 bg-[#1E293B] border border-slate-700 rounded-xl text-white font-medium focus:outline-none focus:border-[#E1007A] focus:ring-1 focus:ring-[#E1007A] text-xs shadow-inner placeholder-slate-500"
                          />

                          {/* Visual Progress Bar Indicator */}
                          <div className="space-y-1 pt-1">
                            <div className="w-full h-2 bg-[#1E293B] rounded-full overflow-hidden border border-slate-700">
                              <div
                                className={`h-full transition-all duration-300 ${
                                  pageForm.metaTitle.length >= 50 && pageForm.metaTitle.length <= 60
                                    ? 'bg-emerald-400'
                                    : pageForm.metaTitle.length > 60
                                    ? 'bg-rose-500'
                                    : 'bg-amber-400'
                                }`}
                                style={{ width: `${Math.min(100, (pageForm.metaTitle.length / 60) * 100)}%` }}
                              ></div>
                            </div>
                            <div className="flex justify-between text-[10px] text-slate-400 font-sans">
                              <span>0 chars</span>
                              <span className="font-bold text-slate-300">50-60 chars (Recommended)</span>
                              <span>70+ chars</span>
                            </div>
                          </div>
                        </div>

                        {/* Meta Description Field with Validation */}
                        <div className="space-y-2.5 md:col-span-2 bg-[#0B0F19] p-5 rounded-2xl border border-[#1E293B]">
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1.5">
                            <label className="font-extrabold text-white text-xs uppercase tracking-wider flex items-center gap-1.5">
                              <span>Meta Description</span>
                              <span className="text-[10px] text-slate-400 font-normal font-sans">(Google Result Snippet Text)</span>
                            </label>
                            
                            {/* Live Character Count Indicator */}
                            <div className="flex items-center gap-2 text-[11px] font-mono">
                              <span className="font-bold text-slate-300">
                                Length: <span className={
                                  pageForm.metaDescription.length >= 120 && pageForm.metaDescription.length <= 160
                                    ? 'text-emerald-400 font-extrabold'
                                    : pageForm.metaDescription.length > 160
                                    ? 'text-rose-400 font-extrabold'
                                    : 'text-amber-400 font-bold'
                                }>{pageForm.metaDescription.length}</span> / 160 Chars
                              </span>

                              {/* Status Badge */}
                              <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-extrabold font-sans border ${
                                pageForm.metaDescription.length === 0
                                  ? 'bg-slate-800 text-slate-300 border-slate-700'
                                  : pageForm.metaDescription.length >= 120 && pageForm.metaDescription.length <= 160
                                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                                  : pageForm.metaDescription.length > 160
                                  ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                                  : 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                              }`}>
                                {pageForm.metaDescription.length === 0 && 'Empty (Google auto-generates)'}
                                {pageForm.metaDescription.length > 0 && pageForm.metaDescription.length < 120 && 'Too Short (<120 chars)'}
                                {pageForm.metaDescription.length >= 120 && pageForm.metaDescription.length <= 160 && 'Optimal Length (120–160)'}
                                {pageForm.metaDescription.length > 160 && 'Too Long (>160 chars will cut off)'}
                              </span>
                            </div>
                          </div>

                          <textarea
                            rows={3}
                            value={pageForm.metaDescription}
                            onChange={(e) => setPageForm({ ...pageForm, metaDescription: e.target.value })}
                            placeholder={pageForm.subtitle || "Provide a concise summary highlighting your Nordic early childhood education curriculum and zero royalty business opportunity."}
                            className="w-full px-4 py-3 bg-[#1E293B] border border-slate-700 rounded-xl text-white font-medium focus:outline-none focus:border-[#E1007A] focus:ring-1 focus:ring-[#E1007A] text-xs shadow-inner placeholder-slate-500 resize-y leading-relaxed"
                          ></textarea>

                          {/* Visual Progress Bar Indicator */}
                          <div className="space-y-1 pt-1">
                            <div className="w-full h-2 bg-[#1E293B] rounded-full overflow-hidden border border-slate-700">
                              <div
                                className={`h-full transition-all duration-300 ${
                                  pageForm.metaDescription.length >= 120 && pageForm.metaDescription.length <= 160
                                    ? 'bg-emerald-400'
                                    : pageForm.metaDescription.length > 160
                                    ? 'bg-rose-500'
                                    : 'bg-amber-400'
                                }`}
                                style={{ width: `${Math.min(100, (pageForm.metaDescription.length / 160) * 100)}%` }}
                              ></div>
                            </div>
                            <div className="flex justify-between text-[10px] text-slate-400 font-sans">
                              <span>0 chars</span>
                              <span className="font-bold text-slate-300">120-160 chars (Recommended)</span>
                              <span>180+ chars</span>
                            </div>
                          </div>
                        </div>

                        {/* Keywords Field & Tag Pills */}
                        <div className="space-y-2.5 md:col-span-2 bg-[#0B0F19] p-5 rounded-2xl border border-[#1E293B]">
                          <div className="flex items-center justify-between">
                            <label className="font-extrabold text-white text-xs uppercase tracking-wider">
                              Target Meta Keywords
                            </label>
                            <span className="text-[10px] text-cyan-400 font-mono font-bold bg-[#1E293B] px-2 py-0.5 rounded border border-slate-700">
                              {pageForm.keywords.split(',').filter((k: string) => k.trim().length > 0).length} Keywords Tagged
                            </span>
                          </div>

                          <input
                            type="text"
                            value={pageForm.keywords}
                            onChange={(e) => setPageForm({ ...pageForm, keywords: e.target.value })}
                            placeholder="e.g. kinderbee, kips education, preschool partnership, zero royalty school, nep 2020 curriculum"
                            className="w-full px-4 py-3 bg-[#1E293B] border border-slate-700 rounded-xl text-white font-medium focus:outline-none focus:border-[#E1007A] focus:ring-1 focus:ring-[#E1007A] text-xs shadow-inner placeholder-slate-500"
                          />

                          {/* Active Keyword Tags Pills Display */}
                          {pageForm.keywords.trim().length > 0 && (
                            <div className="pt-2 flex flex-wrap gap-1.5">
                              {pageForm.keywords.split(',').map((kw, idx) => {
                                const cleanKw = kw.trim();
                                if (!cleanKw) return null;
                                return (
                                  <span key={idx} className="inline-flex items-center gap-1 px-2.5 py-1 bg-[#1E293B] text-cyan-300 text-[10px] font-bold rounded-lg font-mono border border-slate-700">
                                    <span>#{cleanKw}</span>
                                  </span>
                                );
                              })}
                            </div>
                          )}

                          {/* Suggested Keywords Shortcuts */}
                          <div className="pt-2.5 border-t border-[#1E293B] flex flex-wrap items-center gap-1.5 text-[10px]">
                            <span className="font-bold text-slate-400">Quick Add Suggestions:</span>
                            {['kips education', 'zero royalty franchise', 'nordic preschool', 'nep 2020 teacher training', 'school setup partner'].map((sug, idx) => (
                              <button
                                key={idx}
                                type="button"
                                onClick={() => {
                                  const currentList = pageForm.keywords.split(',').map(k => k.trim()).filter(Boolean);
                                  if (!currentList.includes(sug)) {
                                    const updated = [...currentList, sug].join(', ');
                                    setPageForm({ ...pageForm, keywords: updated });
                                  }
                                }}
                                className="px-2.5 py-1 bg-[#1E293B] hover:bg-[#E1007A]/20 hover:text-[#E1007A] text-slate-300 border border-slate-700 hover:border-[#E1007A]/40 rounded-lg font-medium transition-all cursor-pointer"
                              >
                                + {sug}
                              </button>
                            ))}
                          </div>
                        </div>

                      </div>

                      {/* --- 3. PAGE CONTENT FIELDS --- */}
                      <div className="border-t border-[#1E293B] pt-6 space-y-4">
                        <div className="flex items-center gap-2">
                          <Sliders className="w-4 h-4 text-[#E1007A]" />
                          <h4 className="font-extrabold text-white text-sm font-display uppercase tracking-wider">
                            Page Hero Content & Headings
                          </h4>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          
                          {/* Eyebrow badge text */}
                          <div>
                            <label className="block font-bold text-slate-300 mb-1.5 uppercase tracking-wide text-[10px]">Eyebrow / Badge Tagline</label>
                            <input
                              type="text"
                              value={pageForm.badgeText}
                              onChange={(e) => setPageForm({ ...pageForm, badgeText: e.target.value })}
                              placeholder="e.g. The KIPS Advantage"
                              className="w-full px-4 py-2.5 bg-[#1E293B] border border-slate-700 rounded-xl text-white font-medium focus:outline-none focus:border-[#E1007A] focus:ring-1 focus:ring-[#E1007A] text-xs placeholder-slate-500"
                            />
                          </div>

                          {/* Extra content tagline */}
                          <div>
                            <label className="block font-bold text-slate-300 mb-1.5 uppercase tracking-wide text-[10px]">Hero Secondary Tagline (Optional)</label>
                            <input
                              type="text"
                              value={pageForm.content1}
                              onChange={(e) => setPageForm({ ...pageForm, content1: e.target.value })}
                              placeholder='e.g. "Empowering Educators through Nordic Excellence"'
                              className="w-full px-4 py-2.5 bg-[#1E293B] border border-slate-700 rounded-xl text-white font-medium focus:outline-none focus:border-[#E1007A] focus:ring-1 focus:ring-[#E1007A] text-xs placeholder-slate-500"
                            />
                          </div>

                          {/* Page title */}
                          <div className="md:col-span-2">
                            <label className="block font-bold text-slate-300 mb-1.5 uppercase tracking-wide text-[10px]">Main Page Headline (H1 Heading)</label>
                            <input
                              type="text"
                              required
                              value={pageForm.title}
                              onChange={(e) => setPageForm({ ...pageForm, title: e.target.value })}
                              className="w-full px-4 py-2.5 bg-[#1E293B] border border-slate-700 rounded-xl text-white font-extrabold focus:outline-none focus:border-[#E1007A] focus:ring-1 focus:ring-[#E1007A] text-xs placeholder-slate-500"
                            />
                          </div>

                          {/* Page subtitle */}
                          <div className="md:col-span-2">
                            <label className="block font-bold text-slate-300 mb-1.5 uppercase tracking-wide text-[10px]">Page Core Subtitle / Description</label>
                            <textarea
                              required
                              rows={3}
                              value={pageForm.subtitle}
                              onChange={(e) => setPageForm({ ...pageForm, subtitle: e.target.value })}
                              className="w-full px-4 py-2.5 bg-[#1E293B] border border-slate-700 rounded-xl text-white font-medium focus:outline-none focus:border-[#E1007A] focus:ring-1 focus:ring-[#E1007A] text-xs placeholder-slate-500 resize-y leading-relaxed"
                            ></textarea>
                          </div>

                        </div>
                      </div>

                      {/* Submit & Cancel Footer Bar */}
                      <div className="pt-5 border-t border-[#1E293B] flex flex-col sm:flex-row items-center justify-between gap-3">
                        <div className="text-[11px] text-slate-400 font-sans">
                          * Updates apply across all public pages instantly upon saving.
                        </div>

                        <div className="flex items-center gap-3 w-full sm:w-auto">
                          <button
                            type="button"
                            onClick={() => setEditingPage(null)}
                            className="w-full sm:w-auto px-5 py-2.5 bg-[#1E293B] hover:bg-slate-700 text-slate-200 border border-slate-600 font-bold rounded-xl text-xs transition-colors cursor-pointer"
                          >
                            Cancel Changes
                          </button>
                          <button
                            type="submit"
                            className="w-full sm:w-auto px-7 py-2.5 bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 hover:brightness-110 text-white font-black rounded-xl text-xs transition-all shadow-lg cursor-pointer flex items-center justify-center gap-2"
                          >
                            <Check className="w-4 h-4 text-white" />
                            <span>Save SEO & Page Settings</span>
                          </button>
                        </div>
                      </div>

                    </form>
                  )}

                </div>
              )}

              {/* --- 5. SYSTEM SETTINGS CONFIG --- */}
              {activeAdminTab === 'settings' && (
                <div className="space-y-6">
                  
                  {settingsSuccess && (
                    <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs font-bold flex items-center gap-2">
                      <Check className="w-5 h-5 text-emerald-600" />
                      <span>{settingsSuccess}</span>
                    </div>
                  )}

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
                    
                    {/* Public details card */}
                    <form onSubmit={saveSettings} className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm space-y-4">
                      <h3 className="font-extrabold text-stone-900 text-sm font-display border-b border-stone-100 pb-2">Public Contact Coordinates</h3>
                      
                      <div>
                        <label className="block font-bold text-stone-700 mb-1">Corporate Hotline Phone</label>
                        <input
                          type="text"
                          required
                          value={settingsForm.phone}
                          onChange={(e) => setSettingsForm({ ...settingsForm, phone: e.target.value })}
                          className="w-full px-3 py-2 border border-stone-300 rounded-lg bg-stone-50 focus:outline-none"
                        />
                      </div>

                      <div>
                        <label className="block font-bold text-stone-700 mb-1">Corporate Support Email</label>
                        <input
                          type="email"
                          required
                          value={settingsForm.email}
                          onChange={(e) => setSettingsForm({ ...settingsForm, email: e.target.value })}
                          className="w-full px-3 py-2 border border-stone-300 rounded-lg bg-stone-50 focus:outline-none"
                        />
                      </div>

                      <div>
                        <label className="block font-bold text-stone-700 mb-1">WhatsApp Integration Number</label>
                        <input
                          type="text"
                          required
                          value={settingsForm.whatsappNumber}
                          onChange={(e) => setSettingsForm({ ...settingsForm, whatsappNumber: e.target.value })}
                          placeholder="e.g. +919876543210 (include country code)"
                          className="w-full px-3 py-2 border border-stone-300 rounded-lg bg-stone-50 focus:outline-none"
                        />
                      </div>

                      <div>
                        <label className="block font-bold text-stone-700 mb-1">HQ Office Address (Visible on footer & contact pages)</label>
                        <textarea
                          required
                          rows={3}
                          value={settingsForm.officeAddress}
                          onChange={(e) => setSettingsForm({ ...settingsForm, officeAddress: e.target.value })}
                          className="w-full px-3 py-2 border border-stone-300 rounded-lg bg-stone-50 focus:outline-none resize-none"
                        ></textarea>
                      </div>

                      <button
                        type="submit"
                        className="w-full py-2.5 bg-stone-900 hover:bg-stone-800 text-white font-bold rounded-lg transition-colors cursor-pointer"
                      >
                        Update Public Coordinates
                      </button>
                    </form>

                    {/* Pop-up Modal Lead Form & Left Image Poster Management Card */}
                    <form onSubmit={saveSettings} className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm space-y-4 md:col-span-2">
                      <div className="flex items-center justify-between border-b border-stone-100 pb-2">
                        <div className="flex items-center gap-2">
                          <Sparkles className="w-4 h-4 text-amber-500" />
                          <h3 className="font-extrabold text-stone-900 text-sm font-display">Lead Pop-up & Left Poster Image Settings</h3>
                        </div>
                        <span className="text-[10px] font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded-full border border-amber-200">
                          Desktop & Mobile Pop-up
                        </span>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        
                        {/* Left column: Poster image configuration & live thumbnail preview */}
                        <div className="space-y-3 bg-stone-50 p-4 rounded-xl border border-stone-200">
                          <label className="block font-bold text-stone-800 text-xs">
                            Left Poster Image URL <span className="text-stone-500 font-normal">(Shown on left side of popup)</span>
                          </label>
                          <input
                            type="text"
                            value={settingsForm.popupImageUrl || ''}
                            onChange={(e) => setSettingsForm({ ...settingsForm, popupImageUrl: e.target.value })}
                            placeholder="https://images.unsplash.com/photo-..."
                            className="w-full px-3 py-2 text-xs border border-stone-300 rounded-lg bg-white focus:outline-none font-mono"
                          />

                          {/* Image Live Preview */}
                          <div className="relative aspect-[16/9] sm:aspect-[4/3] rounded-lg overflow-hidden border border-stone-200 bg-stone-900 shadow-inner">
                            <img
                              src={settingsForm.popupImageUrl || 'https://images.unsplash.com/photo-1577896851231-70ef18881754?auto=format&fit=crop&q=80&w=800'}
                              alt="Popup Preview"
                              className="w-full h-full object-cover opacity-75"
                            />
                            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent flex items-end p-3 text-white text-[10px]">
                              <span>Live Poster Preview in Popup</span>
                            </div>
                          </div>

                          {/* Quick Presets */}
                          <div className="pt-1">
                            <span className="text-[10px] font-bold text-stone-500 block mb-1.5">Quick Choose High-Res Poster Presets:</span>
                            <div className="grid grid-cols-2 gap-1.5 text-[10px]">
                              <button
                                type="button"
                                onClick={() => setSettingsForm({
                                  ...settingsForm,
                                  popupImageUrl: 'https://images.unsplash.com/photo-1577896851231-70ef18881754?auto=format&fit=crop&q=80&w=800'
                                })}
                                className="px-2 py-1.5 bg-white hover:bg-stone-200 border border-stone-200 rounded font-semibold text-stone-700 text-left truncate"
                              >
                                🏫 Modern Campus
                              </button>
                              <button
                                type="button"
                                onClick={() => setSettingsForm({
                                  ...settingsForm,
                                  popupImageUrl: 'https://images.unsplash.com/photo-1503676260728-1c00da094a0b?auto=format&fit=crop&q=80&w=800'
                                })}
                                className="px-2 py-1.5 bg-white hover:bg-stone-200 border border-stone-200 rounded font-semibold text-stone-700 text-left truncate"
                              >
                                🎨 Playful Learning
                              </button>
                              <button
                                type="button"
                                onClick={() => setSettingsForm({
                                  ...settingsForm,
                                  popupImageUrl: 'https://images.unsplash.com/photo-1580582932707-520aed937b7b?auto=format&fit=crop&q=80&w=800'
                                })}
                                className="px-2 py-1.5 bg-white hover:bg-stone-200 border border-stone-200 rounded font-semibold text-stone-700 text-left truncate"
                              >
                                📚 Finnish Classroom
                              </button>
                              <button
                                type="button"
                                onClick={() => setSettingsForm({
                                  ...settingsForm,
                                  popupImageUrl: 'https://images.unsplash.com/photo-1524178232363-1fb2b075b655?auto=format&fit=crop&q=80&w=800'
                                })}
                                className="px-2 py-1.5 bg-white hover:bg-stone-200 border border-stone-200 rounded font-semibold text-stone-700 text-left truncate"
                              >
                                👩‍🏫 Teacher & Child
                              </button>
                            </div>
                          </div>
                        </div>

                        {/* Right column: Pop-up text & behavior fields */}
                        <div className="space-y-3">
                          
                          {/* Toggle active state, delay & scroll percentage */}
                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                            <div>
                              <label className="block font-bold text-stone-700 mb-1">Pop-up Status</label>
                              <select
                                value={settingsForm.popupEnabled !== false ? 'true' : 'false'}
                                onChange={(e) => setSettingsForm({ ...settingsForm, popupEnabled: e.target.value === 'true' })}
                                className="w-full px-3 py-2 border border-stone-300 rounded-lg bg-stone-50 text-xs font-bold"
                              >
                                <option value="true">Active (Enabled)</option>
                                <option value="false">Disabled</option>
                              </select>
                            </div>

                            <div>
                              <label className="block font-bold text-stone-700 mb-1">Scroll Trigger</label>
                              <select
                                value={settingsForm.popupScrollPercent || 50}
                                onChange={(e) => setSettingsForm({ ...settingsForm, popupScrollPercent: Number(e.target.value) })}
                                className="w-full px-3 py-2 border border-stone-300 rounded-lg bg-stone-50 text-xs font-bold"
                              >
                                <option value={25}>25% Page Scroll</option>
                                <option value={50}>50% Page Scroll (Default)</option>
                                <option value={75}>75% Page Scroll</option>
                              </select>
                            </div>

                            <div>
                              <label className="block font-bold text-stone-700 mb-1">Timer Delay (Sec)</label>
                              <input
                                type="number"
                                min={1}
                                max={60}
                                value={settingsForm.popupDelay || 6}
                                onChange={(e) => setSettingsForm({ ...settingsForm, popupDelay: Number(e.target.value) })}
                                className="w-full px-3 py-2 border border-stone-300 rounded-lg bg-stone-50 text-xs"
                              />
                            </div>
                          </div>

                          {/* Eyebrow tag */}
                          <div>
                            <label className="block font-bold text-stone-700 mb-1">Top Eyebrow Badge Tag</label>
                            <input
                              type="text"
                              value={settingsForm.popupTag || 'ADMISSIONS & PARTNERSHIPS OPEN'}
                              onChange={(e) => setSettingsForm({ ...settingsForm, popupTag: e.target.value })}
                              placeholder="e.g. ADMISSIONS & FRANCHISE OPEN"
                              className="w-full px-3 py-2 border border-stone-300 rounded-lg bg-stone-50 text-xs"
                            />
                          </div>

                          {/* Title */}
                          <div>
                            <label className="block font-bold text-stone-700 mb-1">Pop-up Headline Title</label>
                            <input
                              type="text"
                              value={settingsForm.popupTitle || 'Start Your Transformation Journey'}
                              onChange={(e) => setSettingsForm({ ...settingsForm, popupTitle: e.target.value })}
                              className="w-full px-3 py-2 border border-stone-300 rounded-lg bg-stone-50 text-xs font-bold"
                            />
                          </div>

                          {/* Subtitle */}
                          <div>
                            <label className="block font-bold text-stone-700 mb-1">Pop-up Subtitle Description</label>
                            <textarea
                              rows={2}
                              value={settingsForm.popupSubtitle || 'Complete the form and our Academic & Franchise Advisor will contact you shortly.'}
                              onChange={(e) => setSettingsForm({ ...settingsForm, popupSubtitle: e.target.value })}
                              className="w-full px-3 py-2 border border-stone-300 rounded-lg bg-stone-50 text-xs resize-none"
                            ></textarea>
                          </div>

                          <div className="pt-2">
                            <button
                              type="submit"
                              className="w-full py-2.5 bg-[#E1007A] hover:bg-[#c20068] text-white font-bold rounded-lg transition-colors cursor-pointer flex items-center justify-center gap-2 shadow"
                            >
                              <Check className="w-4 h-4 text-white" />
                              <span>Save Pop-up Image & Settings</span>
                            </button>
                          </div>

                        </div>

                      </div>
                    </form>

                    {/* Security access configuration card */}
                    <div className="space-y-6">
                      
                      <form onSubmit={savePassword} className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm space-y-4">
                        <h3 className="font-extrabold text-stone-900 text-sm font-display border-b border-stone-100 pb-2">Change Admin Access Code</h3>
                        
                        <div>
                          <label className="block font-bold text-stone-700 mb-1">New Access Code Password</label>
                          <input
                            type="password"
                            required
                            value={newPassword}
                            onChange={(e) => setNewPassword(e.target.value)}
                            placeholder="Must be at least 4 characters"
                            className="w-full px-3 py-2 border border-stone-300 rounded-lg bg-stone-50 focus:outline-none"
                          />
                        </div>

                        <button
                          type="submit"
                          className="w-full py-2.5 bg-[#E1007A] hover:bg-[#c20068] text-white font-bold rounded-lg transition-colors cursor-pointer"
                        >
                          Modify Access Password
                        </button>
                      </form>

                      {/* DB Status information */}
                      <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-sm space-y-2.5">
                        <h3 className="font-bold text-stone-900 text-xs uppercase tracking-wider font-display">Database Status Info</h3>
                        <div className="text-[11px] text-stone-500 leading-normal font-sans space-y-1">
                          <p><strong>DB Engine:</strong> File-based JSON Database (db.json)</p>
                          <p><strong>Total Submissions Logged:</strong> {enquiries.length}</p>
                          <p><strong>Total Blogs Published:</strong> {blogs.length}</p>
                          <p><strong>Total Active FAQs:</strong> {faqs.length}</p>
                        </div>
                      </div>

                    </div>

                  </div>
                </div>
              )}
            </>
          )}
        </div>

      </div>
    </div>
  );
}
