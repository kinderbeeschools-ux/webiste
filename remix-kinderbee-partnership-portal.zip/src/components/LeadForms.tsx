import React, { useState } from 'react';
import { Send, CheckCircle2, AlertCircle, FileText, Calendar, Sparkles } from 'lucide-react';
import { api } from '../utils/api';
import { EnquiryType } from '../types';

interface LeadFormProps {
  initialType?: EnquiryType;
  onSuccess?: () => void;
}

export default function LeadForms({ initialType = 'franchise', onSuccess }: LeadFormProps) {
  const [activeType, setActiveType] = useState<EnquiryType>(initialType);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [submitted, setSubmitted] = useState(false);
  const [aiAnalysis, setAiAnalysis] = useState<string | null>(null);

  // Form Fields State
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    organization: '',
    city: '',
    state: '',
    budget: '',
    partnershipModel: '',
    message: '',
    courseOfInterest: '',
    academicBackground: '',
    learningMode: 'Hybrid'
  });

  const enquiryTypes: { id: EnquiryType; label: string; desc: string }[] = [
    { id: 'franchise', label: 'Preschool Franchise', desc: 'Launch a premium play-based preschool under NEP 2020.' },
    { id: 'investor', label: 'Investor Opportunities', desc: 'Invest in schools, teacher institutes, or degree colleges.' },
    { id: 'fwa_course', label: 'Finnish Way Academy', desc: 'Apply for teacher training, ECCE, NTT, or leadership courses.' },
    { id: 'general', label: 'General / Consultant', desc: 'Request branding, operational support, or bespoke consultations.' }
  ];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    // Basic Validation
    if (!formData.name || !formData.email || !formData.phone) {
      setError("Please fill out your name, email, and phone number.");
      setLoading(false);
      return;
    }

    try {
      // Set type-specific details if empty
      const fieldsToSend = { ...formData };
      if (activeType === 'franchise' && !fieldsToSend.partnershipModel) {
        fieldsToSend.partnershipModel = 'Preschool Franchise';
      } else if (activeType === 'investor' && !fieldsToSend.partnershipModel) {
        fieldsToSend.partnershipModel = 'Investor Venture';
      } else if (activeType === 'fwa_course' && !fieldsToSend.courseOfInterest) {
        fieldsToSend.courseOfInterest = 'Diploma in ECCE';
      }

      const result = await api.submitEnquiry(activeType, fieldsToSend);
      if (result.success) {
        setSubmitted(true);
        if (result.aiSummary) {
          setAiAnalysis(result.aiSummary);
        }
        if (onSuccess) onSuccess();
      } else {
        setError("Enquiry failed to submit. Please try again.");
      }
    } catch (err: any) {
      setError(err.message || "Something went wrong. Please check your network and retry.");
    } finally {
      setLoading(false);
    }
  };

  if (submitted) {
    return (
      <div className="bg-white p-8 rounded-2xl border border-stone-200 shadow-xl max-w-xl mx-auto text-center space-y-6 animate-scale-up" id="success-enquiry-card">
        <div className="w-16 h-16 bg-emerald-50 rounded-full flex items-center justify-center mx-auto border border-emerald-200">
          <CheckCircle2 className="w-10 h-10 text-emerald-500" />
        </div>
        
        <div className="space-y-2">
          <h3 className="text-2xl font-bold text-stone-900 font-display">Enquiry Submitted Successfully!</h3>
          <p className="text-stone-600 font-sans text-sm">
            Thank you, <span className="font-bold text-[#E1007A]">{formData.name}</span>. Your application has been logged on our secure server. An academic advisor will contact you within 24 hours.
          </p>
        </div>

        {/* Real-time AI Summary feedback */}
        {aiAnalysis && (
          <div className="bg-gradient-to-br from-purple-50 to-pink-50 p-5 rounded-xl border border-purple-100 text-left space-y-3 relative overflow-hidden shadow-inner">
            <div className="absolute top-0 right-0 p-2 opacity-10">
              <Sparkles className="w-12 h-12 text-[#E1007A]" />
            </div>
            <div className="flex items-center gap-2 text-[#7E22CE] font-bold text-xs uppercase tracking-wider">
              <Sparkles className="w-4 h-4" />
              <span>Kinderbee AI Strategic Score</span>
            </div>
            <p className="text-stone-800 text-sm italic font-sans leading-relaxed">
              "{aiAnalysis}"
            </p>
          </div>
        )}

        <div className="pt-4 flex flex-col sm:flex-row gap-3 justify-center">
          <button
            onClick={() => {
              setSubmitted(false);
              setAiAnalysis(null);
              setFormData({
                name: '', email: '', phone: '', organization: '', city: '', state: '',
                budget: '', partnershipModel: '', message: '', courseOfInterest: '',
                academicBackground: '', learningMode: 'Hybrid'
              });
            }}
            className="px-6 py-2.5 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold rounded-full text-sm transition-all"
          >
            Submit Another Query
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl border border-stone-200 shadow-xl overflow-hidden max-w-4xl mx-auto grid grid-cols-1 lg:grid-cols-12" id="lead-enquiry-system">
      
      {/* Sidebar Selector (4 Columns) */}
      <div className="lg:col-span-4 bg-stone-50 border-r border-stone-200 p-6 space-y-4">
        <h3 className="font-bold text-stone-900 text-base font-display">Select Vertical</h3>
        <p className="text-xs text-stone-500 leading-relaxed font-sans">
          Choose the partnership or training type to customize your enquiry form.
        </p>
        
        <div className="flex flex-col gap-2.5">
          {enquiryTypes.map((type) => (
            <button
              key={type.id}
              type="button"
              onClick={() => {
                setActiveType(type.id);
                setError(null);
              }}
              className={`p-3 text-left rounded-xl transition-all duration-200 border cursor-pointer ${
                activeType === type.id
                  ? 'bg-white border-[#E1007A] shadow-md ring-1 ring-[#E1007A]/10'
                  : 'bg-transparent border-transparent hover:bg-stone-100 hover:border-stone-300'
              }`}
            >
              <div className={`text-xs font-bold leading-none ${activeType === type.id ? 'text-[#E1007A]' : 'text-stone-800'}`}>
                {type.label}
              </div>
              <p className="text-[10px] text-stone-500 mt-1 leading-normal font-sans">
                {type.desc}
              </p>
            </button>
          ))}
        </div>

        <div className="pt-6 border-t border-stone-200 hidden lg:block">
          <div className="flex items-center gap-2 text-stone-600 text-xs font-bold">
            <Sparkles className="w-4 h-4 text-[#7E22CE]" />
            <span>AI Fast-Track Enabled</span>
          </div>
          <p className="text-[10px] text-stone-400 mt-1 font-sans">
            Our Gemini-powered engine instantly routes qualified budget proposals directly to state-directors.
          </p>
        </div>
      </div>

      {/* Main Form (8 Columns) */}
      <form onSubmit={handleSubmit} className="lg:col-span-8 p-6 sm:p-10 space-y-6">
        <div className="border-b border-stone-100 pb-4">
          <h3 className="text-xl sm:text-2xl font-extrabold text-stone-900 font-display">
            {enquiryTypes.find(t => t.id === activeType)?.label} Lead Application
          </h3>
          <p className="text-xs sm:text-sm text-stone-500 mt-1 font-sans">
            Please fill out your contact details. Items with <span className="text-[#E1007A] font-bold">*</span> are required.
          </p>
        </div>

        {error && (
          <div className="flex items-center gap-2.5 p-4 bg-rose-50 border border-rose-200 text-rose-800 text-xs font-semibold rounded-lg">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
            <span>{error}</span>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          {/* Primary Contact Fields */}
          <div>
            <label className="block text-xs font-bold text-stone-800 mb-2 uppercase tracking-wide">Full Name <span className="text-[#E1007A] font-bold">*</span></label>
            <input
              type="text"
              name="name"
              required
              value={formData.name}
              onChange={handleInputChange}
              placeholder="e.g. Suresh Kumar"
              className="w-full px-4 py-3.5 text-sm text-stone-900 placeholder-stone-400 bg-white border border-stone-300 rounded-xl focus:outline-none focus:ring-4 focus:ring-[#E1007A]/10 focus:border-[#E1007A] transition-all duration-200 shadow-sm"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-stone-800 mb-2 uppercase tracking-wide">Email Address <span className="text-[#E1007A] font-bold">*</span></label>
            <input
              type="email"
              name="email"
              required
              value={formData.email}
              onChange={handleInputChange}
              placeholder="e.g. name@example.com"
              className="w-full px-4 py-3.5 text-sm text-stone-900 placeholder-stone-400 bg-white border border-stone-300 rounded-xl focus:outline-none focus:ring-4 focus:ring-[#E1007A]/10 focus:border-[#E1007A] transition-all duration-200 shadow-sm"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-stone-800 mb-2 uppercase tracking-wide">Phone Number <span className="text-[#E1007A] font-bold">*</span></label>
            <input
              type="tel"
              name="phone"
              required
              value={formData.phone}
              onChange={handleInputChange}
              placeholder="e.g. +91 98765 43210"
              className="w-full px-4 py-3.5 text-sm text-stone-900 placeholder-stone-400 bg-white border border-stone-300 rounded-xl focus:outline-none focus:ring-4 focus:ring-[#E1007A]/10 focus:border-[#E1007A] transition-all duration-200 shadow-sm"
            />
          </div>

          {/* City / State - needed for feasibility */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-stone-800 mb-2 uppercase tracking-wide">City</label>
              <input
                type="text"
                name="city"
                value={formData.city}
                onChange={handleInputChange}
                placeholder="Pune"
                className="w-full px-4 py-3.5 text-sm text-stone-900 placeholder-stone-400 bg-white border border-stone-300 rounded-xl focus:outline-none focus:ring-4 focus:ring-[#E1007A]/10 focus:border-[#E1007A] transition-all duration-200 shadow-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-stone-800 mb-2 uppercase tracking-wide">State</label>
              <input
                type="text"
                name="state"
                value={formData.state}
                onChange={handleInputChange}
                placeholder="Maharashtra"
                className="w-full px-4 py-3.5 text-sm text-stone-900 placeholder-stone-400 bg-white border border-stone-300 rounded-xl focus:outline-none focus:ring-4 focus:ring-[#E1007A]/10 focus:border-[#E1007A] transition-all duration-200 shadow-sm"
              />
            </div>
          </div>
        </div>

        {/* Dynamic Fields based on activeType */}
        <div className="border-t border-stone-100 pt-6 grid grid-cols-1 sm:grid-cols-2 gap-6">
          
          {activeType === 'franchise' && (
            <>
              <div>
                <label className="block text-xs font-bold text-stone-800 mb-2 uppercase tracking-wide">Partnership Model</label>
                <select
                  name="partnershipModel"
                  value={formData.partnershipModel}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3.5 text-sm text-stone-900 bg-white border border-stone-300 rounded-xl focus:outline-none focus:ring-4 focus:ring-[#E1007A]/10 focus:border-[#E1007A] transition-all duration-200 shadow-sm"
                >
                  <option value="Preschool Franchise">Preschool Franchise (NEP 2020)</option>
                  <option value="Existing School Transformation">Existing School Transformation</option>
                  <option value="School Setup Consultancy">Complete School Setup Consultancy</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-800 mb-2 uppercase tracking-wide">Proposed Capital Investment</label>
                <select
                  name="budget"
                  value={formData.budget}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3.5 text-sm text-stone-900 bg-white border border-stone-300 rounded-xl focus:outline-none focus:ring-4 focus:ring-[#E1007A]/10 focus:border-[#E1007A] transition-all duration-200 shadow-sm"
                >
                  <option value="">-- Choose Budget Range --</option>
                  <option value="₹10 Lakhs - ₹15 Lakhs">₹10 Lakhs - ₹15 Lakhs</option>
                  <option value="₹15 Lakhs - ₹25 Lakhs">₹15 Lakhs - ₹25 Lakhs (Standard Preschool)</option>
                  <option value="₹25 Lakhs - ₹35 Lakhs">₹25 Lakhs - ₹35 Lakhs (Premium Preschool)</option>
                  <option value="₹35 Lakhs+">₹35 Lakhs+</option>
                </select>
              </div>
            </>
          )}

          {activeType === 'investor' && (
            <>
              <div>
                <label className="block text-xs font-bold text-stone-800 mb-2 uppercase tracking-wide">Primary Investment Interest</label>
                <select
                  name="partnershipModel"
                  value={formData.partnershipModel}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3.5 text-sm text-stone-900 bg-white border border-stone-300 rounded-xl focus:outline-none focus:ring-4 focus:ring-[#E1007A]/10 focus:border-[#E1007A] transition-all duration-200 shadow-sm"
                >
                  <option value="">-- Choose Interest --</option>
                  <option value="Preschool or Kindergarten">Preschool or Kindergarten Ventures</option>
                  <option value="CBSE K-12 School Establishment">CBSE K-12 School Establishment</option>
                  <option value="IB / International School Development">IB / International School Development</option>
                  <option value="Teacher Training Institutes">Teacher Training Institutes</option>
                  <option value="Degree Colleges">Degree Colleges (Arts, Science, Tech)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-800 mb-2 uppercase tracking-wide">Estimated Investment Budget</label>
                <select
                  name="budget"
                  value={formData.budget}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3.5 text-sm text-stone-900 bg-white border border-stone-300 rounded-xl focus:outline-none focus:ring-4 focus:ring-[#E1007A]/10 focus:border-[#E1007A] transition-all duration-200 shadow-sm"
                >
                  <option value="">-- Choose Budget Tier --</option>
                  <option value="₹15 Lakhs - ₹35 Lakhs">₹15 Lakhs - ₹35 Lakhs (Preschool Level)</option>
                  <option value="₹35 Lakhs - ₹1 Crore">₹35 Lakhs - ₹1 Crore</option>
                  <option value="₹1 Crore - ₹2 Crores">₹1 Crore - ₹2 Crores (K-12 Foundation)</option>
                  <option value="₹2 Crores - ₹5 Crores">₹2 Crores - ₹5 Crores</option>
                  <option value="₹5 Crores+">₹5 Crores+ (Full Campus Setup)</option>
                </select>
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-bold text-stone-800 mb-2 uppercase tracking-wide">Organization or Trust Name</label>
                <input
                  type="text"
                  name="organization"
                  value={formData.organization}
                  onChange={handleInputChange}
                  placeholder="e.g. Vidya Educational Trust"
                  className="w-full px-4 py-3.5 text-sm text-stone-900 placeholder-stone-400 bg-white border border-stone-300 rounded-xl focus:outline-none focus:ring-4 focus:ring-[#E1007A]/10 focus:border-[#E1007A] transition-all duration-200 shadow-sm"
                />
              </div>
            </>
          )}

          {activeType === 'fwa_course' && (
            <>
              <div>
                <label className="block text-xs font-bold text-stone-800 mb-2 uppercase tracking-wide">Course Category of Interest</label>
                <select
                  name="courseOfInterest"
                  value={formData.courseOfInterest}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3.5 text-sm text-stone-900 bg-white border border-stone-300 rounded-xl focus:outline-none focus:ring-4 focus:ring-[#E1007A]/10 focus:border-[#E1007A] transition-all duration-200 shadow-sm"
                >
                  <option value="">-- Select Course Program --</option>
                  <option value="Diploma in Nursery Teacher Training (NTT)">Diploma in Nursery Teacher Training (NTT)</option>
                  <option value="Diploma in Early Childhood Care & Education (ECCE)">Diploma in Early Childhood Care & Education (ECCE)</option>
                  <option value="Certificate in Classroom Management">Certificate in Classroom Management</option>
                  <option value="Professional Course in Academic Leadership">Academic Leadership & School Management</option>
                  <option value="Caregiver Training Modules">Caregiver & Nanny Training</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-800 mb-2 uppercase tracking-wide">Preferred Learning Mode</label>
                <select
                  name="learningMode"
                  value={formData.learningMode}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3.5 text-sm text-stone-900 bg-white border border-stone-300 rounded-xl focus:outline-none focus:ring-4 focus:ring-[#E1007A]/10 focus:border-[#E1007A] transition-all duration-200 shadow-sm"
                >
                  <option value="Online Live Classes">Online Live Interactive Classes</option>
                  <option value="Self-Paced Learning">Self-Paced Learning Portal</option>
                  <option value="Classroom Sessions">In-Person Classroom Sessions</option>
                  <option value="Hybrid Learning">Hybrid Learning (Recommended)</option>
                </select>
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-bold text-stone-800 mb-2 uppercase tracking-wide">Your Academic Qualification</label>
                <input
                  type="text"
                  name="academicBackground"
                  value={formData.academicBackground}
                  onChange={handleInputChange}
                  placeholder="e.g. Graduate in Science, High School Graduate, or Preschool Teacher with 2 years experience"
                  className="w-full px-4 py-3.5 text-sm text-stone-900 placeholder-stone-400 bg-white border border-stone-300 rounded-xl focus:outline-none focus:ring-4 focus:ring-[#E1007A]/10 focus:border-[#E1007A] transition-all duration-200 shadow-sm"
                />
              </div>
            </>
          )}

          {activeType === 'general' && (
            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-stone-800 mb-2 uppercase tracking-wide">Core Service Requirement</label>
              <select
                name="partnershipModel"
                value={formData.partnershipModel}
                onChange={handleInputChange}
                className="w-full px-4 py-3.5 text-sm text-stone-900 bg-white border border-stone-300 rounded-xl focus:outline-none focus:ring-4 focus:ring-[#E1007A]/10 focus:border-[#E1007A] transition-all duration-200 shadow-sm"
              >
                <option value="School Setup Consultancy">School Planning & Feasibility Studies</option>
                <option value="School Setup & Design">Architectural & Building Design</option>
                <option value="Academic Curriculum Support">Academic Curriculum Support & NEP 2020 Upgradations</option>
                <option value="School Branding & Marketing">Admissions Launch & Branding Strategies</option>
                <option value="Degree College Consultancy">Degree College Affiliation (AICTE/University)</option>
              </select>
            </div>
          )}

          {/* General Message (Enhanced Text Area Spacing & Height) */}
          <div className="sm:col-span-2">
            <label className="block text-xs font-bold text-stone-800 mb-2 uppercase tracking-wide">Specific Queries or Property Details</label>
            <textarea
              name="message"
              rows={5}
              value={formData.message}
              onChange={handleInputChange}
              placeholder="e.g. Please provide information about space specifications or describe any existing educational property details..."
              className="w-full px-4.5 py-4 text-sm text-stone-900 placeholder-stone-400 bg-white border border-stone-300 rounded-xl focus:outline-none focus:ring-4 focus:ring-[#E1007A]/10 focus:border-[#E1007A] transition-all duration-200 shadow-sm resize-y leading-relaxed"
            ></textarea>
          </div>

        </div>

        {/* Form Submission button - Relocated and beautifully framed */}
        <div className="pt-6 border-t border-stone-100 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-6">
          <p className="text-[11px] sm:text-xs text-stone-400 font-medium font-sans max-w-md leading-relaxed">
            By submitting, you agree that a Kinderbee educational consultant may contact you by phone, WhatsApp, or email with customized material.
          </p>

          <button
            type="submit"
            disabled={loading}
            className="flex items-center justify-center gap-2 px-8 py-4 bg-gradient-to-r from-[#E1007A] to-[#F79F33] hover:opacity-95 text-white font-extrabold rounded-full text-base transition-all shadow-md hover:shadow-lg disabled:opacity-50 disabled:cursor-not-allowed shrink-0 cursor-pointer active:scale-95"
          >
            {loading ? (
              <>
                <svg className="animate-spin h-5 w-5 text-white" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                </svg>
                <span>Analyzing Proposal...</span>
              </>
            ) : (
              <>
                <Send className="w-5 h-5" />
                <span>Submit Secure Application</span>
              </>
            )}
          </button>
        </div>

      </form>
    </div>
  );
}
