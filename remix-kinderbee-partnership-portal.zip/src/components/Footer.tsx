import React from 'react';
import { Phone, Mail, MapPin, MessageSquare, Facebook, Linkedin, Instagram, Clock } from 'lucide-react';
import { SystemSettings } from '../types';
import Logo from './Logo';

interface FooterProps {
  setCurrentTab: (tab: string) => void;
  settings: SystemSettings;
}

export default function Footer({ setCurrentTab, settings }: FooterProps) {
  const currentYear = new Date().getFullYear();

  const handleNav = (tabId: string) => {
    setCurrentTab(tabId);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#0F172A] text-stone-300 border-t border-[#1E293B]" id="main-footer">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          
          {/* Column 1: Brand details */}
          <div className="flex flex-col space-y-6">
            <div className="flex items-center gap-2">
              <Logo showTagline={false} isSmall={false} className="h-7" />
            </div>
            <p className="text-sm text-stone-400 leading-relaxed font-sans">
              Kinderbee Integrated Partnership System (KIPS) is a comprehensive education ecosystem designed to establish and manage successful, world-class educational ventures with a 100% Zero Royalty Model.
            </p>
            {/* Social Media Link Icons */}
            <div className="flex items-center space-x-4">
              <a href={settings.facebookUrl} target="_blank" rel="noopener noreferrer" className="p-2.5 bg-stone-800 text-stone-300 rounded-full hover:bg-[#E1007A] hover:text-white transition-all duration-200" title="Facebook">
                <Facebook className="w-4.5 h-4.5" />
              </a>
              <a href={settings.linkedinUrl} target="_blank" rel="noopener noreferrer" className="p-2.5 bg-stone-800 text-stone-300 rounded-full hover:bg-[#E1007A] hover:text-white transition-all duration-200" title="LinkedIn">
                <Linkedin className="w-4.5 h-4.5" />
              </a>
              <a href={settings.instagramUrl} target="_blank" rel="noopener noreferrer" className="p-2.5 bg-stone-800 text-stone-300 rounded-full hover:bg-[#E1007A] hover:text-white transition-all duration-200" title="Instagram">
                <Instagram className="w-4.5 h-4.5" />
              </a>
              <a href={`https://wa.me/${settings.whatsappNumber.replace(/[^0-9]/g, '')}`} target="_blank" rel="noopener noreferrer" className="p-2.5 bg-stone-800 text-[#25D366] rounded-full hover:bg-emerald-600 hover:text-white transition-all duration-200" title="WhatsApp">
                <MessageSquare className="w-4.5 h-4.5" />
              </a>
            </div>
          </div>

          {/* Column 2: Quick Links */}
          <div className="flex flex-col space-y-4">
            <h3 className="text-white font-bold text-lg tracking-wide font-display">Navigation</h3>
            <ul className="space-y-2.5 text-sm">
              <li>
                <button onClick={() => handleNav('home')} className="hover:text-[#E1007A] transition-colors cursor-pointer text-left font-medium">
                  Home Portal
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('about')} className="hover:text-[#E1007A] transition-colors cursor-pointer text-left font-medium">
                  About Kinderbee
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('partnerships')} className="hover:text-[#E1007A] transition-colors cursor-pointer text-left font-medium">
                  Franchise
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('fwa')} className="hover:text-[#E1007A] transition-colors cursor-pointer text-left font-medium">
                  NTT Teacher Training
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('investors')} className="hover:text-[#E1007A] transition-colors cursor-pointer text-left font-medium">
                  Partner with us
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('blogs')} className="hover:text-[#E1007A] transition-colors cursor-pointer text-left font-medium">
                  Blogs & Insights
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('contact')} className="hover:text-[#E1007A] transition-colors cursor-pointer text-left font-medium">
                  Contact Us
                </button>
              </li>
            </ul>
          </div>

          {/* Column 3: Partnership Models */}
          <div className="flex flex-col space-y-4">
            <h3 className="text-white font-bold text-lg tracking-wide font-display">Partnership Verticals</h3>
            <ul className="space-y-2.5 text-sm text-stone-400">
              <li>
                <button onClick={() => handleNav('partnerships')} className="hover:text-[#E1007A] text-left transition-colors cursor-pointer font-medium">
                  Preschool Franchise (NEP 2020)
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('partnerships')} className="hover:text-[#E1007A] text-left transition-colors cursor-pointer font-medium">
                  CBSE School Setup & Partnership
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('partnerships')} className="hover:text-[#E1007A] text-left transition-colors cursor-pointer font-medium">
                  IB World School Setup
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('partnerships')} className="hover:text-[#E1007A] text-left transition-colors cursor-pointer font-medium">
                  Degree College Setup & Consultancy
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('fwa')} className="hover:text-[#E1007A] text-left transition-colors cursor-pointer font-medium">
                  NTT & ECCE Teacher Training
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('investors')} className="hover:text-[#E1007A] text-left transition-colors cursor-pointer font-medium">
                  Strategic Education Investment
                </button>
              </li>
            </ul>
          </div>

          {/* Column 4: Down Bar Contact Details */}
          <div className="flex flex-col space-y-5">
            <h3 className="text-white font-bold text-lg tracking-wide font-display">Down Bar Contact</h3>
            <ul className="space-y-3.5 text-sm">
              <li className="flex items-start gap-2.5">
                <MapPin className="w-5 h-5 text-[#E1007A] shrink-0 mt-0.5" />
                <span className="text-stone-300 leading-relaxed font-sans">
                  Opp Vijay Bakery, Old UCO Bank road, Ramamurthy Nagar, Bangalore, 560016
                </span>
              </li>
              <li className="flex items-center gap-2.5">
                <Mail className="w-4.5 h-4.5 text-[#FFD200] shrink-0" />
                <a href="mailto:kinderbeeschools@gmail.com" className="hover:text-white transition-colors text-stone-300 font-medium">
                  kinderbeeschools@gmail.com
                </a>
              </li>
              <li className="flex items-center gap-2.5">
                <Phone className="w-4.5 h-4.5 text-[#F97316] shrink-0" />
                <a href={`tel:${settings.phone.replace(/\s+/g, '')}`} className="hover:text-white transition-colors text-stone-300 font-bold">
                  {settings.phone}
                </a>
              </li>
            </ul>
            <div className="bg-stone-800/90 p-3.5 rounded-xl border border-stone-700 text-xs text-stone-300 font-medium flex items-center gap-3">
              <div className="p-2 bg-[#E1007A]/20 rounded-lg text-[#E1007A] shrink-0">
                <Clock className="w-4.5 h-4.5 text-[#E1007A]" />
              </div>
              <div className="text-left">
                <span className="block font-bold text-white text-xs uppercase tracking-wider font-display">Business Hours</span>
                <span className="text-stone-300 text-xs font-sans font-semibold">10 AM - 5 PM (Mon – Sat)</span>
              </div>
            </div>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="border-t border-stone-800 mt-12 pt-8 flex flex-col sm:flex-row items-center justify-between text-xs text-stone-500 font-medium">
          <p>© {currentYear} Kinderbee Integrated Partnership System (KIPS). All rights reserved.</p>
          <div className="flex space-x-6 mt-4 sm:mt-0 items-center">
            <button onClick={() => handleNav('contact')} className="hover:text-stone-300 transition-colors">Privacy Policy</button>
            <button onClick={() => handleNav('contact')} className="hover:text-stone-300 transition-colors">Terms of Association</button>
            <button onClick={() => handleNav('contact')} className="hover:text-stone-300 transition-colors">Support Desk</button>
          </div>
        </div>
      </div>
    </footer>
  );
}
