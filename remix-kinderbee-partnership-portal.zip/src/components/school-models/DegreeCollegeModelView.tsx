import React from 'react';
import { Check, Award, GraduationCap, Sparkles, Building2, BookOpen, Layers, Briefcase, ArrowRight } from 'lucide-react';
import { BeeGraduateMascot, GrowthCoinsSchool } from '../MascotGraphics';

interface DegreeCollegeModelViewProps {
  onRegisterClick: () => void;
  onBrochureClick: (title: string) => void;
}

export default function DegreeCollegeModelView({ onRegisterClick, onBrochureClick }: DegreeCollegeModelViewProps) {
  const collegeFacilities = [
    'Smart Classrooms',
    'Computer & Advanced Laboratories',
    'Central Library & Digital Library',
    'Seminar & Conference Hall',
    'Department Offices',
    'Faculty Development Centre',
    'Innovation & Entrepreneurship Centre',
    'Placement & Career Development Cell',
    'Student Activity & Clubs Centre',
    'Sports & Recreation Facilities',
    'Student Counselling & Wellness Centre',
    'Administrative & Admissions Office',
    'Digital Learning Infrastructure',
    'Campus Wi-Fi & Technology Systems',
    'Safe & Accessible Campus Facilities'
  ];

  const collegeFocusPoints = [
    'UG & PG Degree Programs',
    'University Affiliation Support',
    'Academic & Curriculum Planning',
    'Higher Education Compliance',
    'Industry-Oriented Programs',
    'Student-Centric Learning',
    'Career & Employability Development',
    'Digital & Technology-Enabled Education'
  ];

  return (
    <div className="space-y-16 py-6 animate-fade-in" id="degree-college-model-view">
      
      {/* Header Banner */}
      <div className="max-w-4xl mx-auto text-center space-y-4">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 bg-[#7E22CE]/10 text-[#7E22CE] rounded-full text-xs font-bold uppercase tracking-wider font-display">
          <GraduationCap className="w-4 h-4" />
          <span>Flagship Higher Education Partnership Model</span>
        </div>
        <h1 className="text-4xl sm:text-5xl font-extrabold text-stone-900 font-display leading-tight">
          Degree College Setup & Consultancy
        </h1>
        <p className="text-stone-600 text-sm sm:text-base leading-relaxed max-w-2xl mx-auto font-sans">
          Establish or transform a degree college in India with comprehensive support for higher education planning, university affiliation, academic development, infrastructure, compliance, faculty training, student admissions and digital transformation.
        </p>
      </div>

      {/* Hero Overview Card */}
      <div className="max-w-5xl mx-auto bg-white rounded-3xl border border-stone-200 p-8 sm:p-12 shadow-sm grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
        <div className="md:col-span-8 space-y-4">
          <span className="text-xs font-bold text-[#7E22CE] uppercase tracking-wider font-display">Higher Education Transformation</span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-stone-950 font-display">
            Industry-Aligned Degree Programs with Seamless University Affiliation
          </h2>
          <p className="text-stone-600 text-xs sm:text-sm leading-relaxed font-sans">
            KIPS provides technical mastery in navigating statutory university affiliations, AICTE and UGC compliance, syllabus enhancement, placement cell setup, and institutional governance to build thriving colleges.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2">
            {collegeFocusPoints.map((item, idx) => (
              <div key={idx} className="flex items-center gap-2 text-xs font-bold text-stone-800 font-sans">
                <Check className="w-4 h-4 text-[#7E22CE] shrink-0" />
                <span>{item}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="md:col-span-4 bg-gradient-to-br from-purple-50 to-pink-50 p-6 rounded-2xl border border-purple-100 flex flex-col items-center justify-center text-center space-y-3">
          <GrowthCoinsSchool className="w-24 h-24" />
          <div className="text-xs font-bold text-stone-900 font-display uppercase tracking-wider">Suitable For</div>
          <p className="text-stone-600 text-[11px] font-sans leading-relaxed">
            Education entrepreneurs, investors, educational trusts, existing institutions and organizations planning to establish or expand a degree college or higher education institution.
          </p>
        </div>
      </div>

      {/* Financial & Space Specifications */}
      <section className="max-w-5xl mx-auto space-y-6">
        <div className="text-center space-y-2">
          <h2 className="text-2xl font-bold font-display">Financial & Campus Specifications</h2>
          <p className="text-stone-500 text-xs font-sans">Structured capital allocation models for higher education institutions.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm space-y-2 text-left">
            <span className="text-[10px] text-[#7E22CE] uppercase font-bold tracking-wider font-display">Estimated Investment</span>
            <div className="text-2xl font-black text-stone-900 font-display">₹5 Crore – ₹15 Crore+</div>
            <p className="text-stone-500 text-xs font-sans leading-relaxed">
              Based on department diversity (Commerce, Arts, Sciences, Technology, Management) and hostel capacities.
            </p>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm space-y-2 text-left">
            <span className="text-[10px] text-[#7E22CE] uppercase font-bold tracking-wider font-display">Land & Campus Requirements</span>
            <div className="text-2xl font-black text-stone-900 font-display">3 – 10+ Acres</div>
            <p className="text-stone-500 text-xs font-sans leading-relaxed">
              Based on state university affiliation criteria, UGC/AICTE campus guidelines, and local zoning.
            </p>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm space-y-2 text-left">
            <span className="text-[10px] text-[#7E22CE] uppercase font-bold tracking-wider font-display">Campus Development</span>
            <div className="text-2xl font-black text-stone-900 font-display">Institutional Norms</div>
            <p className="text-stone-500 text-xs font-sans leading-relaxed">
              Planned according to applicable higher education infrastructure and institutional accreditation standards.
            </p>
          </div>
        </div>
      </section>

      {/* 15 Recommended Campus Facilities Checklist */}
      <section className="max-w-5xl mx-auto bg-stone-50 rounded-3xl border border-stone-200 p-8 sm:p-10 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-stone-200 pb-4">
          <div>
            <h3 className="text-xl font-extrabold text-stone-900 font-display">Recommended Degree College Facilities</h3>
            <p className="text-stone-500 text-xs font-sans mt-0.5">Full 15-point facility framework for UGC / University compliance.</p>
          </div>
          <span className="px-3 py-1 bg-white text-xs font-bold text-[#7E22CE] border border-stone-200 rounded-full shrink-0">
            15 Facilities Included
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
          {collegeFacilities.map((facility, idx) => (
            <div key={idx} className="flex items-start gap-2 bg-white p-3.5 rounded-xl border border-stone-200/80 shadow-xs">
              <Check className="w-4 h-4 text-purple-600 shrink-0 mt-0.5" />
              <span className="text-stone-800 text-xs font-bold font-sans">{facility}</span>
            </div>
          ))}
        </div>
      </section>

      {/* Call to Action Bar */}
      <div className="max-w-3xl mx-auto bg-gradient-to-r from-[#0F172A] to-[#1E293B] text-white p-8 rounded-3xl text-center space-y-4 shadow-xl">
        <h3 className="text-2xl font-extrabold font-display !text-white">Begin Your Degree College Consultancy</h3>
        <p className="text-slate-300 text-xs sm:text-sm font-sans max-w-lg mx-auto">
          Consult with our higher education advisors to map university affiliations and campus development schedules.
        </p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center pt-2">
          <button 
            onClick={onRegisterClick}
            className="px-8 py-3 bg-[#7E22CE] hover:bg-[#6b1dae] text-white font-bold rounded-full text-xs transition-all shadow-md cursor-pointer"
          >
            Register Degree College Project
          </button>
          <button 
            onClick={() => onBrochureClick('Degree College Setup & Consultancy Guide')}
            className="px-8 py-3 border border-slate-600 hover:border-white text-white font-bold rounded-full text-xs transition-all cursor-pointer"
          >
            Download College Setup Guide
          </button>
        </div>
      </div>

    </div>
  );
}
