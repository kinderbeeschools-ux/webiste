import React from 'react';
import { Check, Award, ShieldCheck, Sparkles, Building2, BookOpen, Layers, Users, Globe, ArrowRight } from 'lucide-react';
import { BeeGraduateMascot, Education3DCapGlobe } from '../MascotGraphics';

interface CBSEModelViewProps {
  onRegisterClick: () => void;
  onBrochureClick: (title: string) => void;
}

export default function CBSEModelView({ onRegisterClick, onBrochureClick }: CBSEModelViewProps) {
  const cbseFacilities = [
    'Spacious Smart Classrooms',
    'Science & Computer Laboratories',
    'Mathematics Laboratory',
    'Library & Reading Centre',
    'STEM / Innovation Lab',
    'Indoor & Outdoor Sports Facilities',
    'Multipurpose Activity Hall',
    'Principal & Administrative Offices',
    'Teacher Resource Centre',
    'Safe & Child-Friendly Washrooms',
    'CCTV & Campus Security',
    'Medical / First-Aid Facility',
    'Parent Interaction Area',
    'Digital Smart-Class Infrastructure',
    'Adequate Playground & Green Spaces'
  ];

  const cbseFocusPoints = [
    'CBSE-Aligned Curriculum',
    'NEP 2020-Based Education',
    'Student-Centric Learning',
    'Experiential & Activity-Based Learning',
    'STEM & Technology Integration',
    'Holistic Student Development',
    'Academic & Administrative Excellence'
  ];

  const supportPillars = [
    {
      title: 'School Planning & Setup',
      desc: 'Land evaluation, architectural layout, project roadmaps, and turnkey K-12 campus planning.'
    },
    {
      title: 'CBSE Compliance Guidance',
      desc: 'Step-by-step guidance on CBSE affiliation bylaws, safety certifications, and documentation.'
    },
    {
      title: 'Curriculum & Academic Support',
      desc: 'Structured annual lesson plans, assessment frameworks, teacher guides, and student books.'
    },
    {
      title: 'Teacher Training & NTT Programs',
      desc: 'Continuous teacher capacity building through FinnishWay Academy modules and CBSE pedagogy workshops.'
    },
    {
      title: 'Website, CRM & Digital Marketing',
      desc: 'Dedicated school portal, automated admissions CRM, and localized brand marketing campaigns.'
    }
  ];

  return (
    <div className="space-y-16 py-6 animate-fade-in" id="cbse-school-model-view">
      
      {/* Header Banner */}
      <div className="max-w-4xl mx-auto text-center space-y-4">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 bg-[#F97316]/10 text-[#F97316] rounded-full text-xs font-bold uppercase tracking-wider font-display">
          <Award className="w-4 h-4" />
          <span>Premier K-12 Institutional Model</span>
        </div>
        <h1 className="text-4xl sm:text-5xl font-extrabold text-stone-900 font-display leading-tight">
          CBSE School Setup & Partnership
        </h1>
        <p className="text-stone-600 text-sm sm:text-base leading-relaxed max-w-2xl mx-auto font-sans">
          Establish a high-quality CBSE school in India with comprehensive support for school planning, curriculum development, infrastructure, compliance, teacher training and digital growth.
        </p>
      </div>

      {/* Hero Overview Card */}
      <div className="max-w-5xl mx-auto bg-white rounded-3xl border border-stone-200 p-8 sm:p-12 shadow-sm grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
        <div className="md:col-span-8 space-y-4">
          <span className="text-xs font-bold text-[#F97316] uppercase tracking-wider font-display">Academic Focus & Methodology</span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-stone-950 font-display">
            Excellence Aligned with Central CBSE Curriculum & NEP 2020
          </h2>
          <p className="text-stone-600 text-xs sm:text-sm leading-relaxed font-sans">
            Our CBSE setup framework empowers education entrepreneurs, trusts, and school owners to launch state-of-the-art K-12 campuses with zero operational friction. We combine academic rigour with experiential STEM teaching and active student engagement.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2">
            {cbseFocusPoints.map((item, idx) => (
              <div key={idx} className="flex items-center gap-2 text-xs font-bold text-stone-800 font-sans">
                <Check className="w-4 h-4 text-[#F97316] shrink-0" />
                <span>{item}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="md:col-span-4 bg-gradient-to-br from-orange-50 to-amber-50 p-6 rounded-2xl border border-orange-100 flex flex-col items-center justify-center text-center space-y-3">
          <Education3DCapGlobe className="w-24 h-24" />
          <div className="text-xs font-bold text-stone-900 font-display uppercase tracking-wider">Suitable For</div>
          <p className="text-stone-600 text-[11px] font-sans leading-relaxed">
            Entrepreneurs, education investors, existing school owners, educational trusts and institutions planning to establish or upgrade a CBSE school.
          </p>
        </div>
      </div>

      {/* Financial & Space Specifications */}
      <section className="max-w-5xl mx-auto space-y-6">
        <div className="text-center space-y-2">
          <h2 className="text-2xl font-bold font-display">Financial & Infrastructure Specifications</h2>
          <p className="text-stone-500 text-xs font-sans">Transparent capital planning calibrated to local land and capacity requirements.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm space-y-2 text-left">
            <span className="text-[10px] text-[#F97316] uppercase font-bold tracking-wider font-display">Estimated Investment</span>
            <div className="text-2xl font-black text-stone-900 font-display">₹2 Crore – ₹5 Crore+</div>
            <p className="text-stone-500 text-xs font-sans leading-relaxed">
              Investment varies depending on location, land ownership, construction, infrastructure, facilities and project scale.
            </p>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm space-y-2 text-left">
            <span className="text-[10px] text-[#F97316] uppercase font-bold tracking-wider font-display">Land Space Requirements</span>
            <div className="text-2xl font-black text-stone-900 font-display">1.5 – 3+ Acres</div>
            <p className="text-stone-500 text-xs font-sans leading-relaxed">
              As per CBSE affiliation bylaws and applicable state municipal / educational zoning norms.
            </p>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm space-y-2 text-left">
            <span className="text-[10px] text-[#F97316] uppercase font-bold tracking-wider font-display">Campus Development</span>
            <div className="text-2xl font-black text-stone-900 font-display">CBSE Standards</div>
            <p className="text-stone-500 text-xs font-sans leading-relaxed">
              Modern master plans with smart labs, barrier-free access, and certified child safety architecture.
            </p>
          </div>
        </div>
      </section>

      {/* 15 Recommended Campus Facilities Checklist */}
      <section className="max-w-5xl mx-auto bg-stone-50 rounded-3xl border border-stone-200 p-8 sm:p-10 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-stone-200 pb-4">
          <div>
            <h3 className="text-xl font-extrabold text-stone-900 font-display">Recommended CBSE School Facilities</h3>
            <p className="text-stone-500 text-xs font-sans mt-0.5">Comprehensive 15-point infrastructure matrix for modern K-12 education.</p>
          </div>
          <span className="px-3 py-1 bg-white text-xs font-bold text-[#F97316] border border-stone-200 rounded-full shrink-0">
            15 Key Facilities Included
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
          {cbseFacilities.map((facility, idx) => (
            <div key={idx} className="flex items-start gap-2 bg-white p-3.5 rounded-xl border border-stone-200/80 shadow-xs">
              <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span className="text-stone-800 text-xs font-bold font-sans">{facility}</span>
            </div>
          ))}
        </div>
      </section>

      {/* 5 End-to-End Support Pillars */}
      <section className="max-w-5xl mx-auto space-y-6">
        <h3 className="text-2xl font-bold text-center font-display">Complete CBSE School Support System</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {supportPillars.map((pillar, idx) => (
            <div key={idx} className="bg-white p-5 rounded-2xl border border-stone-200 shadow-sm space-y-2">
              <div className="text-[10px] font-bold text-[#F97316] uppercase tracking-wider font-display">Pillar 0{idx + 1}</div>
              <h4 className="font-bold text-stone-900 text-sm font-display">{pillar.title}</h4>
              <p className="text-stone-500 text-xs font-sans leading-relaxed">{pillar.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Call to Action Bar */}
      <div className="max-w-3xl mx-auto bg-gradient-to-r from-[#0F172A] to-[#1E293B] text-white p-8 rounded-3xl text-center space-y-4 shadow-xl">
        <h3 className="text-2xl font-extrabold font-display !text-white">Start Your CBSE School Project Today</h3>
        <p className="text-slate-300 text-xs sm:text-sm font-sans max-w-lg mx-auto">
          Get in touch with our school development consultants to verify feasibility and download the detailed CBSE blueprint.
        </p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center pt-2">
          <button 
            onClick={onRegisterClick}
            className="px-8 py-3 bg-[#F97316] hover:bg-[#ea580c] text-white font-bold rounded-full text-xs transition-all shadow-md cursor-pointer"
          >
            Register CBSE School Project
          </button>
          <button 
            onClick={() => onBrochureClick('CBSE School Setup & Partnership Brochure')}
            className="px-8 py-3 border border-slate-600 hover:border-white text-white font-bold rounded-full text-xs transition-all cursor-pointer"
          >
            Download CBSE Setup Guide
          </button>
        </div>
      </div>

    </div>
  );
}
