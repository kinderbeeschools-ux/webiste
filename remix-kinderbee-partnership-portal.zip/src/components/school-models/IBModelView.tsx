import React from 'react';
import { Check, Award, Globe, Sparkles, Building, BookOpen, Compass, ShieldCheck, ArrowRight } from 'lucide-react';
import { BeeGraduateMascot, Education3DCapGlobe } from '../MascotGraphics';

interface IBModelViewProps {
  onRegisterClick: () => void;
  onBrochureClick: (title: string) => void;
}

export default function IBModelView({ onRegisterClick, onBrochureClick }: IBModelViewProps) {
  const ibFacilities = [
    'Modern Smart Classrooms',
    'Science & Computer Laboratories',
    'Innovation & STEM Labs',
    'International Standard Library',
    'Art & Performing Arts Studios',
    'Indoor & Outdoor Sports Facilities',
    'Multipurpose Activity Centre',
    'Collaborative Learning Spaces',
    'Language Learning Rooms',
    'Student Wellness & Counselling Centre',
    'Teacher Resource & Planning Centre',
    'Child-Friendly Washrooms',
    'CCTV & Campus Security',
    'Medical / First-Aid Facility',
    'Digital Learning Infrastructure',
    'Sustainable & Green Learning Spaces'
  ];

  const ibFocusPoints = [
    'International Baccalaureate (IB) Curriculum',
    'Inquiry-Based Learning',
    'Student-Centred Education',
    'Experiential & Project-Based Learning',
    'Global-Mindedness & International Education',
    'Critical Thinking & Problem-Solving',
    'Holistic Student Development'
  ];

  return (
    <div className="space-y-16 py-6 animate-fade-in" id="ib-school-model-view">
      
      {/* Header Banner */}
      <div className="max-w-4xl mx-auto text-center space-y-4">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 bg-[#0284C7]/10 text-[#0284C7] rounded-full text-xs font-bold uppercase tracking-wider font-display">
          <Globe className="w-4 h-4" />
          <span>Flagship International School Model</span>
        </div>
        <h1 className="text-4xl sm:text-5xl font-extrabold text-stone-900 font-display leading-tight">
          IB School Setup & Partnership
        </h1>
        <p className="text-stone-600 text-sm sm:text-base leading-relaxed max-w-2xl mx-auto font-sans">
          Establish a premium IB World School in India with strategic support for international curriculum development, school planning, academic systems, teacher development, infrastructure and digital transformation.
        </p>
      </div>

      {/* Hero Overview Card */}
      <div className="max-w-5xl mx-auto bg-white rounded-3xl border border-stone-200 p-8 sm:p-12 shadow-sm grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
        <div className="md:col-span-8 space-y-4">
          <span className="text-xs font-bold text-[#0284C7] uppercase tracking-wider font-display">Global Pedagogical Standards</span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-stone-950 font-display">
            Inquiry-Driven International Education with Global Accreditation
          </h2>
          <p className="text-stone-600 text-xs sm:text-sm leading-relaxed font-sans">
            Our IB partnership model delivers world-class institutional planning, teacher recruitment from global talent pools, PYP/MYP/DP curriculum design, and end-to-end authorization consultancy for the International Baccalaureate organization.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2">
            {ibFocusPoints.map((item, idx) => (
              <div key={idx} className="flex items-center gap-2 text-xs font-bold text-stone-800 font-sans">
                <Check className="w-4 h-4 text-[#0284C7] shrink-0" />
                <span>{item}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="md:col-span-4 bg-gradient-to-br from-sky-50 to-blue-50 p-6 rounded-2xl border border-sky-100 flex flex-col items-center justify-center text-center space-y-3">
          <Education3DCapGlobe className="w-24 h-24" />
          <div className="text-xs font-bold text-stone-900 font-display uppercase tracking-wider">Suitable For</div>
          <p className="text-stone-600 text-[11px] font-sans leading-relaxed">
            Education entrepreneurs, investors, educational trusts, existing school owners and institutions planning to establish or transform into an international school.
          </p>
        </div>
      </div>

      {/* Financial & Space Specifications */}
      <section className="max-w-5xl mx-auto space-y-6">
        <div className="text-center space-y-2">
          <h2 className="text-2xl font-bold font-display">Financial & Campus Specifications</h2>
          <p className="text-stone-500 text-xs font-sans">Turnkey investment tiers for international institutional excellence.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm space-y-2 text-left">
            <span className="text-[10px] text-[#0284C7] uppercase font-bold tracking-wider font-display">Estimated Investment</span>
            <div className="text-2xl font-black text-stone-900 font-display">₹5 Crore – ₹15 Crore+</div>
            <p className="text-stone-500 text-xs font-sans leading-relaxed">
              Tailored based on institutional scale, state-of-the-art lab fitouts, robotics suites, and athletic complexes.
            </p>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm space-y-2 text-left">
            <span className="text-[10px] text-[#0284C7] uppercase font-bold tracking-wider font-display">Land Requirements</span>
            <div className="text-2xl font-black text-stone-900 font-display">2 – 5+ Acres</div>
            <p className="text-stone-500 text-xs font-sans leading-relaxed">
              Based on campus master plan, international boarding options, and applicable local zoning bylaws.
            </p>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-stone-200 shadow-sm space-y-2 text-left">
            <span className="text-[10px] text-[#0284C7] uppercase font-bold tracking-wider font-display">Campus Development</span>
            <div className="text-2xl font-black text-stone-900 font-display">International Standards</div>
            <p className="text-stone-500 text-xs font-sans leading-relaxed">
              Sustainable green architecture, maker-spaces, performing arts auditoriums, and collaborative pods.
            </p>
          </div>
        </div>
      </section>

      {/* 16 Recommended Campus Facilities Checklist */}
      <section className="max-w-5xl mx-auto bg-stone-50 rounded-3xl border border-stone-200 p-8 sm:p-10 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-stone-200 pb-4">
          <div>
            <h3 className="text-xl font-extrabold text-stone-900 font-display">Recommended IB School Facilities</h3>
            <p className="text-stone-500 text-xs font-sans mt-0.5">High-performance international infrastructure matching IB authorization benchmarks.</p>
          </div>
          <span className="px-3 py-1 bg-white text-xs font-bold text-[#0284C7] border border-stone-200 rounded-full shrink-0">
            16 Facilities Included
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
          {ibFacilities.map((facility, idx) => (
            <div key={idx} className="flex items-start gap-2 bg-white p-3.5 rounded-xl border border-stone-200/80 shadow-xs">
              <Check className="w-4 h-4 text-sky-600 shrink-0 mt-0.5" />
              <span className="text-stone-800 text-xs font-bold font-sans">{facility}</span>
            </div>
          ))}
        </div>
      </section>

      {/* Call to Action Bar */}
      <div className="max-w-3xl mx-auto bg-gradient-to-r from-[#0F172A] to-[#1E293B] text-white p-8 rounded-3xl text-center space-y-4 shadow-xl">
        <h3 className="text-2xl font-extrabold font-display !text-white">Partner with Us for an IB World School</h3>
        <p className="text-slate-300 text-xs sm:text-sm font-sans max-w-lg mx-auto">
          Consult with our international school architects and IB authorization specialists to evaluate your territory.
        </p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center pt-2">
          <button 
            onClick={onRegisterClick}
            className="px-8 py-3 bg-[#0284C7] hover:bg-[#0369a1] text-white font-bold rounded-full text-xs transition-all shadow-md cursor-pointer"
          >
            Register IB School Project
          </button>
          <button 
            onClick={() => onBrochureClick('IB World School Setup & Partnership Brochure')}
            className="px-8 py-3 border border-slate-600 hover:border-white text-white font-bold rounded-full text-xs transition-all cursor-pointer"
          >
            Download IB Setup Guide
          </button>
        </div>
      </div>

    </div>
  );
}
