import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import PublicPages from './components/PublicPages';
import AdminDashboard from './components/AdminDashboard';
import LeadPopupModal from './components/LeadPopupModal';
import { api } from './utils/api';
import { SystemSettings } from './types';
import { PhoneCall, ArrowRight } from 'lucide-react';

// Extend window interface for global popup trigger
declare global {
  interface Window {
    openLeadPopup?: () => void;
  }
}

export default function App() {
  const [currentTab, setCurrentTab] = useState<string>('home');
  const [isAdmin, setIsAdmin] = useState<boolean>(false);
  const [settings, setSettings] = useState<SystemSettings>({
    phone: '+91 99013 32233',
    email: 'kinderbeeschools@gmail.com',
    officeAddress: 'Opp Vijay Bakery, Old UCO Bank road, Ramamurthy Nagar, Bangalore, 560016',
    whatsappNumber: '+919901332233',
    facebookUrl: 'https://facebook.com/kinderbee',
    twitterUrl: 'https://twitter.com/kinderbee',
    instagramUrl: 'https://instagram.com/kinderbee',
    workingHours: '10 AM - 5 PM',
    popupEnabled: true,
    popupDelay: 4,
    popupTag: 'ADMISSIONS & PARTNERSHIPS OPEN',
    popupTitle: 'Start Your Transformation Journey',
    popupSubtitle: 'Complete the form and our Academic & Franchise Advisor will contact you shortly.',
    popupImageUrl: 'https://images.unsplash.com/photo-1577896851231-70ef18881754?auto=format&fit=crop&q=80&w=800'
  });
  const [pages, setPages] = useState<any[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [popupOpen, setPopupOpen] = useState<boolean>(false);

  // Global trigger registration
  useEffect(() => {
    window.openLeadPopup = () => setPopupOpen(true);
    return () => {
      delete window.openLeadPopup;
    };
  }, []);

  // Sync route from URL query params or hash
  useEffect(() => {
    const syncTabFromUrl = () => {
      const params = new URLSearchParams(window.location.search);
      const tabParam = params.get('tab') || params.get('page');
      const hashParam = window.location.hash.replace('#', '');
      const pathParam = window.location.pathname.replace('/', '').toLowerCase();

      if (tabParam === 'admin' || hashParam === 'admin' || pathParam === 'admin') {
        setCurrentTab('admin');
      } else if (tabParam) {
        setCurrentTab(tabParam);
      }
    };

    syncTabFromUrl();
    window.addEventListener('popstate', syncTabFromUrl);
    return () => window.removeEventListener('popstate', syncTabFromUrl);
  }, []);

  // Expose global modal opener for buttons and components
  useEffect(() => {
    (window as any).openLeadPopup = () => setPopupOpen(true);
    return () => {
      delete (window as any).openLeadPopup;
    };
  }, []);

  // Initial authentication and settings sync
  useEffect(() => {
    async function initPortal() {
      // Check for admin token
      const token = localStorage.getItem('kips_admin_token');
      if (token) {
        setIsAdmin(true);
      }

      // Sync settings & pages
      try {
        const config = await api.getSettings();
        setSettings(config);
        
        const pagesData = await api.getPages();
        setPages(pagesData);
      } catch (err) {
        console.error("Failed to load initial settings:", err);
      } finally {
        setLoading(false);
      }
    }
    initPortal();
  }, []);

  // Automatic Lead Generation Pop-up Triggers (50% Scroll Depth & Timed Delay) for desktop & mobile
  useEffect(() => {
    if (loading || currentTab === 'admin' || isAdmin) return;
    if (settings.popupEnabled === false) return;

    let hasTriggered = false;

    const checkScrollTrigger = () => {
      if (hasTriggered) return;

      const doc = document.documentElement;
      const body = document.body;
      const scrollTop = window.pageYOffset || window.scrollY || doc.scrollTop || body.scrollTop || 0;
      const scrollHeight = Math.max(
        body.scrollHeight || 0,
        doc.scrollHeight || 0,
        body.offsetHeight || 0,
        doc.offsetHeight || 0,
        doc.clientHeight || 0
      );
      const clientHeight = window.innerHeight || doc.clientHeight || body.clientHeight || 1;
      const totalScrollable = scrollHeight - clientHeight;

      if (totalScrollable <= 100) {
        // If short page, trigger after 400px of scrolling
        if (scrollTop >= 400) {
          hasTriggered = true;
          setPopupOpen(true);
        }
        return;
      }

      const scrollPercent = (scrollTop / totalScrollable) * 100;
      const targetThreshold = settings.popupScrollPercent !== undefined ? settings.popupScrollPercent : 50;

      // Trigger if user reaches the threshold (e.g. 50%) or scrolls past 700px (past hero)
      if (scrollPercent >= targetThreshold || scrollTop >= 700) {
        hasTriggered = true;
        setPopupOpen(true);
      }
    };

    // Attach listeners across window, document, and touchmove for mobile
    window.addEventListener('scroll', checkScrollTrigger, { passive: true });
    document.addEventListener('scroll', checkScrollTrigger, { passive: true });
    window.addEventListener('touchmove', checkScrollTrigger, { passive: true });

    // Initial check in case user loaded halfway down
    checkScrollTrigger();

    // Fallback timer (e.g., auto-open after delay if user is idle)
    const delaySeconds = settings.popupDelay || 6;
    const timer = setTimeout(() => {
      if (!hasTriggered) {
        hasTriggered = true;
        setPopupOpen(true);
      }
    }, delaySeconds * 1000);

    return () => {
      window.removeEventListener('scroll', checkScrollTrigger);
      document.removeEventListener('scroll', checkScrollTrigger);
      window.removeEventListener('touchmove', checkScrollTrigger);
      clearTimeout(timer);
    };
  }, [loading, currentTab, isAdmin, settings.popupEnabled, settings.popupDelay, settings.popupScrollPercent]);

  const handleSetTab = (tab: string) => {
    setCurrentTab(tab);
    try {
      if (tab === 'admin') {
        const newUrl = `${window.location.pathname}?tab=admin`;
        window.history.pushState({ tab }, '', newUrl);
      } else if (tab === 'home') {
        window.history.pushState({ tab }, '', window.location.pathname);
      } else {
        window.history.pushState({ tab }, '', `${window.location.pathname}?tab=${tab}`);
      }
    } catch (e) {
      // Fallback if pushState fails in certain iframe contexts
    }
  };

  // Sync scroll to top on tab changes
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [currentTab]);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#FAF9F6] flex flex-col items-center justify-center space-y-3 font-sans" id="app-loading-state">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-[#E1007A]"></div>
        <div className="text-center space-y-1">
          <span className="font-extrabold text-stone-950 block text-lg font-display">KinderBee Partnerships</span>
          <span className="text-stone-400 text-xs font-semibold uppercase tracking-wider">Synchronizing secure portals...</span>
        </div>
      </div>
    );
  }

  const isTabAdmin = currentTab === 'admin';

  return (
    <div className="min-h-screen bg-[#FAF9F6] text-stone-900 flex flex-col font-sans selection:bg-[#E1007A]/10 selection:text-[#E1007A] relative" id="portal-root">
      
      {/* Soft Pastel Background Mesh Gradients for Kinderbee Branding */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none z-0">
        <div className="absolute top-[-5%] left-[-5%] w-[45%] h-[45%] bg-[#E1007A] rounded-full blur-[140px] opacity-[0.06]"></div>
        <div className="absolute bottom-[-5%] right-[-5%] w-[45%] h-[45%] bg-[#FFD200] rounded-full blur-[140px] opacity-[0.06]"></div>
        <div className="absolute top-[35%] left-[55%] w-[30%] h-[30%] bg-[#9D2B84] rounded-full blur-[150px] opacity-[0.04]"></div>
      </div>

      {/* Dynamic Sticky Header */}
      {!(isTabAdmin && isAdmin) && (
        <Header 
          currentTab={currentTab} 
          setCurrentTab={handleSetTab} 
          settings={settings} 
          isAdmin={isAdmin}
          onLogout={() => {
            setIsAdmin(false);
            localStorage.removeItem('kips_admin_token');
            handleSetTab('home');
          }}
        />
      )}

      {/* Main Switchboard */}
      {isTabAdmin ? (
        <AdminDashboard 
          isAdmin={isAdmin} 
          setIsAdmin={setIsAdmin} 
          settings={settings} 
          setSettings={setSettings} 
          pages={pages}
          setPages={setPages}
        />
      ) : (
        <PublicPages 
          currentTab={currentTab} 
          setCurrentTab={handleSetTab} 
          settings={settings} 
          pages={pages}
        />
      )}

      {/* Global Interactive Footer */}
      {!(isTabAdmin && isAdmin) && <Footer setCurrentTab={handleSetTab} settings={settings} />}

      {/* Customizable Lead Generation Popup Modal */}
      <LeadPopupModal
        isOpen={popupOpen}
        onClose={() => {
          setPopupOpen(false);
        }}
        settings={settings}
      />

      {/* Floating Interactive Widget Support Callouts */}
      {!(isTabAdmin && isAdmin) && (
        <div className="fixed bottom-6 right-6 flex flex-col gap-3.5 z-40 items-end" id="floating-widgets">
        
        {/* Quick Pop-up Enquiry Trigger Pill */}
        <button
          type="button"
          onClick={() => setPopupOpen(true)}
          className="group flex items-center gap-2.5 px-4 py-2.5 bg-gradient-to-r from-[#0C5A3E] to-[#0A4731] border border-amber-400/50 text-white rounded-full shadow-xl hover:shadow-2xl hover:scale-105 active:scale-95 transition-all cursor-pointer ring-4 ring-emerald-500/10 font-sans"
          id="trigger-lead-popup-button"
        >
          <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse"></span>
          <span className="text-xs font-bold font-display tracking-wide uppercase">Admissions Open</span>
          <ArrowRight className="w-3.5 h-3.5 text-amber-300 group-hover:translate-x-0.5 transition-transform" />
        </button>

        {/* Live Support hotline callout with beautiful gradient & active click effect */}
        <a 
          href={`tel:${settings.phone.replace(/\s+/g, '')}`}
          className="p-3.5 bg-gradient-to-r from-[#E1007A] to-[#F79F33] text-white rounded-full shadow-lg hover:shadow-[#E1007A]/30 active:scale-95 transition-all duration-300 flex items-center justify-center cursor-pointer ring-4 ring-pink-500/15 w-12 h-12"
          title={`Call Partnership Desk: ${settings.phone}`}
        >
          <PhoneCall className="w-5 h-5 text-white" />
        </a>

        {/* WhatsApp Chat link with official green branding and custom SVG logo */}
        <a 
          href={`https://wa.me/${settings.whatsappNumber.replace(/[^0-9]/g, '')}?text=Hello%20KinderBee,%20I%20am%20interested%20in%20an%20educational%20partnership.`}
          target="_blank" 
          referrerPolicy="no-referrer"
          rel="noreferrer"
          className="p-3.5 bg-[#25D366] text-white rounded-full shadow-lg hover:shadow-emerald-500/30 active:scale-95 transition-all duration-300 flex items-center justify-center cursor-pointer ring-4 ring-emerald-500/15 w-12 h-12"
          title="Instant WhatsApp Consultation"
        >
          <svg className="w-5 h-5 fill-current text-white" viewBox="0 0 24 24">
            <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946C.06 5.348 5.397.01 12.008.01c3.202.001 6.212 1.246 8.477 3.513 2.262 2.268 3.507 5.28 3.505 8.484-.004 6.657-5.34 11.997-11.953 11.997-2.005-.001-3.973-.502-5.724-1.455L0 24zm6.59-4.846c1.6.95 3.188 1.449 4.825 1.451 5.436 0 9.86-4.37 9.864-9.799.002-2.63-1.023-5.101-2.885-6.97C16.428 1.968 13.963 1.01 11.385 1.01c-5.408 0-9.81 4.372-9.815 9.802-.001 1.77.472 3.497 1.371 5.022L1.921 21.75l6.009-1.573c.001-.001.001-.001.002-.001z" />
            <path d="M17.037 13.882c-.276-.138-1.636-.807-1.888-.899-.253-.093-.437-.138-.62.138-.184.276-.713.899-.873 1.083-.16.184-.321.207-.597.069-.276-.138-1.166-.43-2.22-1.37-1.161-1.036-1.554-2.155-1.784-2.523-.23-.368-.024-.567.16-.749.166-.164.276-.322.414-.483.138-.161.184-.276.276-.46.093-.184.047-.346-.024-.483-.07-.138-.62-1.494-.85-2.046-.223-.538-.45-.465-.62-.473l-.528-.01c-.184 0-.483.069-.736.346-.253.276-.966.944-.966 2.3 0 1.356.989 2.666 1.127 2.85 1.356 1.802 2.9 3.326 5.009 4.14 2.109.814 2.109.543 2.494.509.385-.034 1.241-.507 1.413-1.012.172-.506.172-.943.121-1.034-.051-.09-.184-.138-.46-.276z" />
          </svg>
        </a>

      </div>
      )}

    </div>
  );
}
